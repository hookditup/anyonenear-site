// AnyoneNear — Background Service Worker
// Handles: License validation, central Claude qualification via backend,
//          lead relay to GHL (via the ghl-webhook backend function),
//          rate-limited comment queue, group cycling, DM phone capture,
//          notifications, badge, owner-app sync (replies approved on the
//          owner's phone are claimed here and posted from this computer)
//
// MV3 service workers are killed after ~30s idle, so nothing that must outlive
// one event lives in memory: pending approvals and the comment queue are in
// chrome.storage.local, cycling state in chrome.storage.session, and every
// timer is a chrome.alarms alarm (setTimeout dies with the worker).

"use strict";

// Settings and the license lived in chrome.storage.sync until 1.11.30. Sync
// storage is shared by every Chrome signed in to the same Google account, so
// a second profile could mark the license invalid on the 24/7 computer, and
// it has a small size limit. Copied to local storage once; the sync copy is
// left alone (an older version on another computer still reads it).
const STORAGE_MIGRATION = (async () => {
  try {
    const { syncMigratedAt } = await chrome.storage.local.get("syncMigratedAt");
    if (syncMigratedAt) return;
    const old = await chrome.storage.sync.get(null).catch(() => ({}));
    const have = await chrome.storage.local.get(Object.keys(old));
    const copy = Object.fromEntries(Object.entries(old).filter(([k]) => !(k in have)));
    await chrome.storage.local.set({ ...copy, syncMigratedAt: Date.now() });
  } catch (e) { console.warn("[AnyoneNear] storage migration:", e?.message); }
})();

// ─── Constants ────────────────────────────────────────────────────────────────
const BACKEND_URL       = "https://citzcbytydvrrqxbzkli.supabase.co/functions/v1";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpdHpjYnl0eWR2cnJxeGJ6a2xpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAwMzU5OTMsImV4cCI6MjEwNTYxMTk5M30.6KoRIkdQIfVRO8BccKag9XSNS0EGSC51y8g9_6Y574o";
const SEEN_TTL_MS       = 30 * 24 * 60 * 60 * 1000;
const REVALIDATE_ALARM  = "license-revalidate";
const CYCLE_ALARM       = "cycle-next";
const QUEUE_ALARM       = "comment-queue";
const HEARTBEAT_ALARM   = "heartbeat";
const REPLY_SYNC_ALARM  = "reply-sync";      // owner app: claim approved replies, report results
const REPLY_SYNC_MIN    = 2;

// Facebook account-safety defaults ("conservative"). The customer can loosen
// them in Settings → Safety limits; stored as chrome.storage.local `safety`.
const SAFETY_DEFAULTS = {
  dailyCap:        8,     // comments per rolling 24h
  minGapMin:       5,     // random gap between comments, minutes
  maxGapMin:       20,
  dwellMinSec:     120,   // random time on each group before moving on
  dwellMaxSec:     360,
  activeStartHour: 7,     // scan + comment only between these local hours
  activeEndHour:   22,
};

// Every backend request needs the anon key for Supabase API gateway routing
function backendHeaders(extra = {}) {
  return { "Content-Type": "application/json", "apikey": SUPABASE_ANON_KEY, ...extra };
}

async function getSafety() {
  const { safety } = await chrome.storage.local.get("safety");
  return { ...SAFETY_DEFAULTS, ...(safety || {}) };
}

// Replies post automatically — that's the product. The default is set by the
// server (/activate `autoPostDefault`, Supabase secret AUTO_POST_DEFAULT) so it
// can be turned on for everyone without a release: while it's off, every reply
// waits for confirmation; once on, new installs get a 48h review period and then
// buyers scoring AUTO_MIN_SCORE+ are queued without a click. The customer can pin
// either mode in Settings (sync `replyMode`: "auto" | "review"). Every queued
// reply still goes through the safety limits below.
const AUTO_MIN_SCORE   = 7;
const REVIEW_PERIOD_MS = 48 * 60 * 60 * 1000;

// 2026-10-17: the default is earned, not timed. The server turns
// autoPostDefault on once the owner has sent 20+ replies (80%+ unchanged, over
// 3+ days; _shared/auto-earn.ts), and default auto-posts stop at
// AUTO_DAILY_CAP a day (later ones wait for the owner). A mode the owner picks
// in Settings wins, with the normal safety limits.
const AUTO_DAILY_CAP = 5;
async function getReplyMode() {
  const { replyMode, autoPostDefault } = await chrome.storage.local.get(["replyMode", "autoPostDefault"]);
  if (replyMode === "auto" || replyMode === "review") return replyMode;
  if (autoPostDefault !== true) return "review";
  const { autoPosts } = await chrome.storage.local.get("autoPosts");
  const today = (autoPosts || []).filter((t) => Date.now() - t < 86400_000);
  return today.length < AUTO_DAILY_CAP ? "auto" : "review";
}

// Starts the review period once (first install, or first run of this version).
async function ensureReviewPeriod() {
  const { reviewUntil } = await chrome.storage.local.get("reviewUntil");
  if (!reviewUntil) await chrome.storage.local.set({ reviewUntil: Date.now() + REVIEW_PERIOD_MS });
}

function inActiveHours(s, d = new Date()) {
  const h = d.getHours();
  return s.activeStartHour <= s.activeEndHour
    ? h >= s.activeStartHour && h < s.activeEndHour
    : h >= s.activeStartHour || h < s.activeEndHour;   // window spans midnight
}

// Active hours (2026-09-30) only decide when replies post. Groups are checked
// around the clock (more slowly at night). A 24-hour business can let replies
// post any time too ("Reply any time", replyAnyTime from the app).
async function repliesAllowed(s, d = new Date()) {
  const { replyAnyTime } = await chrome.storage.local.get("replyAnyTime");
  return replyAnyTime === true || inActiveHours(s, d);
}

// Next local time the active window opens.
function nextActiveStart(s) {
  const d = new Date();
  d.setMinutes(0, 0, 0);
  for (let i = 0; i < 48 && !inActiveHours(s, d); i++) d.setHours(d.getHours() + 1);
  return Math.max(d.getTime(), Date.now() + 60_000);
}

const rand = (min, max) => min + Math.random() * (max - min);

// ─── Message Handler ──────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message.type) {
    case "SEND_FEEDBACK":
      sendFeedback(message).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message }));
      return true;

    case "LEAD_FOUND":
      handleNewLead(message.lead);
      sendResponse({ ok: true });
      return false;

    case "NETWORK_POST":
      handleNetworkPost(message.post, message.candidates).catch((e) => log("Network referral error:", e.message));
      sendResponse({ ok: true });
      return false;

    case "DM_PHONE_CAPTURED":
      handlePhoneCaptured({ ...message.contact, leadId: message.leadId ?? message.contact?.leadId });
      sendResponse({ ok: true });
      return false;

    case "APPROVE_COMMENT":
      approveComment(message.leadId, message.commentText).then(sendResponse);
      return true;

    case "SKIP_LEAD":
      skipLead(message.leadId).then(sendResponse);
      return true;

    case "ACTIVATE_LICENSE":
      activateLicense(message.licenseKey, message.deviceId)
        .then(result => sendResponse(result))
        .catch(err => sendResponse({ valid: false, error: err.message }));
      return true;

    case "GET_LICENSE_STATUS":
      getLicenseStatus().then(sendResponse);
      return true;

    // Setup: search Facebook for local groups (see findGroups).
    case "FIND_GROUPS":
      (message.topic ? findGroupsByTopic(message.topic) : findGroups(message.town)).then(sendResponse).catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;

    // ── Tab cycling — controlled from dashboard but runs in background ──
    case "START_CYCLING":
      chrome.storage.local.remove("fbRestrictedUntil").then(startCycling).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: e.message }));
      return true;

    case "STOP_CYCLING":
      stopCycling().then(() => sendResponse({ ok: true }));
      return true;

    case "GET_CYCLE_STATUS":
      getCycleState().then(st => sendResponse({
        active:    st.active,
        groupName: st.currentGroup,
        index:     st.index,
        total:     st.total,
        paused:    st.paused || false,
        resumeAt:  st.resumeAt || null,
      }));
      return true;

    case "SAVE_CLOUD_SETTINGS":
      saveCloudSettings(message.settings || {}).then(sendResponse);
      return true;

    case "GET_UPTIME":
      uptimeSummary().then(sendResponse);
      return true;

    case "SIGN_OUT_LICENSE":
      signOutLicense().then(sendResponse);
      return true;

    case "OPEN_DASHBOARD":
      // One app: settings live in the AnyoneNear app now (Watch screen).
      openApp("#/watch").then(() => sendResponse({ ok: true }));
      return true;

    case "WATCH_GROUP":
      watchGroup(message.url, message.name).then(sendResponse);
      return true;

    case "CONFIG_UPDATED":
      // Relay to every open Facebook tab. chrome.runtime.sendMessage never
      // reaches content scripts, so a tab already open and scanning would
      // otherwise keep its stale keyword list / business settings.
      chrome.tabs.query({ url: "https://www.facebook.com/*" }, (tabs) => {
        tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { type: "CONFIG_UPDATED" }).catch(() => {}));
      });
      // Safety settings may have changed — let a waiting queue re-evaluate.
      chrome.alarms.create(QUEUE_ALARM, { when: Date.now() + 1000 });
      sendResponse({ ok: true });
      return false;
  }
  return false;
});

// "+ Watch this group" from the bubble. Same rules as the dashboard's Add
// group: a real group URL, no duplicates, within the plan's group limit.
async function watchGroup(url, name) {
  const m = String(url || "").match(/facebook\.com\/groups\/([^/?#]+)/);
  if (!m) return { ok: false, error: "Open a Facebook group to watch it" };
  const gid = decodeURIComponent(m[1]);
  const clean = `https://www.facebook.com/groups/${m[1]}/`;
  const { maxGroups = 3 } = await chrome.storage.local.get("maxGroups");
  let result = { ok: true };
  await updateStore("monitorGroups", (groups) => {
    const list = Array.isArray(groups) ? groups : [];
    const idOf = (u) => { const x = String(u || "").match(/facebook\.com\/groups\/([^/?#]+)/); return x ? decodeURIComponent(x[1]) : null; };
    if (list.some((g) => idOf(g.url) === gid)) { result = { ok: true, already: true }; return list; }
    if (list.length >= maxGroups) { result = { ok: false, error: `Your plan covers ${maxGroups} groups — remove one in the dashboard first` }; return list; }
    list.push({ url: clean, name: (name || gid).slice(0, 120), active: true });
    return list;
  }, []);
  return result;
}

// ─── License Activation ───────────────────────────────────────────────────────
async function activateLicense(licenseKey, deviceId) {
  log("Activating license:", licenseKey?.substring(0, 8) + "...");

  try {
    const res = await fetch(`${BACKEND_URL}/activate`, {
      method:  "POST",
      headers: backendHeaders(),
      body:    JSON.stringify({ licenseKey, deviceId }),
    });

    let data = {};
    try { data = await res.json(); } catch { /* an error page, not JSON */ }

    // A busy or failing server (429, 5xx) says nothing about the license. It
    // used to mark the license invalid, which stopped monitoring and signed
    // the customer out until they pasted the key again.
    if (res.status === 429 || res.status >= 500) {
      log("License check: server returned", res.status, "— keeping the license");
      return { valid: false, error: "Connection error — the server is busy. Try again in a minute." };
    }

    if (!res.ok || !data.valid) {
      await chrome.storage.local.set({ licenseStatus: "invalid", licenseError: data.error || "Invalid license key" });
      return { valid: false, error: data.error };
    }

    // Server values seed the customer's settings, but never overwrite what the
    // customer has since set themselves — re-validation runs every 23h and
    // used to silently revert custom keywords and Settings edits.
    const cur = await chrome.storage.local.get(["keywords", "businessPageName", "messengerUrl"]);
    await chrome.storage.local.set({
      licenseKey,
      licenseStatus:     "active",
      licenseError:      "",
      licenseExpiresAt:  data.expiresAt,
      plan:              data.plan,
      customerId:        data.customerId,
      ghlLocationId:     data.ghlLocationId || "",
      ownerAppUrl:       data.ownerAppUrl || "",
      maxGroups:         data.maxGroups ?? 3,
      scanAllGroups:     data.scanAllGroups === true,
      autoPostDefault:   data.autoPostDefault === true,
      businessPageName:  cur.businessPageName || data.businessPageName || "",
      messengerUrl:      cur.messengerUrl     || data.messengerUrl     || "",
      keywords:          cur.keywords?.length ? cur.keywords : (data.keywords || []),
    });
    await chrome.storage.local.set({ ghlSetup: data.ghlSetup || null, addons: data.addons || {}, usage: data.usage || null, cloud: data.cloud || null, serverVertical: data.vertical || "", extraTrades: Array.isArray(data.extraTrades) ? data.extraTrades : [] });
    // Keys from the retired direct-to-GHL relay and GHL approval polling.
    await chrome.storage.local.remove(["ghlWebhookUrl", "approvalEndpoint", "requiresClaudeKey", "claudeApiKey"]);

    // Tell all open Facebook tabs to reload config
    const tabs = await chrome.tabs.query({ url: "https://www.facebook.com/*" });
    tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { type: "CONFIG_UPDATED" }).catch(() => {}));

    // Schedule 23h re-validation, and make sure the hourly heartbeat is running
    chrome.alarms.create(REVALIDATE_ALARM, { delayInMinutes: 23 * 60 });
    scheduleHeartbeat();   // first check-in (with settings) a minute from now
    scheduleReplySync(5000);

    log("License activated:", data.plan);
    // Back after a refusal: pick monitoring up again if the owner had it on.
    const { pausedByLicense, monitoringOn } = await chrome.storage.local.get(["pausedByLicense", "monitoringOn"]);
    if (pausedByLicense) {
      await chrome.storage.local.remove("pausedByLicense");
      if (monitoringOn) { log("License works again: resuming monitoring"); startCycling().catch((e) => log("Resume error:", e.message)); }
    }
    return { valid: true, plan: data.plan, businessPageName: data.businessPageName };

  } catch (err) {
    log("License activation error:", err.message);
    return { valid: false, error: "Connection error — check your internet and try again." };
  }
}

async function getLicenseStatus() {
  const sync = await chrome.storage.local.get([
    "licenseStatus", "licenseError", "licenseExpiresAt", "plan", "licenseKey"
  ]);
  return {
    status:    sync.licenseStatus    || "none",
    error:     sync.licenseError     || "",
    plan:      sync.plan             || "",
    expiresAt: sync.licenseExpiresAt || "",
    hasKey:    !!sync.licenseKey,
  };
}

async function revalidateLicense() {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return;

  const deviceId = await getDeviceId();
  const result   = await activateLicense(licenseKey, deviceId);

  if (!result.valid) {
    log("Re-validation failed:", result.error);
    // Connection errors keep the license; a refusal from the server doesn't.
    if (!/connection error/i.test(result.error || "")) await deactivateLocally(result.error || "License not active");
  }
}

async function getDeviceId() {
  const { deviceId } = await chrome.storage.local.get("deviceId");
  if (deviceId) return deviceId;
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  const id = Array.from(arr).map(b => b.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

// ─── Core Lead Flow ───────────────────────────────────────────────────────────
async function handleNewLead(lead, preResult = null) {
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);

  if (licenseStatus !== "active" || !licenseKey) {
    log("Lead dropped — license not active");
    return;
  }

  // Each lead goes to Claude once. content.js remembers what it has seen, but
  // this is the backstop: without it every group revisit re-sent every
  // matching post (and burned the monthly plan quota within hours).
  if (!await claimLeadId(lead.id)) return;

  // The same post can reach us under two IDs — fb_<postId> once FB exposes
  // its permalink, a text hash (h_…) before that. Claim the post text too so
  // it becomes one lead, not two (and one AI check, one GHL contact).
  // Top-level posts only: short comments ("need a plumber") repeat verbatim.
  if (lead.source !== "facebook_comment" && lead.postText) {
    const body = String(lead.postText).replace(/\s+/g, " ").trim().toLowerCase().substring(0, 200);
    // Text only, not the group (2026-10-22): the Groups feed and the group's
    // own page could name the group differently.
    if (body.length >= 20 && !await claimLeadId(`t_${simpleHash(body.substring(0, 120))}`)) {
      log("Duplicate post (same text under another ID) — skipped:", lead.id);
      return;
    }
  }

  const result = preResult || await qualifyAndComment(lead, licenseKey);
  await actOnCheck(lead, result);
}

// What happens after the AI check (first try or a retry).
async function actOnCheck(lead, result) {
  if (!result.isBuyer) {
    if (result.retry) {
      const gaveUp = await scheduleRetry(`ai:${lead.id}`, { kind: "ai", lead });
      await logActivity(lead, "ai_error", { reason: gaveUp ? "Couldn't reach the AI after 5 tries; this post was skipped" : "Couldn't reach the AI; trying this post again shortly" });
      return;
    }
    log("Disqualified:", result.reason);
    const failed = !!result.error || /^(backend_error|network)/i.test(result.reason || "");
    await logActivity(lead, failed ? "ai_error" : "not_buyer", { reason: failed ? (result.error || "The AI check failed") : (result.reason || "") });
    return;
  }

  log("Qualified buyer — score:", result.score);

  lead.intentScore   = Number(result.score) || 5;
  lead.intentReason  = result.reason;
  lead.intentSummary = result.summary;
  lead.commentDraft  = result.commentText;
  lead.commentStatus = lead.postUrl ? "pending" : "manual";

  const auto = !!lead.postUrl && !!result.commentText
    && lead.intentScore >= AUTO_MIN_SCORE && await getReplyMode() === "auto";
  if (auto) lead.commentStatus = "queued";
  // Tells the server whether this reply waits for the owner (a reply request
  // the phone can approve), posts by itself, or needs a hand-written reply.
  lead.approval = auto ? "auto" : (lead.postUrl && result.commentText) ? "pending" : "manual";

  await persistLead(lead);

  if (auto) {
    await updateStore("autoPosts", (a) => [...(a || []).filter((t) => Date.now() - t < 86400_000), Date.now()], []);
    await updateStore("commentQueue", (q) => {
      if (!q.find(x => x.lead.id === lead.id)) q.push({ lead, commentText: result.commentText, queuedAt: Date.now(), auto: true });
      return q;
    }, []);
    await scheduleQueue();
  } else if (lead.postUrl) {
    await updateStore("pendingApprovals", (p) => {
      // No expiry: owners approve from their phone whenever they get to it,
      // and a late reply still beats no reply.
      p[lead.id] = { lead, commentText: result.commentText };
      return p;
    }, {});
  }

  await relayLead(lead, "detected");
  await logActivity(lead, auto ? "auto_queued" : lead.postUrl ? "reply_waiting" : "lead_manual", { score: lead.intentScore });
  await showNotification(lead, auto);
}

// ─── Retries ──────────────────────────────────────────────────────────────────
// A post whose AI check failed, or a lead whose hand-off to the server failed,
// waits here and is tried again: 10, 20, 40, 80 and 160 minutes later, then
// dropped. Runs with the 10-minute config check.
const RETRY_MAX = 5;
async function scheduleRetry(key, item) {
  let gaveUp = false;
  await updateStore("retryQueue", (q) => {
    const attempts = (q[key]?.attempts || 0) + 1;
    if (attempts > RETRY_MAX) { delete q[key]; gaveUp = true; return q; }
    q[key] = { ...item, attempts, nextAt: Date.now() + 10 * 60_000 * 2 ** (attempts - 1) };
    const keys = Object.keys(q);
    if (keys.length > 200) keys.sort((a, b) => q[a].nextAt - q[b].nextAt).slice(200).forEach((k) => delete q[k]);
    return q;
  }, {});
  return gaveUp;
}
async function clearRetry(key) {
  const { retryQueue } = await chrome.storage.local.get("retryQueue");
  if (retryQueue?.[key]) await updateStore("retryQueue", (q) => { delete q[key]; return q; }, {});
}
async function runRetries() {
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  if (licenseStatus !== "active" || !licenseKey) return;
  const { retryQueue = {} } = await chrome.storage.local.get("retryQueue");
  const due = Object.entries(retryQueue).filter(([, v]) => v.nextAt <= Date.now()).slice(0, 5);
  for (const [key, item] of due) {
    if (item.kind === "ai") {
      log("Retrying the AI check for", item.lead.id, `(try ${item.attempts + 1})`);
      const result = await qualifyAndComment(item.lead, licenseKey);
      if (!result.retry) await clearRetry(key);
      await actOnCheck(item.lead, result);
    } else if (item.kind === "relay") {
      log("Retrying the hand-off for", item.lead.id, item.stage);
      await relayLead(item.lead, item.stage, item.extra || {});
    }
  }
}

// Returns false if this lead id was already processed (within SEEN_TTL_MS).
// The Piano Project network (2026-10-25): a post asking for a fellow
// member's trade goes to network-referral, which checks it for that member and
// creates the referral (and our recommendation to approve). Once per post.
async function handleNetworkPost(post, candidates) {
  if (!post?.id || !post.postUrl || !Array.isArray(candidates) || !candidates.length) return;
  if (!await claimLeadId(`n_${post.id}`)) return;
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return;
  const res = await fetch(`${BACKEND_URL}/network-referral`, {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${licenseKey}` },
    body: JSON.stringify({ postId: post.id, postText: post.postText, postUrl: post.postUrl, groupName: post.groupName,
      groupId: post.groupId, authorName: post.authorName, postedAt: post.postedAt, candidates }),
  });
  const data = await res.json().catch(() => ({}));
  log(data.referred ? `Network referral: sent to ${data.to}${data.recommendation ? ", recommendation waiting for you" : ""}` : `Network post not referred (${data.reason || data.error || res.status})`);
}

async function claimLeadId(id) {
  let fresh = false;
  await updateStore("processedLeadIds", (seen) => {
    const now = Date.now();
    for (const [k, t] of Object.entries(seen)) if (now - t > SEEN_TTL_MS) delete seen[k];
    if (!seen[id]) { seen[id] = now; fresh = true; }
    return seen;
  }, {});
  return fresh;
}

// ─── Central Qualification + Comment ─────────────────────────────────────────
// Calls YOUR backend — Claude runs on YOUR key, customer needs nothing
async function qualifyAndComment(lead, licenseKey) {
  const sync = await chrome.storage.local.get(["businessPageName", "messengerUrl", "tagPageInReplies", "keywords"]);

  try {
    const res = await fetch(`${BACKEND_URL}/qualify-and-comment`, {
      method:  "POST",
      headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }),
      body: JSON.stringify({
        postText:        lead.postText,
        matchedKeywords: lead.matchedKeywords,
        // The customer's whole keyword list describes what they sell, so the AI
        // can turn down buyers for a different trade ("need a plumber" when the
        // business does roofing) even when a generic keyword matched.
        businessKeywords: (sync.keywords || []).slice(0, 80),
        groupName:       lead.groupName,
        groupId:         lead.groupId || "",
        postUrl:         lead.postUrl || lead.sourceUrl || "",
        businessPageName:sync.businessPageName || "",
        messengerUrl:    sync.messengerUrl     || "",
        // Reply ends with an @tag of the Page instead of an m.me link — tags are
        // native FB, links draw spam filtering. content.js falls back to the
        // link only if the tag can't be made.
        tagPage:         sync.tagPageInReplies !== false,
        // Someone named/tagged this business: ask for a thank-you/follow-up
        // reply rather than a cold "we can help" comment.
        ...(lead.mention ? { mode: "mention" } : {}),
      }),
    });

    if (!res.ok) {
      // Fail CLOSED — a 401/429/5xx is not evidence someone wants to hire this
      // business. The backend fails closed too (it used to answer errors with
      // a 200 "isBuyer: true" plus a canned comment).
      const body = await res.json().catch(() => ({}));
      const limit = !!(body.groupLimitReached || body.limitReached);
      if (limit) await chrome.storage.local.set({ backendLimit: { message: body.error, at: Date.now() } });
      // Server trouble isn't an answer: keep the post and ask again later.
      const retry = !limit && (res.status >= 500 || res.status === 429 || res.status === 408);
      log(`Backend error ${res.status}${retry ? " — will try this post again" : ""}:`, body.error || "");
      return { isBuyer: false, score: 0, reason: `backend_error_${res.status}`, summary: "", commentText: "", retry,
               error: body.error || `Server error ${res.status}` };
    }

    return await res.json();

  } catch (err) {
    log("qualifyAndComment network error — will try this post again:", err.message);
    return { isBuyer: false, score: 0, reason: "network_error", summary: "", commentText: "", retry: true };
  }
}

// ─── Lead Persistence ─────────────────────────────────────────────────────────
async function persistLead(lead) {
  await updateStore("leads", (leads) => {
    if (leads.find(l => l.id === lead.id)) return leads;
    leads.unshift(lead);
    return leads.slice(0, 500);
  }, []);
}

async function patchLead(leadId, patch) {
  await updateStore("leads", (leads) => {
    const l = leads.find(x => x.id === leadId);
    if (l) Object.assign(l, patch);
    return leads;
  }, []);
}

// Serialized read-modify-write on one chrome.storage.local key. Every writer
// in this worker goes through here, so concurrent handlers can't drop each
// other's updates.
const storeLocks = {};
function updateStore(key, fn, fallback) {
  const prev = storeLocks[key] || Promise.resolve();
  const next = prev.then(async () => {
    const data = await chrome.storage.local.get(key);
    const cur  = data[key] ?? structuredClone(fallback);
    await chrome.storage.local.set({ [key]: fn(cur) });
  }).catch(err => log(`updateStore(${key}) error:`, err.message));
  storeLocks[key] = next;
  return next;
}

// ─── Approvals → rate-limited comment queue ──────────────────────────────────
// Replies reach the queue automatically (see getReplyMode) or by approval from
// the popup, dashboard or notification button (review mode, and buyers below
// AUTO_MIN_SCORE). The queue enforces the safety limits: daily cap, random gap
// between comments, active hours.
async function approveComment(leadId, editedText) {
  const { pendingApprovals = {} } = await chrome.storage.local.get("pendingApprovals");
  const pending = pendingApprovals[leadId];

  if (!pending) {
    const { leads = [] } = await chrome.storage.local.get("leads");
    const lead = leads.find(l => l.id === leadId);
    if (lead && !lead.postUrl) return { ok: false, reason: "no_permalink" };
    return { ok: false, expired: true };
  }
  if (pending.expiresAt && Date.now() > pending.expiresAt) {   // legacy entries only
    await updateStore("pendingApprovals", (p) => { delete p[leadId]; return p; }, {});
    await patchLead(leadId, { commentStatus: "expired" });
    return { ok: false, expired: true };
  }

  const commentText = (editedText || pending.commentText || "").trim();
  if (!commentText) return { ok: false, reason: "empty_comment" };

  // The server is the single source of truth for decisions, so the phone and
  // this computer can't both send the same reply. It hands the claim straight
  // back to this device, so the reply queues here right away.
  const decision = await decideOnServer(leadId, "send", commentText);
  if (decision.alreadyDecided) {
    await applyServerDecision(leadId, decision.status, pending.lead, decision.decidedBy);
    return { ok: false, reason: "already_decided", status: decision.status, decidedBy: decision.decidedBy };
  }

  await updateStore("pendingApprovals", (p) => { delete p[leadId]; return p; }, {});
  await updateStore("commentQueue", (q) => {
    if (!q.find(x => x.lead.id === leadId)) q.push({ lead: pending.lead, commentText, queuedAt: Date.now() });
    return q;
  }, []);
  await patchLead(leadId, { commentStatus: "queued", commentDraft: commentText });
  await logActivity(pending.lead, "approved", commentText !== pending.commentText ? { reason: "edited before sending" } : {});

  const eta = await scheduleQueue();
  return { ok: true, queued: true, eta };
}

async function skipLead(leadId) {
  const { pendingApprovals = {} } = await chrome.storage.local.get("pendingApprovals");
  if (pendingApprovals[leadId]) {
    const decision = await decideOnServer(leadId, "skip");
    if (decision.alreadyDecided) {
      await applyServerDecision(leadId, decision.status, pendingApprovals[leadId].lead, decision.decidedBy);
      return { ok: false, reason: "already_decided", status: decision.status };
    }
    await logActivity(pendingApprovals[leadId].lead, "skipped");
  }
  await updateStore("pendingApprovals", (p) => { delete p[leadId]; return p; }, {});
  await patchLead(leadId, { commentStatus: "skipped" });
  return { ok: true };
}

// ─── Owner app sync ───────────────────────────────────────────────────────────
// Replies waiting for approval live on the server (reply_requests) so the
// owner can decide from their phone. This computer still does the posting:
// every couple of minutes it claims replies approved anywhere, feeds them
// into the safety queue above, and reports how each one went.

// Records a Send/Skip on the server. Returns { ok } on success,
// { alreadyDecided, status, decidedBy } when the phone (or another device)
// got there first, and { ok: true, offline: true } when the server can't be
// reached or has no row for this lead (pre-1.6 leads) — then the local
// queue carries on as before, so a backend outage never blocks a reply.
async function decideOnServer(leadId, action, text) {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return { ok: true, offline: true };
  try {
    const res = await fetch(`${BACKEND_URL}/reply-decide`, {
      method: "POST", headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }),
      body: JSON.stringify({ leadId, action, text, claimDevice: await getDeviceId() }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 409 && data.alreadyDecided) return data;
    if (res.status === 404) return { ok: true, offline: true };
    if (!res.ok) { log("reply-decide failed:", res.status, data.error || ""); return { ok: true, offline: true }; }
    return data;
  } catch (err) {
    log("reply-decide unreachable — deciding locally:", err.message);
    return { ok: true, offline: true };
  }
}

// Mirrors a decision made elsewhere (phone, another device) onto this computer.
async function applyServerDecision(leadId, status, lead, decidedBy) {
  await updateStore("pendingApprovals", (p) => { delete p[leadId]; return p; }, {});
  const map = { skipped: "skipped", approved: "queued", claimed: "queued", posted: "posted", failed: "failed", auto: "queued" };
  await patchLead(leadId, { commentStatus: map[status] || status });
  if (lead) await logActivity(lead, status === "skipped" ? "skipped" : "approved",
    { reason: status === "skipped" ? `skipped from ${decidedBy || "your phone"}` : `approved from ${decidedBy || "your phone"}` });
}

function scheduleReplySync(delayMs = 0) {
  chrome.alarms.create(REPLY_SYNC_ALARM, { when: Date.now() + Math.max(delayMs, 1000), periodInMinutes: REPLY_SYNC_MIN });
}

async function syncReplies() {
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  if (licenseStatus !== "active" || !licenseKey) return;
  const { replyResults = [], pendingApprovals = {} } = await chrome.storage.local.get(["replyResults", "pendingApprovals"]);
  // Outside active hours nothing can post anyway — skip the call unless there
  // are outcomes to report (keeps the server-call count down).
  if (!replyResults.length && !(await repliesAllowed(await getSafety()))) return;

  let data;
  try {
    const res = await fetch(`${BACKEND_URL}/ext-replies`, {
      method: "POST", headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }),
      body: JSON.stringify({ deviceId: await getDeviceId(), results: replyResults.slice(0, 50), localPending: Object.keys(pendingApprovals) }),
    });
    if (res.status === 401 || res.status === 403) { const d = await res.json().catch(() => ({})); await deactivateLocally(d.error || "License not active"); return; }
    if (!res.ok) { log("reply sync failed:", res.status); return; }
    data = await res.json();
  } catch (err) {
    log("reply sync unreachable:", err.message);
    return;
  }

  // The server has the outcomes now.
  const reported = new Set(replyResults.map(r => `${r.leadId}:${r.at}`));
  await updateStore("replyResults", (r) => r.filter(x => !reported.has(`${x.leadId}:${x.at}`)), []);

  // Replies approved on the phone: queue them here, within the safety limits.
  const { leads = [] } = await chrome.storage.local.get("leads");
  const claimedIds = new Set();
  for (const row of data.claimed || []) {
    claimedIds.add(row.lead_id);
    const text = (row.final_text || row.draft || "").trim();
    if (!text) continue;
    const lead = leads.find(l => l.id === row.lead_id) || leadFromRow(row);
    if (!leads.find(l => l.id === row.lead_id)) await persistLead(lead);
    await updateStore("commentQueue", (q) => {
      if (!q.find(x => x.lead.id === row.lead_id)) q.push({ lead, commentText: text, queuedAt: Date.now(), fromServer: true });
      return q;
    }, []);
    await updateStore("pendingApprovals", (p) => { delete p[row.lead_id]; return p; }, {});
    await patchLead(row.lead_id, { commentStatus: "queued", commentDraft: text, replyRequestId: row.id });
    await logActivity(lead, "approved", { reason: row.decided_via === "pwa" ? "approved from your phone" : "approved" });
  }

  // Decisions made elsewhere on replies still listed here.
  for (const d of data.decided || []) {
    if (claimedIds.has(d.leadId) || !pendingApprovals[d.leadId]) continue;
    await applyServerDecision(d.leadId, d.status, pendingApprovals[d.leadId].lead, d.status === "skipped" ? "your phone" : "your phone");
  }

  if ((data.claimed || []).length) await scheduleQueue();
}

// Enough of a lead to post from, when this computer never saw the post itself
// (it was found by the customer's other device).
function leadFromRow(row) {
  return {
    id: row.lead_id, postUrl: row.post_url, groupName: row.group_name || "", snippet: row.snippet || "",
    postText: row.post_text || row.snippet || "", authorName: row.author_name || "", intentScore: row.lead_score || 5,
    mention: !!row.mention, commentDraft: row.final_text || row.draft, commentStatus: "queued",
    tagPage: row.tag_page || null,   // a network recommendation: tag that member's Page, not ours
    timestamp: Date.parse(row.created_at) || Date.now(), matchedKeywords: [], replyRequestId: row.id, ghlStatus: "ok",
  };
}

// Works out when the next comment may go out, arms the alarm, returns that time.
async function scheduleQueue() {
  const { commentQueue = [], commentLog = [], nextCommentAt = 0 } =
    await chrome.storage.local.get(["commentQueue", "commentLog", "nextCommentAt"]);
  // Items being posted right now (or interrupted mid-post) don't need an alarm.
  if (!commentQueue.some((x) => !x.inFlightAt)) return null;

  const s   = await getSafety();
  const now = Date.now();
  const day = commentLog.filter(t => now - t < 24 * 60 * 60 * 1000).sort((a, b) => a - b);

  let when = Math.max(now + 1000, nextCommentAt);
  if (day.length >= s.dailyCap) when = Math.max(when, day[day.length - s.dailyCap] + 24 * 60 * 60 * 1000);
  if (!(await repliesAllowed(s, new Date(when)))) {
    const d = new Date(when); d.setMinutes(0, 0, 0);
    for (let i = 0; i < 48 && !inActiveHours(s, d); i++) d.setHours(d.getHours() + 1);
    when = Math.max(when, d.getTime());
  }

  chrome.alarms.create(QUEUE_ALARM, { when });
  return when;
}

async function processQueue() {
  const { queueBusyUntil = 0 } = await chrome.storage.session.get("queueBusyUntil");
  if (Date.now() < queueBusyUntil) return;           // another run is posting

  await sweepInterruptedReplies();
  const when = await scheduleQueue();
  if (!when || when > Date.now() + 2000) return;      // not yet — alarm re-armed

  const { commentQueue = [] } = await chrome.storage.local.get("commentQueue");
  const item = commentQueue.find((x) => !x.inFlightAt);
  if (!item) return;
  if (await restrictedUntil()) return;   // Facebook is limiting the account: no replies for now
  // Posted before (a re-claimed reply, a sync race): drop it, never post twice.
  const { postedLeadIds = {} } = await chrome.storage.local.get("postedLeadIds");
  if (postedLeadIds[item.lead.id]) {
    log("Not posting again: this reply was already posted", item.lead.id);
    await updateStore("commentQueue", (q) => q.filter((x) => x.lead.id !== item.lead.id), []);
    return;
  }

  // One post can take several minutes (waiting for a visit, loading, retries).
  await chrome.storage.session.set({ queueBusyUntil: Date.now() + 10 * 60 * 1000 });
  const s0 = await getSafety();
  await chrome.storage.local.set({ nextCommentAt: Date.now() + rand(s0.minGapMin, s0.maxGapMin) * 60 * 1000 });
  // The item stays queued, marked in flight, until the outcome is recorded.
  // It used to be removed first, so a worker killed mid-post lost it and the
  // lead stayed "queued" forever.
  await updateStore("commentQueue", (q) => q.map((x) => x.lead.id === item.lead.id ? { ...x, inFlightAt: Date.now() } : x), []);

  const result = await postCommentInOwnTab(item.lead, item.commentText);
  const s = await getSafety();

  // Space out attempts whether or not this one landed — a burst of failures
  // is as visible to Facebook as a burst of comments.
  await chrome.storage.local.set({ nextCommentAt: Date.now() + rand(s.minGapMin, s.maxGapMin) * 60 * 1000 });

  await finishQueueItem(item, result);
  await chrome.storage.session.set({ queueBusyUntil: 0 });
  await scheduleQueue();
}

// A reply still marked in flight 10 minutes after it started was interrupted
// (worker killed, Chrome closed); after a browser restart every in-flight one
// was (maxAgeMs 0). It may or may not have posted, so it is marked failed
// rather than retried: a double reply on a stranger's post is worse than a
// missed one, and the owner can send it again.
async function sweepInterruptedReplies(maxAgeMs = 10 * 60 * 1000) {
  const { commentQueue = [] } = await chrome.storage.local.get("commentQueue");
  const stale = commentQueue.filter((x) => x.inFlightAt && Date.now() - x.inFlightAt >= maxAgeMs);
  for (const x of stale) await finishQueueItem(x, { ok: false, reason: "interrupted" });
}

// Records how a queued reply went and takes it off the queue.
async function finishQueueItem(item, result) {
  await updateStore("commentQueue", (q) => q.filter(x => x.lead.id !== item.lead.id), []);
  if (result.ok) {
    await updateStore("postedLeadIds", (m) => {
      const keep = Object.fromEntries(Object.entries(m || {}).filter(([, t]) => Date.now() - t < 30 * 864e5));
      return { ...keep, [item.lead.id]: Date.now() };
    }, {});
    await updateStore("commentLog", (log) => [...log.filter(t => Date.now() - t < 48 * 3600 * 1000), Date.now()], []);
    await patchLead(item.lead.id, { commentStatus: "posted", commented: true, commentedAt: Date.now() });
    showCommentSuccessNotification(item.lead);
    await logActivity(item.lead, "posted");
    await relayLead({ ...item.lead, commentDraft: item.commentText }, "commented");
  } else if (result.reason === "already_replied") {
    log("Not posted: you'd already commented on this post", item.lead.id);
    await patchLead(item.lead.id, { commentStatus: "skipped", commentError: "already replied" });
    await logActivity(item.lead, "skipped", { reason: "you'd already commented on this post" });
  } else {
    if (result.reason === "restricted" || result.reason === "logged_out") await facebookTrouble(result.reason);
    log("Comment not posted for lead", item.lead.id, "—", result.reason);
    await patchLead(item.lead.id, { commentStatus: "failed", commentError: result.reason });
    await logActivity(item.lead, "failed", { reason: result.reason });
  }
  // Tell the server (and so the owner's phone) how it went.
  await updateStore("replyResults", (r) => [...r, { leadId: item.lead.id, ok: !!result.ok, reason: result.ok ? undefined : String(result.reason || "failed"), at: Date.now() }].slice(-50), []);
  scheduleReplySync(3000);
}

// Posts from a tab opened on the post's own permalink as the front tab of the
// monitor window (or in an unfocused window of its own), then closes it —
// never the cycling tab (it navigates away mid-post) and never in the window
// the user is working in. It has to be the front tab of a window that isn't
// minimized: Chrome doesn't draw background tabs or minimized windows, and
// Facebook doesn't load the comment box in a page that isn't drawn
// (comment_box_not_found). Group visits wait while it posts.
async function postCommentInOwnTab(lead, commentText) {
  if (!lead.postUrl) return { ok: false, reason: "no_permalink" };

  // Let a group visit that's under way finish first (up to 2 minutes).
  for (let i = 0; i < 24; i++) {
    const { visitingSince } = await chrome.storage.session.get("visitingSince");
    if (!visitingSince || Date.now() - visitingSince > 5 * 60_000) break;
    await sleep(5000);
  }
  await chrome.storage.session.set({ postingSince: Date.now() });
  let tabId, ownWindowId, keepTab = false;
  try {
    const monitor = await getMonitorWindow(await getCycleState());
    const ownTab = monitor?.tabs?.[0]?.id;
    if (monitor && Number.isInteger(ownTab)) {
      if (monitor.state === "minimized") await chrome.windows.update(monitor.id, { state: "normal", focused: false }).catch(() => {});
      await chrome.tabs.update(ownTab, { url: lead.postUrl });
      tabId = ownTab;
      keepTab = true;   // the monitor's own tab: the next group visit moves it on
    } else {
      const win = await chrome.windows.create({ url: lead.postUrl, type: "popup", focused: false, state: "normal", width: 1000, height: 820 });
      ownWindowId = win.id;
      tabId = win.tabs?.[0]?.id;
    }
    await waitForTabComplete(tabId, 30_000);
    await sleep(rand(2500, 5000));

    // @tag the customer's Business Page in the reply unless they turned it off.
    const { businessPageName, tagPageInReplies } = await chrome.storage.local.get(["businessPageName", "tagPageInReplies"]);
    const tagName = lead.tagPage ? lead.tagPage : tagPageInReplies === false ? "" : (businessPageName || "");

    for (let attempt = 1; attempt <= 7; attempt++) {
      const res = await sendToTab(tabId, { type: "POST_COMMENT", leadId: lead.id, postUrl: lead.postUrl, commentText, tagName });
      if (res?.ok) return { ok: true };
      if (res && !res.retry) return { ok: false, reason: res.reason || "failed" };
      // No response (content script not ready) or navigating — wait and retry.
      if (res?.reason === "navigating") await waitForTabComplete(tabId, 30_000);
      await sleep(3500);
    }
    return { ok: false, reason: "gave_up_after_retries" };
  } catch (err) {
    return { ok: false, reason: err.message };
  } finally {
    await chrome.storage.session.remove("postingSince").catch(() => {});
    setTimeout(() => {
      if (ownWindowId) chrome.windows.remove(ownWindowId).catch(() => {});
      else if (tabId && !keepTab) chrome.tabs.remove(tabId).catch(() => {});
    }, 4000);
  }
}

// No answer within 90 s (a stuck or throttled page) counts as no answer, so
// a visit always ends and is recorded.
function sendToTab(tabId, msg, timeoutMs = 90_000) {
  return new Promise((resolve) => {
    const t = setTimeout(() => resolve(null), timeoutMs);
    chrome.tabs.sendMessage(tabId, msg, (res) => {
      clearTimeout(t);
      if (chrome.runtime.lastError) resolve(null);
      else resolve(res);
    });
  });
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    const done = () => { clearTimeout(t); chrome.tabs.onUpdated.removeListener(listener); resolve(); };
    const listener = (id, info) => { if (id === tabId && info.status === "complete") done(); };
    const t = setTimeout(done, timeoutMs);
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(tab => { if (tab.status === "complete") done(); }).catch(done);
  });
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
// A long pause that keeps the service worker alive: Chrome stops an idle
// extension worker after about 30 seconds, and every extension call resets it.
async function wakefulSleep(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) { await sleep(Math.min(10_000, end - Date.now())); await chrome.storage.session.get("keepAlive").catch(() => {}); }
}

// ─── Group finder (setup) ─────────────────────────────────────────────────────
// Runs a few Facebook group searches for the owner's town, one background tab
// at a time with a human-sized pause between them, and ranks what comes back:
// groups named after the town first, then the busiest (posts a day), then the
// biggest. The owner picks which to watch; nothing is joined or posted.
// Searches run one after another in background tabs, each closed when read.
// A town's biggest groups are usually named after it ("Ask Heber, UT",
// "Heber Valley Community"), so the plain town and "Ask <town>" searches come
// first; the rest catch recommendation and neighbor groups with other names.
const finderQueries = (town, townWord) => [
  town, `Ask ${townWord}`, `${town} community`, `${town} recommendations`, `${town} neighbors`,
];
let finderRunning = false;

async function findGroups(town) {
  town = String(town || "").trim();
  if (town.length < 2) return { ok: false, error: "Enter your town first" };
  if (finderRunning) return { ok: false, error: "Already searching" };
  finderRunning = true;
  const found = new Map();
  const townWord = town.split(",")[0].trim().replace(/\s+(city|town|village)$/i, "");
  const queries = finderQueries(town, townWord);
  // The setup page shows progress; it may be closed, so ignore send errors.
  const progress = (step) => chrome.runtime.sendMessage({ type: "FINDER_PROGRESS", step, total: queries.length }).catch(() => {});
  try {
    for (let i = 0; i < queries.length; i++) {
      progress(i + 1);
      const tab = await chrome.tabs.create({ url: `https://www.facebook.com/search/groups/?q=${encodeURIComponent(queries[i])}`, active: false });
      try {
        await waitForTabComplete(tab.id, 30_000);
        // Tell anyone who opens this tab what it is and that it closes itself.
        await chrome.tabs.sendMessage(tab.id, { type: "FINDER_BANNER" }).catch(() => {});
        await sleep(3500 + Math.random() * 1500);           // let the results render
        const res = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_GROUP_SEARCH" }).catch(() => null);
        for (const g of res?.groups || []) {
          const prev = found.get(g.url);
          found.set(g.url, prev ? { ...prev, hits: prev.hits + 1 } : { ...g, hits: 1 });
        }
      } finally {
        chrome.tabs.remove(tab.id).catch(() => {});
      }
      if (i < queries.length - 1) await sleep(4000 + Math.random() * 3000);
    }
  } finally {
    finderRunning = false;
  }
  // Local first (the town in the name), then the kind of group people ask for
  // help in, then size and activity. Buy/sell, jobs and yard-sale groups
  // rarely have "who do you recommend" posts, so they sink.
  const tw = townWord.toLowerCase();
  const score = (g) => {
    const n = g.name.toLowerCase();
    return (n.includes(tw) ? 100 : 0)
      + (/\bask\b|recommend|community|neighbou?r|residents|locals|moms|valley|what'?s happening/.test(n) ? 25 : 0)
      - (/buy|sell|swap|yard sale|garage sale|marketplace|jobs|hiring|rent|for sale|free stuff/.test(n) ? 40 : 0)
      + Math.min(40, (g.postsPerDay || 0) * 4)
      + (g.members ? Math.log10(g.members) * 10 : 0)
      + g.hits * 4;
  };
  const groups = [...found.values()].map((g) => ({ ...g, score: Math.round(score(g)) }))
    .sort((a, b) => b.score - a.score).slice(0, 15);
  return { ok: true, groups };
}

// "My groups" (2026-10-16): the groups this Facebook login has joined, from
// facebook.com/groups/joins/ in a background tab that closes itself. Local
// ones (the town in the name) and "ask / recommend / community" groups first,
// buy-sell and jobs groups last, like findGroups.
async function myGroups(town) {
  if (finderRunning) return { ok: false, error: "Already reading Facebook, try again in a minute" };
  finderRunning = true;
  let res = null;
  try {
    const tab = await chrome.tabs.create({ url: "https://www.facebook.com/groups/joins/?nav_source=tab", active: false });
    try {
      await waitForTabComplete(tab.id, 30_000);
      await chrome.tabs.sendMessage(tab.id, { type: "FINDER_BANNER" }).catch(() => {});
      await sleep(3000 + Math.random() * 1500);
      res = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_JOINED_GROUPS" }).catch(() => null);
    } finally {
      chrome.tabs.remove(tab.id).catch(() => {});
    }
  } finally {
    finderRunning = false;
  }
  if (!res) return { ok: false, error: "Couldn't read your groups. Is Facebook signed in in this Chrome?" };
  if (res.loggedOut) return { ok: false, error: "Facebook isn't signed in in this Chrome. Sign in, then try again." };
  const tw = String(town || "").split(",")[0].trim().replace(/\s+(city|town|village)$/i, "").toLowerCase();
  const score = (g) => {
    const n = g.name.toLowerCase();
    return (tw && n.includes(tw) ? 100 : 0)
      + (/\bask\b|recommend|community|neighbou?r|residents|locals|moms|valley|what'?s happening|word of mouth/.test(n) ? 25 : 0)
      - (/buy|sell|swap|yard sale|garage sale|marketplace|jobs|hiring|rent|for sale|free stuff/.test(n) ? 40 : 0);
  };
  const groups = (res.groups || []).map((g) => ({ ...g, score: score(g) })).sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  return { ok: true, groups: groups.slice(0, 300) };
}

// The business's Facebook Page About tab, read in a background tab that
// closes itself (setup's "Read my Facebook Page"). Page link, its name or its
// m.me link.
async function pageText(page) {
  const raw = String(page || "").trim();
  const slug = (raw.match(/(?:facebook\.com|m\.me)\/(?:pg\/)?([^/?#\s]+)/i)?.[1] || (/^[A-Za-z0-9.\-]+$/.test(raw) ? raw : "")).replace(/\/$/, "");
  const pid = raw.match(/profile\.php\?id=(\d+)/i)?.[1];
  if (!slug && !pid) return { ok: false, error: "Enter your Facebook Page's link" };
  if (finderRunning) return { ok: false, error: "Already reading Facebook, try again in a minute" };
  finderRunning = true;
  let res = null;
  try {
    const url = pid ? `https://www.facebook.com/profile.php?id=${pid}&sk=about` : `https://www.facebook.com/${encodeURIComponent(slug)}/about`;
    const tab = await chrome.tabs.create({ url, active: false });
    try {
      await waitForTabComplete(tab.id, 30_000);
      await chrome.tabs.sendMessage(tab.id, { type: "FINDER_BANNER" }).catch(() => {});
      await sleep(3500 + Math.random() * 1500);
      res = await chrome.tabs.sendMessage(tab.id, { type: "READ_PAGE_TEXT" }).catch(() => null);
    } finally {
      chrome.tabs.remove(tab.id).catch(() => {});
    }
  } finally {
    finderRunning = false;
  }
  if (!res) return { ok: false, error: "Couldn't read the Page. Is Facebook signed in in this Chrome?" };
  if (!res.ok) return { ok: false, error: res.reason === "logged_out" ? "Facebook isn't signed in in this Chrome" : "Facebook didn't show the Page" };
  if ((res.text || "").length < 80) return { ok: false, error: "That Page didn't show any details" };
  return { ok: true, title: res.title, text: res.text };
}

// A group's name from its page (this Chrome's Facebook login): the page
// title, "Ask Heber | Facebook". "" when it can't be read.
async function groupName(url) {
  const m = String(url).match(/facebook\.com\/groups\/([^/?#\s]+)/i);
  if (!m) return { ok: false, error: "Not a group link" };
  try {
    const html = await fetch(`https://www.facebook.com/groups/${m[1]}/`, { credentials: "include" }).then((r) => r.text());
    const raw = (html.match(/<meta property="og:title" content="([^"]+)"/i) || html.match(/<title>([^<]+)<\/title>/i) || [])[1] || "";
    const name = raw.replace(/&amp;/g, "&").replace(/&#039;|&#x27;/g, "'").replace(/&quot;/g, '"').replace(/\s*\|\s*Facebook\s*$/i, "").trim();
    if (!name || /^(facebook|log in|log into facebook)/i.test(name)) return { ok: false, error: "Couldn't read the name" };
    return { ok: true, name: name.slice(0, 120) };
  } catch {
    return { ok: false, error: "Couldn't read the name" };
  }
}

// Businesses that don't serve one town (digital marketing, coaching, online
// services) look for groups by topic instead: "small business+marketing"
// searches the phrase, each part, and the parts together, and ranks groups
// whose name has every part first. Same one-tab-at-a-time searching as
// findGroups.
const topicQueries = (parts) => [...new Set([parts.join(" "), ...(parts.length > 1 ? parts : []), `${parts.join(" ")} group`, `${parts.join(" ")} community`])].slice(0, 5);

async function findGroupsByTopic(topic) {
  const parts = String(topic || "").split("+").map((p) => p.trim()).filter(Boolean).slice(0, 3);
  if (!parts.length || parts.join("").length < 3) return { ok: false, error: "Enter a topic, e.g. small business+marketing" };
  if (finderRunning) return { ok: false, error: "Already searching" };
  finderRunning = true;
  const found = new Map();
  const queries = topicQueries(parts);
  const progress = (step) => chrome.runtime.sendMessage({ type: "FINDER_PROGRESS", step, total: queries.length }).catch(() => {});
  try {
    for (let i = 0; i < queries.length; i++) {
      progress(i + 1);
      const tab = await chrome.tabs.create({ url: `https://www.facebook.com/search/groups/?q=${encodeURIComponent(queries[i])}`, active: false });
      try {
        await waitForTabComplete(tab.id, 30_000);
        await chrome.tabs.sendMessage(tab.id, { type: "FINDER_BANNER" }).catch(() => {});
        await sleep(3500 + Math.random() * 1500);
        const res = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_GROUP_SEARCH" }).catch(() => null);
        for (const g of res?.groups || []) {
          const prev = found.get(g.url);
          found.set(g.url, prev ? { ...prev, hits: prev.hits + 1 } : { ...g, hits: 1 });
        }
      } finally {
        chrome.tabs.remove(tab.id).catch(() => {});
      }
      if (i < queries.length - 1) await sleep(4000 + Math.random() * 3000);
    }
  } finally {
    finderRunning = false;
  }
  const words = parts.map((p) => p.toLowerCase());
  const score = (g) => {
    const n = g.name.toLowerCase();
    const has = words.filter((w) => n.includes(w)).length;
    return (has === words.length ? 100 : has * 30)
      + (/\bask\b|recommend|help|advice|support|network|owners|community/.test(n) ? 20 : 0)
      - (/buy|sell|swap|yard sale|garage sale|marketplace|jobs|hiring|for sale|free stuff|promote|promotion|advertis/.test(n) ? 40 : 0)
      + Math.min(40, (g.postsPerDay || 0) * 4)
      + (g.members ? Math.log10(g.members) * 10 : 0)
      + g.hits * 4;
  };
  const groups = [...found.values()].map((g) => ({ ...g, score: Math.round(score(g)) }))
    .sort((a, b) => b.score - a.score).slice(0, 15);
  return { ok: true, groups };
}

// ─── GHL Relay ────────────────────────────────────────────────────────────────
// Everything goes through the ghl-webhook backend function, which writes the
// contact, tags and opportunity into the customer's GHL sub-account via the
// GHL API. (The extension used to POST straight to a per-location inbound
// webhook URL that was never populated, with an empty email GHL couldn't
// create a contact from — no lead ever reached GHL.)
async function relayRetry(lead, stage, extra) {
  const gaveUp = await scheduleRetry(`relay:${lead.id}:${stage}`, { kind: "relay", lead, stage, extra });
  if (gaveUp) await logActivity(lead, "ai_error", { reason: "Couldn't send this lead to your inbox after 5 tries" });
}

async function relayLead(lead, stage, extra = {}) {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return false;

  const payload = {
    id:              lead.id,
    source:          "facebook_group",
    groupName:       lead.groupName,
    groupId:         lead.groupId || "",
    authorName:      lead.authorName,
    postUrl:         lead.postUrl || "",
    sourceUrl:       lead.sourceUrl || "",
    postText:        lead.postText,
    snippet:         lead.snippet,
    matchedKeywords: lead.matchedKeywords || [],
    mention:         !!lead.mention,
    stage,
    ...(stage === "detected" && lead.approval ? { approval: lead.approval } : {}),
    ...extra,
    customFields: {
      leadScore:        lead.intentScore || scoreLead(lead),
      intentSummary:    lead.intentSummary || "",
      suggestedComment: lead.commentDraft || "",
      detectedAt:       new Date(lead.timestamp || Date.now()).toISOString(),
      postedAt:         lead.postedAt || "",
      postSnippet:      lead.snippet?.substring(0, 200) || "",
      stage,
    },
  };

  try {
    const res  = await fetch(`${BACKEND_URL}/ghl-webhook`, {
      method:  "POST",
      headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }),
      body:    JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    log(`GHL [${stage}]:`, res.ok ? "OK" : `${res.status} ${data.error || ""}`);
    await patchLead(lead.id, { ghlStatus: res.ok ? "ok" : (data.ghlStatus || `error_${res.status}`),
      ...(data.replyRequestId ? { replyRequestId: data.replyRequestId } : {}) });
    if (res.ok) await clearRetry(`relay:${lead.id}:${stage}`);
    else if (res.status >= 500 || res.status === 429 || res.status === 408) await relayRetry(lead, stage, extra);
    return res.ok;
  } catch (err) {
    log("GHL relay error:", err.message);
    await patchLead(lead.id, { ghlStatus: "network_error" });
    await relayRetry(lead, stage, extra);
    return false;
  }
}

function scoreLead(lead) {
  let s = 5;
  const t = ((lead.postText || "") + " " + (lead.snippet || "")).toLowerCase();
  if (/today|tonight|asap|urgent|emergency|right now|immediately/.test(t)) s += 3;
  if (/this week|soon|need/.test(t)) s += 1;
  if (/already|found someone|sorted|thanks everyone/.test(t)) s -= 4;
  if (/just wondering|curious|hypothetically/.test(t)) s -= 2;
  return Math.min(10, Math.max(1, s));
}

// ─── DM Phone Capture ────────────────────────────────────────────────────────
// content.js only reports numbers from Messenger threads whose name matches a
// known lead's author, and passes that lead's id.
async function handlePhoneCaptured(contact) {
  if (!contact?.leadId || !contact.phone) return;

  const { leads = [] } = await chrome.storage.local.get("leads");
  const lead = leads.find(l => l.id === contact.leadId);
  if (!lead || lead.phoneCaptured === contact.phone) return;

  await patchLead(lead.id, { phoneCaptured: contact.phone });
  const ok = await relayLead(lead, "phone_captured", { phone: contact.phone });

  if (ok) {
    chrome.notifications.create(`phone_${simpleHash(contact.phone)}`, {
      type: "basic", iconUrl: "icons/icon48.png",
      title: "📞 Phone captured — sent to GHL",
      message: `${contact.name} · ${formatPhone(contact.phone)}`,
      priority: 2,
    });
  }
}

// ─── Notifications ────────────────────────────────────────────────────────────
async function showNotification(lead, autoQueued = false) {
  const canComment = !!lead.postUrl && !autoQueued;
  chrome.notifications.create(`lead_${lead.id}`, {
    type: "basic", iconUrl: "icons/icon48.png",
    title: lead.mention ? `⭐ You were recommended in ${lead.groupName}` : `🎯 ${lead.groupName}`,
    message: `"${lead.snippet?.substring(0, 90)}"`,
    contextMessage: autoQueued ? "Reply queued — it posts automatically within your safety limits"
      : canComment ? "Reply ready — approve to queue it" : "Sent to your lead inbox — reply to this one by hand",
    priority: 2, requireInteraction: canComment,
    buttons: canComment ? [{ title: "Send Comment ✓" }, { title: "Skip" }] : undefined,
  });
}

function showCommentSuccessNotification(lead) {
  chrome.notifications.create(`sent_${lead.id}`, {
    type: "basic", iconUrl: "icons/icon48.png",
    title: "✅ Comment posted",
    message: `Reply posted in ${lead.groupName}`,
    contextMessage: "GHL AI takes over when they DM your Page",
    priority: 1,
  });
}

chrome.notifications.onButtonClicked.addListener(async (notifId, btnIndex) => {
  if (!notifId.startsWith("lead_")) return;
  const leadId = notifId.slice("lead_".length);
  if (btnIndex === 0) {
    const res = await approveComment(leadId);
    if (!res.ok) log("Notification approve failed:", res.reason || (res.expired ? "expired" : "unknown"));
  } else {
    await skipLead(leadId);
  }
  chrome.notifications.clear(notifId);
});

chrome.notifications.onClicked.addListener(async (notifId) => {
  if (notifId === "monitor_paused" || notifId === "monitor_resumed") {
    await openApp("#/watch");
    chrome.notifications.clear(notifId);
    return;
  }
  if (!notifId.startsWith("lead_")) return;
  const leadId = notifId.slice("lead_".length);
  await chrome.storage.local.set({ focusLeadId: leadId });   // bubble opens on this reply
  const { leads = [] } = await chrome.storage.local.get("leads");
  const lead = leads.find(l => l.id === leadId);
  const url  = lead?.postUrl || lead?.sourceUrl;
  if (url) chrome.tabs.create({ url });
  chrome.notifications.clear(notifId);
});

// ─── Activity log (what the on-page bubble shows) ─────────────────────────────
// Newest first, capped. Explains what happened to each post that matched a
// keyword — including the ones the AI turned down — so "0 leads" is never a
// mystery.
async function logActivity(lead, kind, extra = {}) {
  const entry = {
    t: Date.now(), kind, leadId: lead?.id || "",
    group: lead?.groupName || "", snippet: (lead?.postText || lead?.snippet || "").slice(0, 160),
    ...extra,
  };
  await updateStore("activityLog", (log) => [entry, ...(Array.isArray(log) ? log : [])].slice(0, 50), []);
}

// Toolbar badge = replies waiting for approval (not "new since you last
// looked"), so opening the popup can't make a waiting reply look handled.
async function updatePendingBadge() {
  const { pendingApprovals = {} } = await chrome.storage.local.get("pendingApprovals");
  const n = Object.keys(pendingApprovals).length;
  chrome.action.setBadgeText({ text: n ? String(n) : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#f0883e" });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "pendingApprovals" in changes) updatePendingBadge();
});

// ─── Badge ────────────────────────────────────────────────────────────────────
async function incrementBadge() {
  const { badgeCount } = await chrome.storage.local.get(["badgeCount"]);
  const n = (badgeCount || 0) + 1;
  await chrome.storage.local.set({ badgeCount: n });
  chrome.action.setBadgeText({ text: String(n) });
  chrome.action.setBadgeBackgroundColor({ color: "#2f6bff" });
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function simpleHash(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) { h = (h << 5) - h + str.charCodeAt(i); h |= 0; }
  return Math.abs(h).toString(36);
}

function formatPhone(digits) {
  const d = String(digits).replace(/\D/g, "").slice(-10);
  return d.length === 10 ? `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}` : digits;
}

// The last 150 lines are kept (in memory, while the worker is awake) so a
// "Report a problem" can send them along.
const logRing = [];
function log(...args) {
  console.log("[AnyoneNear]", ...args);
  const line = args.map((a) => (typeof a === "string" ? a : (() => { try { return JSON.stringify(a); } catch { return String(a); } })())).join(" ");
  logRing.push(`${new Date().toISOString().slice(11, 19)} ${line.slice(0, 300)}`);
  if (logRing.length > 150) logRing.shift();
}

// What the admin console (and support) needs to see why a computer isn't
// reading: the cycle, its next alarm, pauses, the last error and log lines.
async function diagnostics() {
  const [st, alarm, sess, loc] = await Promise.all([getCycleState(), chrome.alarms.get(CYCLE_ALARM),
    chrome.storage.session.get(["visitingSince", "postingSince", "snapshotSince"]),
    chrome.storage.local.get(["lastCheckAt", "lastReadAt", "lastStopReason", "lastCycleError", "fbRestrictedUntil", "scanVisitsPending", "pausedByLicense", "retryQueue"])]);
  return { at: Date.now(), cycle: { active: !!st.active, index: st.index, total: st.total, group: st.currentGroup || "" },
    nextVisitAt: alarm?.scheduledTime || null, sleepingUntil: (await sleepWindow()) || null,
    visitingSince: sess.visitingSince || null, postingSince: sess.postingSince || null, snapshotSince: sess.snapshotSince || null,
    lastCheckAt: loc.lastCheckAt || null, lastReadAt: loc.lastReadAt || null, lastStopReason: loc.lastStopReason || null,
    lastCycleError: loc.lastCycleError || null, restrictedUntil: loc.fbRestrictedUntil || null, pausedByLicense: !!loc.pausedByLicense,
    pendingVisits: (loc.scanVisitsPending || []).length, retries: Object.keys(loc.retryQueue || {}).length, log: logRing.slice(-40) };
}

// "Report a problem" from the popup: the message, a picture of the tab and
// this computer's recent log, sent with the license key (feedback function).
async function sendFeedback({ kind, message, screenshot, tabUrl }) {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return { ok: false, error: "Sign in to the extension first" };
  const { monitoringOn, lastCheckAt, monitorGroups = [] } = await chrome.storage.local.get(["monitoringOn", "lastCheckAt", "monitorGroups"]);
  const safety = await getSafety().catch(() => ({}));
  const res = await fetch(`${BACKEND_URL}/feedback`, {
    method: "POST", headers: backendHeaders(),
    body: JSON.stringify({
      action: "send", licenseKey, kind, message, screenshot: screenshot || undefined,
      page: String(tabUrl || "").replace(/[?#].*$/, "").slice(0, 300), extVersion: chrome.runtime.getManifest().version, userAgent: navigator.userAgent,
      context: { log: logRing.slice(-150), monitoringOn: !!monitoringOn, lastCheckAt: lastCheckAt || 0, groups: monitorGroups.length,
        activeHours: `${safety.activeStartHour}-${safety.activeEndHour}`, cycle: await getCycleState().catch(() => null) },
    }),
  });
  const data = await res.json().catch(() => ({}));
  return res.ok ? { ok: true } : { ok: false, error: data.error || `Server error ${res.status}` };
}

// ─── Monitoring engine (group cycling) ────────────────────────────────────────
// Runs in the background so it continues when the dashboard closes. Whether
// monitoring is ON is remembered in chrome.storage.local, so it resumes by
// itself every time Chrome starts (it used to be forgotten on restart and
// silently stop). Per-run state — the monitor window/tab, position — is in
// chrome.storage.session, and each step is a chrome.alarms alarm, so it
// survives the worker being shut down between steps.
//
// Groups are visited in a dedicated "monitor window" (not minimized) rather than a
// tab mixed in with the customer's own tabs. Dwell per group is randomized
// within the safety limits, and monitoring pauses outside active hours.
// Key safety rule: NEVER navigate a window/tab the user is looking at.
const CATCH_UP_AFTER_MS = 6 * 60 * 60 * 1000;   // a group unseen this long gets a deeper scroll

async function getCycleState() {
  const { cycle } = await chrome.storage.session.get("cycle");
  return cycle || { active: false, windowId: null, tabId: null, index: 0, currentGroup: "", total: 0 };
}

async function setCycleState(patch) {
  const next = { ...(await getCycleState()), ...patch };
  await chrome.storage.session.set({ cycle: next });
  return next;
}

async function closeMonitorWindow(st) {
  const { monitorWindowId } = await chrome.storage.local.get("monitorWindowId");
  const winId = st.windowId || monitorWindowId;
  // Only the pop-up window is ours to close; a regular window (from before
  // 1.11.47) may hold the owner's own tabs by now, so only our tab goes.
  const win = Number.isInteger(winId) ? await chrome.windows.get(winId).catch(() => null) : null;
  if (win?.type === "popup") await chrome.windows.remove(winId).catch(() => {});
  else if (st.tabId) await chrome.tabs.remove(st.tabId).catch(() => {});
  await chrome.storage.local.remove("monitorWindowId");
}

// The state of the window a tab is in ("minimized", "normal", …; "" if
// unknown). From the tab itself: the saved window id can be missing after a
// restart, and chrome.windows.get(undefined) throws instead of rejecting
// (1.11.32: every visit on a new install failed with "No matching signature").
async function windowStateOfTab(tabId, fallbackWindowId) {
  try {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    const id = Number.isInteger(tab?.windowId) ? tab.windowId : fallbackWindowId;
    if (!Number.isInteger(id)) return "";
    const w = await chrome.windows.get(id).catch(() => null);
    return w?.state || "";
  } catch { return ""; }
}

// The one minimized window the extension works in (monitoring and posting).
// Its id is kept in local storage too, so an extension reload or a service
// worker restart reuses it instead of opening another window each time.
async function getMonitorWindow(st) {
  const { monitorWindowId } = await chrome.storage.local.get("monitorWindowId");
  for (const id of [st?.windowId, monitorWindowId]) {
    if (!Number.isInteger(id)) continue;
    const win = await chrome.windows.get(id, { populate: true }).catch(() => null);
    if (!win) continue;
    // A regular window from before 1.11.47: the owner may have tabs of their
    // own in it by now. Leave it to them; a pop-up window takes over.
    if (win.type !== "popup") {
      await chrome.storage.local.remove("monitorWindowId");
      await setCycleState({ windowId: null, tabId: null });
      return null;
    }
    return win;
  }
  return null;
}

// Not minimized (2026-09-29): Chrome doesn't draw a minimized window, so
// Facebook never built the feed and visits read nothing (the Scan log showed
// 0 posts, page hidden). A normal window that doesn't take focus: the owner
// can move it to a corner or a second screen, as long as part of it stays
// visible (or Chrome runs with --disable-backgrounding-occluded-windows).
// A pop-up window (2026-10-20): no tab strip or address bar, so the owner
// never browses in it, and Chrome never opens their new tabs or links there.
// It holds one tab, the extension's own; nothing else is ever navigated.
const MONITOR_WINDOW = { type: "popup", width: 1000, height: 820, focused: false, state: "normal" };
async function createMonitorWindow(url) {
  // Reopens where the owner last put it (e.g. on a second screen).
  const { monitorBounds } = await chrome.storage.local.get("monitorBounds");
  const b = monitorBounds && monitorBounds.width >= 400 && monitorBounds.height >= 300 ? monitorBounds : {};
  const win = await chrome.windows.create({ url, ...MONITOR_WINDOW, ...b })
    .catch(() => chrome.windows.create({ url, ...MONITOR_WINDOW }));   // that screen is gone: default spot
  await chrome.storage.local.set({ monitorWindowId: win.id });
  return win;
}

// Accounts with scanAllGroups (AnyoneNear's own) also visit the Groups feed,
// posts from every joined group mixed together, as one more stop in the
// cycle. It's Facebook's mix, not newest-first, so it adds coverage on top of
// the Watch list rather than replacing it.
const GROUPS_FEED = { name: "Groups feed", url: "https://www.facebook.com/groups/feed/", feed: true };
async function cycleStops() {
  const { monitorGroups = [] } = await chrome.storage.local.get("monitorGroups");
  const { scanAllGroups } = await chrome.storage.local.get("scanAllGroups");
  // Paused groups (switched off in the app) aren't visited at all.
  const on = monitorGroups.filter((g) => g && g.active !== false);
  return scanAllGroups === true ? [...on, GROUPS_FEED] : on;
}

async function startCycling() {
  const monitorGroups = await cycleStops();
  if (monitorGroups.length === 0) {
    log("Cycling: no groups configured");
    return;
  }
  await chrome.storage.local.set({ monitoringOn: true });
  await setCycleState({ active: true, index: 0, total: monitorGroups.length });
  log("Monitoring started —", monitorGroups.length, "groups");
  await cycleStep();
}

async function pauseForLicense() {
  const st = await getCycleState();
  await chrome.alarms.clear(CYCLE_ALARM);
  await closeMonitorWindow(st);
  await setCycleState({ active: false, windowId: null, tabId: null, currentGroup: "", paused: false });
  await chrome.storage.local.set({ pausedByLicense: true });
  log("Monitoring paused until the license works again");
  notifyDashboard({ type: "CYCLE_STATUS", active: false });
  updateActionStatus();
}

async function stopCycling() {
  const st = await getCycleState();
  await chrome.storage.local.set({ monitoringOn: false });
  await chrome.alarms.clear(CYCLE_ALARM);
  await closeMonitorWindow(st);
  await setCycleState({ active: false, windowId: null, tabId: null, currentGroup: "", paused: false });
  log("Monitoring stopped");
  notifyDashboard({ type: "CYCLE_STATUS", active: false });
  updateActionStatus();
}

// Load `url` in the monitor window, creating it (minimized, unfocused) if it
// doesn't exist. Returns the tab id, or null when the user is looking at the
// window right now (skip this round rather than yank the page from them).
async function loadInMonitorWindow(st, url) {
  let win = await getMonitorWindow(st);
  if (!win) {
    win = await createMonitorWindow(url);
    const tabId = win.tabs?.[0]?.id ?? null;
    await setCycleState({ windowId: win.id, tabId });
    return tabId;
  }
  if (win.id !== st.windowId) await setCycleState({ windowId: win.id });
  // Left minimized (by an older version, or by hand): bring it back without
  // taking focus, or Facebook won't load posts in it.
  if (win.state === "minimized") await chrome.windows.update(win.id, { state: "normal", focused: false }).catch(() => {});
  // In front and focused: someone is using it, unless nobody has touched the
  // computer for a while (then it's in front because we brought it there).
  if (win.focused && win.state !== "minimized" && (await userState()) === "active") {
    log("Monitor window is in use — skipping navigation this round");
    return null;
  }
  // Its own tab only (a pop-up window has one). Never another window's tab.
  const tabId = win.tabs?.find(t => t.id === st.tabId)?.id ?? win.tabs?.[0]?.id;
  if (!tabId) {
    const fresh = await createMonitorWindow(url);
    const id = fresh.tabs?.[0]?.id ?? null;
    await setCycleState({ windowId: fresh.id, tabId: id });
    return id;
  }
  await chrome.tabs.update(tabId, { url });
  if (tabId !== st.tabId) await setCycleState({ tabId });
  return tabId;
}

// Tooltip on the toolbar icon: is monitoring running, and when did it last check?
async function updateActionStatus(extra) {
  const st = await getCycleState();
  const { monitoringOn, lastCheckAt } = await chrome.storage.local.get(["monitoringOn", "lastCheckAt"]);
  const at = lastCheckAt ? new Date(lastCheckAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : "—";
  const title = !monitoringOn
    ? "AnyoneNear — monitoring paused. Open the dashboard to start."
    : st.paused
      ? "AnyoneNear — paused outside your active hours; resumes automatically."
      : `AnyoneNear — monitoring ${st.total || 0} group${st.total === 1 ? "" : "s"} · last check ${at}${extra ? " · " + extra : ""}`;
  chrome.action.setTitle({ title }).catch(() => {});
}

// Facebook signed the owner out or is limiting the account (2026-10-09).
// Restricted: no visits and no replies for 48 h (pushing on is how a warning
// becomes a ban); the owner can restart sooner with Start monitoring.
// Signed out: try again every 30 min and tell the owner.
const RESTRICT_PAUSE_MS = 48 * 3600_000;
async function facebookTrouble(kind) {
  const { fbTroubleWarnAt = 0 } = await chrome.storage.local.get("fbTroubleWarnAt");
  if (kind === "restricted") await chrome.storage.local.set({ fbRestrictedUntil: Date.now() + RESTRICT_PAUSE_MS });
  if (Date.now() - fbTroubleWarnAt < 3 * 3600_000) return;
  await chrome.storage.local.set({ fbTroubleWarnAt: Date.now() });
  log(kind === "restricted" ? "Facebook is limiting this account: pausing visits and replies for 48 hours" : "Facebook is signed out on this computer");
  chrome.notifications.create("an-fb-trouble", { type: "basic", iconUrl: "icons/icon128.png", priority: 2, requireInteraction: true,
    title: kind === "restricted" ? "AnyoneNear paused: Facebook is limiting your account" : "AnyoneNear: Facebook is signed out",
    message: kind === "restricted"
      ? "Facebook showed a warning or a checkpoint. AnyoneNear stopped checking groups and posting replies for 48 hours. Open Facebook in Chrome and clear any warning yourself."
      : "Sign back in to Facebook in Chrome on this computer (tick \"Keep me signed in\"). AnyoneNear tries again every 30 minutes." }, () => void chrome.runtime.lastError);
}
async function restrictedUntil() {
  const { fbRestrictedUntil = 0 } = await chrome.storage.local.get("fbRestrictedUntil");
  return fbRestrictedUntil > Date.now() ? fbRestrictedUntil : 0;
}

// When the next visit may happen if we're in the sleep window, else 0.
const SLEEP_START_MIN = 30, SLEEP_END_H = 5, SLEEP_END_MIN = 30;   // 00:30 .. 05:30 local
async function sleepWindow(d = new Date()) {
  const { storm } = await chrome.storage.local.get("storm");
  if (storm && Date.parse(storm.until) > Date.now()) return 0;   // storm mode: keep watching
  const mins = d.getHours() * 60 + d.getMinutes();
  const start = SLEEP_START_MIN, end = SLEEP_END_H * 60 + SLEEP_END_MIN;
  if (mins < start || mins >= end) return 0;
  const wake = new Date(d); wake.setHours(SLEEP_END_H, SLEEP_END_MIN + rand(0, 25), rand(0, 59), 0);
  return wake.getTime();
}

async function cycleStep() {
  let st = await getCycleState();
  if (!st.active) return;
  // Fallback first (2026-10-09): if this visit dies part-way (service worker
  // killed, a throw outside the try), the cycle still continues in 15 min.
  // The normal reschedule at the end replaces it.
  chrome.alarms.create(CYCLE_ALARM, { when: Date.now() + 15 * 60_000 });
  const pausedTill = await restrictedUntil();
  if (pausedTill) { chrome.alarms.create(CYCLE_ALARM, { when: pausedTill + 60_000 }); return; }
  // A demand snapshot is using the window: visit again when it's done.
  const { snapshotSince } = await chrome.storage.session.get("snapshotSince");
  if (snapshotSince && Date.now() - snapshotSince < 20 * 60_000) { chrome.alarms.create(CYCLE_ALARM, { when: Date.now() + 5 * 60_000 }); return; }

  const groups = await cycleStops();
  if (groups.length === 0) { await stopCycling(); return; }

  const s = await getSafety();
  // Groups are checked around the clock (2026-09-30): leads posted at night,
  // or approved late by a group admin, are found by morning. Outside active
  // hours each group is visited about every 45 minutes instead of back to
  // back, and replies wait for active hours (scheduleQueue).
  const night = !inActiveHours(s);

  // Sleep window (2026-10-12): no visits between about 00:30 and 05:30 local,
  // unless storm mode is on. A personal account reading groups every night
  // at 3 a.m. is a strong automation signal; posts made then are read first
  // thing in the morning anyway.
  // (Not named "sleep": that shadowed sleep() below and every regular visit
  // threw "sleep is not a function" right after the page loaded, 1.11.24-31.)
  const wakeAt = await sleepWindow();
  if (wakeAt) {
    await chrome.storage.session.remove("visitingSince").catch(() => {});
    chrome.alarms.create(CYCLE_ALARM, { when: wakeAt });
    updateActionStatus("sleeping until morning");
    return;
  }

  // A reply is being posted in the monitor window: visit groups after it.
  const { postingSince } = await chrome.storage.session.get("postingSince");
  if (postingSince && Date.now() - postingSince < 3 * 60_000) {
    chrome.alarms.create(CYCLE_ALARM, { when: Date.now() + 45_000 });
    return;
  }

  const index = st.index % groups.length;
  // A group whose last visit stalled behind other windows goes first once
  // nobody's using the computer (catch-up); the regular rotation then resumes
  // where it was.
  const catchUp = await catchUpPick(groups);
  const group = catchUp || groups[index];
  st = await setCycleState({ index, total: groups.length, currentGroup: group.name || group.url, paused: false });

  log(`Cycling to: ${st.currentGroup} (${index + 1}/${groups.length})`);
  notifyDashboard({ type: "CYCLE_STATUS", active: true, groupName: st.currentGroup, index, total: groups.length });

  try {
    await chrome.storage.session.set({ visitingSince: Date.now() });
    const navigated = await loadInMonitorWindow(st, group.feed ? group.url : newestFirst(group.url));
    await keepScanning(navigated);
    if (catchUp && Number.isInteger(navigated) && (await userState()) !== "active" && !(await neverBringForward())) {
      log(`Catching up on ${group.name || group.url}: its last visit stalled behind other windows`);
      const winId = (await chrome.tabs.get(navigated).catch(() => null))?.windowId;
      if (Number.isInteger(winId)) await chrome.windows.update(winId, { state: "normal", focused: true }).catch(() => {});
    }

    // Once the group has loaded, have the page scroll slowly through the feed
    // so more than the first few posts get read — and further back when the
    // group hasn't been checked for a while (Chrome was closed overnight), so
    // the first visit of the day catches up on what was posted meanwhile.
    if (navigated) {
      const { groupVisits = {} } = await chrome.storage.local.get("groupVisits");
      const last = groupVisits[group.url] || 0;
      await waitForTabComplete(navigated, 30_000);
      await sleep(rand(3000, 6000));
      const winState = await windowStateOfTab(navigated, st.windowId);
      const away = (await userState()) !== "active";   // the window may be in front because we brought it there
      // Once a day per group, scroll back about 2 days past "caught up", for
      // posts a group admin approved hours after they were written.
      const { groupDeepAt = {} } = await chrome.storage.local.get("groupDeepAt");
      // Not on the Groups feed: it isn't newest-first, so there's no "2 days back" to reach.
      const deep = !group.feed && Date.now() - (groupDeepAt[group.url] || 0) > 20 * 3600_000;
      const { groupBookmarks = {} } = await chrome.storage.local.get("groupBookmarks");
      const bookmark = group.feed ? null : groupBookmarks[group.url] || null;
      let visit = await runVisit(navigated, group, winState, { away, deep, bookmark, catchUp: !!catchUp });
      // Facebook said "This content isn't available": try the plain group
      // link once (it has rejected the newest-first setting in the link).
      if (visit.stopReason === "unavailable" && /sorting_setting=/.test(newestFirst(group.url))) {
        await chrome.tabs.update(navigated, { url: group.url });
        await waitForTabComplete(navigated, 30_000);
        await sleep(rand(3000, 5000));
        visit = await runVisit(navigated, { ...group, plainLink: true }, winState, { away, deep, bookmark, catchUp: !!catchUp });
      }
      // Hidden window, nothing read. If nobody is using the computer, bring
      // the window to the front (it's in no one's way) and read the group
      // again. If someone is, or the screen is locked, just note it.
      if (hiddenAndEmpty(visit) || stalledHidden(visit)) {
        const who = await userState();
        if (who === "idle" && !(await neverBringForward())) {
          log("Window hidden and nobody's at the computer: bringing it to the front");
          const winId = (await chrome.tabs.get(navigated).catch(() => null))?.windowId ?? st.windowId;
          if (Number.isInteger(winId)) await chrome.windows.update(winId, { state: "normal", focused: true }).catch(() => {});
          await chrome.tabs.reload(navigated).catch(() => {});
          await waitForTabComplete(navigated, 30_000);
          await sleep(rand(3000, 5000));
          visit = await runVisit(navigated, group, "brought to front", { away: true, bookmark, catchUp: !!catchUp });
        } else if (who === "locked") {
          visit.windowState = "screen locked";
        }
        if (hiddenAndEmpty(visit)) await warnHidden(who);
      }
      // Bookmark: moves forward only when this visit reached the old one (or
      // had none and caught up the old way). A visit that stopped short (scroll
      // limit, Facebook stopped loading, error) keeps it, and the group is
      // caught up next, from the same bookmark, so nothing in between is skipped.
      // (Read 2 days back, past the age limit, or to the end: complete either way.)
      const complete = ["deep_done", "old_posts", "end_of_feed"].includes(visit.stopReason)
        || (visit.stopReason === "caught_up" && (!bookmark || visit.reachedBookmark || visit.bookmarkLost));
      if (complete && visit.newest && !group.feed) await updateStore("groupBookmarks", (m) => {
        const out = m && typeof m === "object" ? m : {};
        if (!out[group.url] || (visit.newest.at || 0) >= (out[group.url].at || 0)) out[group.url] = { ...visit.newest, savedAt: Date.now() };
        return out;
      }, {});
      const hiddenStall = stalledHidden(visit) || hiddenAndEmpty(visit);
      const shortStop = !complete && !["unavailable", "not_watched", "logged_out", "restricted", "in_use"].includes(visit.stopReason);
      await markCatchUp(group, hiddenStall || shortStop, hiddenStall, !!catchUp);
      await updateStore("groupVisits", (v) => { v[group.url] = Date.now(); return v; }, {});
      if (deep && ["deep_done", "end_of_feed", "cap"].includes(visit.stopReason)) await updateStore("groupDeepAt", (v) => { v[group.url] = Date.now(); return v; }, {});
      await chrome.storage.local.set({ lastCheckAt: Date.now(), ...(visit.newPosts + visit.seenPosts > 0 ? { lastReadAt: Date.now() } : {}), lastStopReason: visit.stopReason });
      // A visit that read posts: an old error isn't news any more (2026-10-17).
      if (visit.newPosts + visit.seenPosts > 0) await chrome.storage.local.remove("lastCycleError");
      if (visit.stopReason === "restricted" || visit.stopReason === "logged_out") {
        await facebookTrouble(visit.stopReason);
        await chrome.storage.session.remove("visitingSince").catch(() => {});
        chrome.alarms.create(CYCLE_ALARM, { when: visit.stopReason === "restricted" ? Date.now() + RESTRICT_PAUSE_MS : Date.now() + 30 * 60_000 });
        updateActionStatus();
        return;
      }
      log(`Visited ${st.currentGroup}: ${visit.newPosts} new post(s), ${visit.steps} scroll(s), ${visit.stopReason}${last ? `, last visit ${Math.round((Date.now() - last) / 60000)} min ago` : ""}`);
    } else {
      // Skipped (the window looked in use): record it for the Scan log, at
      // most once an hour, so a computer that keeps skipping isn't silent.
      const { skipLoggedAt = 0 } = await chrome.storage.local.get("skipLoggedAt");
      if (Date.now() - skipLoggedAt > 3600_000) {
        await chrome.storage.local.set({ skipLoggedAt: Date.now() });
        await updateStore("scanVisitsPending", (q) => [...(Array.isArray(q) ? q : []), { group: group.name || group.url, url: group.url, startedAt: Date.now(),
          steps: 0, newPosts: 0, seenPosts: 0, matches: 0, stopReason: "in_use", windowState: "focused", pageHidden: null, heightGrowth: 0, version: chrome.runtime.getManifest().version }].slice(-200), []);
        uploadScanLog().catch(() => {});
      }
    }
  } catch (err) {
    log("Cycle error:", err.message);
    await setCycleState({ windowId: null, tabId: null });
    // Recorded like a visit (Scan log, admin), so a visit that keeps failing
    // shows up instead of looking like a quiet group.
    await updateStore("scanVisitsPending", (q) => [...(Array.isArray(q) ? q : []), { group: group?.name || group?.url || "", url: group?.url || "", startedAt: Date.now(),
      steps: 0, newPosts: 0, seenPosts: 0, matches: 0, stopReason: "interrupted", error: String(err.message || err).slice(0, 200), windowState: "", pageHidden: null, heightGrowth: 0,
      version: chrome.runtime.getManifest().version }].slice(-200), []).catch(() => {});
    await chrome.storage.local.set({ lastCycleError: { at: Date.now(), message: String(err.message || err).slice(0, 200) } });
  }
  await chrome.storage.session.remove("visitingSince").catch(() => {});
  updateActionStatus();

  await setCycleState({ index: catchUp ? index : index + 1 });
  // At night: about every 45 minutes per group (spread across the groups).
  let gapSec = night ? Math.max(rand(s.dwellMinSec, s.dwellMaxSec), (45 * 60 / groups.length) * rand(0.8, 1.2)) : rand(s.dwellMinSec, s.dwellMaxSec);
  if (!night && (await catchUpPick(groups))) gapSec = rand(45, 90);
  if (!night && Math.random() < 0.06) { gapSec += rand(15, 40) * 60; log(`Taking a break: next visit in ${Math.round(gapSec / 60)} min`); }
  chrome.alarms.create(CYCLE_ALARM, { when: Date.now() + gapSec * 1000 });
}

// ─── One group visit ──────────────────────────────────────────────────────────
// Scroll the newest-first feed until it reaches posts it saw on an earlier
// visit ("caught up"), the feed ends, Facebook stops loading more, or the cap.
// The loop runs here, not in the page: Chrome slows timers in pages it isn't
// showing (a minimized monitor window), which used to cut visits short. Each
// visit is recorded for the app's Scan log (scan-log function).
const MAX_SCROLLS = 40;
const DEEP_SCROLLS = 80;        // the daily deep check
const DEEP_HOURS = 48;          // how far back it reads
async function runVisit(tabId, group, windowState, opts = {}) {
  const t0 = Date.now();
  const v = { group: group.name || group.url, url: group.url, startedAt: t0, steps: 0, newPosts: 0, seenPosts: 0, matches: 0,
    oldPosts: 0, skippedOld: 0, skippedWords: 0, deep: !!opts.deep, stopReason: "cap", windowState, pageHidden: null, heightGrowth: 0, version: chrome.runtime.getManifest().version,
    qualityPosts: 0, noAuthor: 0, noUrl: 0, noTime: 0, noText: 0 };
  let startHeight = null, lastHeight = null, flat = 0, startOld = null, dry = 0, oldRun = 0;
  for (let i = 0; i <= (opts.deep || opts.catchUp ? DEEP_SCROLLS : MAX_SCROLLS); i++) {
    const r = await sendToTab(tabId, { type: "SCAN_STEP", scroll: i > 0, first: i === 0, label: group.name || "", away: !!opts.away, bookmark: opts.bookmark || null });
    if (!r || !r.ok) { v.stopReason = ["not_watched", "unavailable", "logged_out", "restricted"].includes(r?.reason) ? r.reason : "interrupted"; break; }
    if (i > 0) v.steps++;
    v.newPosts += r.newPosts; v.matches += r.matches; v.pageHidden = r.hidden; v.seenPosts = r.oldSeen;
    v.oldPosts += r.oldPosts || 0; v.skippedOld += r.skippedOld || 0; v.skippedWords += r.skippedWords || 0;
    for (const k of ["noAuthor", "noUrl", "noTime", "noText"]) v[k] += r.quality?.[k] || 0;
    v.qualityPosts += r.quality?.posts || 0;   // posts only, not comments (1.11.42)
    if (r.newest && (!v.newest || r.newest.at > v.newest.at)) v.newest = r.newest;
    if (opts.bookmark && (r.bookmarkSeen || r.olderThanBookmark >= 2)) v.reachedBookmark = true;
    if (startHeight === null) { startHeight = r.height; startOld = r.oldSeen; }
    v.heightGrowth = Math.max(0, r.height - startHeight);
    // Caught up: at least 3 screens read, the last 2 brought nothing new, and
    // more posts from earlier visits have come into view since the top (so
    // it's reached what it already read, not just a pinned post or two).
    dry = i > 0 && r.newPosts === 0 ? dry + 1 : 0;
    // Deep check: keep going past "caught up" until the posts are ~2 days old.
    if (opts.deep) { if (i >= 3 && r.oldestAgeH != null && r.oldestAgeH >= DEEP_HOURS) { v.stopReason = "deep_done"; break; } }
    // With a bookmark: caught up once it's reached (one screen past it), or,
    // if it can't be found (no dates, deleted), after 4 screens of nothing new.
    else if (opts.bookmark) {
      if (v.reachedBookmark && i >= 1) { v.stopReason = "caught_up"; break; }
      if (i >= 3 && dry >= 4 && r.oldSeen >= startOld + 3) { v.stopReason = "caught_up"; v.bookmarkLost = true; break; }
    }
    else if (i >= 3 && dry >= 2 && r.oldSeen >= startOld + 3) { v.stopReason = "caught_up"; break; }
    // Reached posts older than the age limit: everything further down is older still.
    oldRun = r.newPosts > 0 && r.oldPosts >= r.newPosts ? oldRun + r.oldPosts : r.newPosts > 0 ? 0 : oldRun;
    // The Groups feed mixes old and new posts, so old ones don't mean the end.
    if (!group.feed && i >= 1 && oldRun >= 4) { v.stopReason = "old_posts"; break; }
    flat = lastHeight !== null && r.height <= lastHeight ? flat + 1 : 0;
    lastHeight = r.height;
    if (flat >= 3) { v.stopReason = v.heightGrowth < 300 ? "not_loading" : "end_of_feed"; break; }
    await sleep(rand(2500, 5000));   // a human-ish reading pause, timed here (not throttled)
  }
  await sendToTab(tabId, { type: "SCAN_DONE" });
  v.seconds = Math.round((Date.now() - t0) / 1000);
  await updateStore("scanVisitsPending", (q) => [...(Array.isArray(q) ? q : []), v].slice(-200), []);
  uploadScanLog().catch(() => {});
  return v;
}

// "Never bring the AnyoneNear window to the front" (toolbar popup, this
// browser only; off by default: bringing it forward keeps scans reading for
// owners who forget it's running and work on top of it).
async function neverBringForward() {
  const { noBringForward } = await chrome.storage.local.get("noBringForward");
  return noBringForward === true;
}
const hiddenAndEmpty = (v) => v.pageHidden === true && v.newPosts === 0 && !["unavailable", "not_watched"].includes(v.stopReason);
// Covered and stalled (2026-10-18): the window was hidden behind other
// windows, so the visit read the first screen and then Facebook stopped
// loading. It counted as a good visit before, so busy groups lost every post
// below the first screen while the owner was working.
const stalledHidden = (v) => v.pageHidden === true && v.stopReason === "not_loading";

// Catch-ups: groups whose last visit stalled behind other windows, visited
// first (window brought to the front) as soon as nobody's using the computer.
// Older than 3 hours: dropped, the regular visit has covered it by then.
// A visit that stopped short for another reason (scroll limit, Facebook
// stopped loading on a visible window, an error) is caught up on the very
// next visit, whoever's at the computer (1.11.45).
const catchUpAt = (e) => (typeof e === "number" ? e : e?.at || 0);
// Two catch-up tries per group, then it's dropped so one group that keeps
// failing can't hold up the others (the hourly health check reports it).
async function markCatchUp(group, needed, hidden = false, wasCatchUp = false) {
  await updateStore("catchUpGroups", (m) => {
    const out = m && typeof m === "object" ? m : {};
    const prev = out[group.url];
    const tries = (typeof prev === "object" && prev?.tries || 0) + (wasCatchUp ? 1 : 0);
    if (needed && tries < 2) out[group.url] = { at: catchUpAt(prev) || Date.now(), hidden: !!hidden, tries }; else delete out[group.url];
    return out;
  }, {});
}
async function catchUpPick(groups) {
  const { catchUpGroups = {} } = await chrome.storage.local.get("catchUpGroups");
  const fresh = Object.entries(catchUpGroups).filter(([, e]) => Date.now() - catchUpAt(e) < 3 * 3600_000).sort((a, b) => catchUpAt(a[1]) - catchUpAt(b[1]));
  if (!fresh.length) return null;
  const someoneThere = (await userState()) === "active";
  const ready = fresh.filter(([, e]) => !someoneThere || !(typeof e === "number" || e?.hidden));
  const urls = new Set(ready.map(([u]) => u));
  return groups.find((g) => urls.has(g.url)) || null;
}
// The owner stepped away: start the catch-ups within a minute instead of
// waiting for the next regular visit.
try { chrome.idle.setDetectionInterval(120); } catch { /* fine */ }
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state !== "idle") return;
  const st = await getCycleState();
  if (!st.active) return;
  const groups = await cycleStops();
  if (!(await catchUpPick(groups))) return;
  const { visitingSince } = await chrome.storage.session.get("visitingSince");
  if (visitingSince && Date.now() - visitingSince < 5 * 60_000) return;   // a visit is running; the gap after it is short
  const alarm = await chrome.alarms.get(CYCLE_ALARM);
  if (!alarm || alarm.scheduledTime > Date.now() + 60_000) chrome.alarms.create(CYCLE_ALARM, { when: Date.now() + rand(20, 50) * 1000 });
});

// "active" (someone used the mouse or keyboard in the last 4 minutes), "idle"
// or "locked" (Windows lock screen).
async function userState() {
  try { return await chrome.idle.queryState(240); } catch { return "active"; }
}

// Hidden window, nothing read: tell the owner (at most every 3 hours).
async function warnHidden(who) {
  const { hiddenWarnAt = 0 } = await chrome.storage.local.get("hiddenWarnAt");
  if (Date.now() - hiddenWarnAt < 3 * 3600_000) return;
  await chrome.storage.local.set({ hiddenWarnAt: Date.now() });
  chrome.notifications.create("an-hidden", { type: "basic", iconUrl: "icons/icon128.png", title: "AnyoneNear can't read your groups",
    message: who === "locked"
      ? "The screen is locked, so Facebook isn't loading posts. On a computer used for monitoring, turn off the automatic lock."
      : "The AnyoneNear window is hidden or minimized, so Facebook isn't loading posts. Move it to a corner or another screen and keep part of it visible." }, () => void chrome.runtime.lastError);
}

// Sends recorded visits (and, once, the older local history of AI checks) to
// the server for the app's Scan log. At most every 5 minutes.
let lastScanUpload = 0;
async function uploadScanLog(force = false) {
  if (!force && Date.now() - lastScanUpload < 5 * 60_000) return;
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return;
  const { scanVisitsPending = [], scanHistorySent, activityLog = [] } = await chrome.storage.local.get(["scanVisitsPending", "scanHistorySent", "activityLog"]);
  const history = scanHistorySent ? [] : activityLog;
  if (!scanVisitsPending.length && !history.length) return;
  lastScanUpload = Date.now();
  const res = await fetch(`${BACKEND_URL}/scan-log`, {
    method: "POST", headers: backendHeaders(),
    body: JSON.stringify({ licenseKey, deviceId: await getDeviceId(), visits: scanVisitsPending.slice(0, 100), history }),
  });
  if (!res.ok) return;
  const sent = scanVisitsPending.length;
  await updateStore("scanVisitsPending", (q) => (Array.isArray(q) ? q.slice(Math.min(sent, 100)) : []), []);
  if (!scanHistorySent) await chrome.storage.local.set({ scanHistorySent: true });
}

// Open group feeds sorted newest-first, so each visit sees fresh posts rather
// than FB's "most relevant" mix. Leaves URLs that already choose a sort alone.
function newestFirst(groupUrl) {
  try {
    const u = new URL(groupUrl);
    if (!u.searchParams.has("sorting_setting")) u.searchParams.set("sorting_setting", "CHRONOLOGICAL");
    return u.toString();
  } catch {
    return groupUrl;
  }
}

// If the user closes the monitor window, the next step reopens it (minimized).
// Monitoring is paused from the dashboard or popup, not by closing the window.
// Remember where the owner moves or resizes the monitor window.
chrome.windows.onBoundsChanged?.addListener(async (win) => {
  const st = await getCycleState();
  if (win.id !== st.windowId || win.state !== "normal") return;
  await chrome.storage.local.set({ monitorBounds: { left: win.left, top: win.top, width: win.width, height: win.height } });
});

chrome.windows.onRemoved.addListener(async (windowId) => {
  const st = await getCycleState();
  if (windowId === st.windowId) {
    log("Monitor window closed — it will reopen on the next check");
    await setCycleState({ windowId: null, tabId: null });
  }
});

function notifyDashboard(data) {
  // Send status to dashboard tab if open — non-critical, ignore errors
  chrome.runtime.sendMessage(data).catch(() => {});
  // runtime.sendMessage never reaches content scripts, so the on-page bubble
  // watches this stamp instead to refresh its Monitoring section.
  if (data?.type === "CYCLE_STATUS") chrome.storage.local.set({ cycleStamp: Date.now() }).catch(() => {});
}

// ─── Heartbeat ────────────────────────────────────────────────────────────────
// Hourly check-in so the backend knows this monitor is alive, whether it's
// switched on, and when it last checked a group. usage-sync turns that into
// the customer's "AnyoneNear Monitor Status" in GHL, which drives an "your monitor is
// offline" reminder workflow.
// Watchdog (2026-10-09): monitoring was "on" for a week with no group visits
// (the cycle's alarm had gone, the hourly heartbeat kept reporting fine). If
// monitoring is on but no visit is scheduled or running, start the cycle again.
async function cycleWatchdog() {
  const { monitoringOn } = await chrome.storage.local.get("monitoringOn");
  if (!monitoringOn) return;
  const { licenseStatus } = await chrome.storage.local.get("licenseStatus");
  if (licenseStatus !== "active") return;
  const [alarm, { visitingSince }, { postingSince }] = await Promise.all([
    chrome.alarms.get(CYCLE_ALARM), chrome.storage.session.get("visitingSince"), chrome.storage.session.get("postingSince")]);
  const busy = (visitingSince && Date.now() - visitingSince < 15 * 60_000) || (postingSince && Date.now() - postingSince < 5 * 60_000);
  if (alarm || busy) return;
  log("Watchdog: monitoring is on but no visit was scheduled; restarting the cycle");
  await startCycling();
}

// ─── Demand snapshot (2026-10-15) ─────────────────────────────────────────────
// Searches a watched group for each of the business's services (Facebook's
// search inside a group reaches back about a year), reads the dated results
// and sends them to group-snapshot, which counts the people who were looking
// to hire. Each group once, when it's new (one group per 3 hours at most), or
// all groups when the owner taps "Estimate demand". Pauses between searches
// like a person would; the regular visits wait until it's done.
const SNAPSHOT_EVERY_MS = 90 * 86400_000;
function groupBase(url) {
  const m = String(url || "").match(/^(https:\/\/www\.facebook\.com\/groups\/[^/?#]+)/);
  return m ? m[1] + "/" : null;
}
async function snapshotTerms(licenseKey) {
  const res = await fetch(`${BACKEND_URL}/group-snapshot`, { method: "POST",
    headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }), body: JSON.stringify({ action: "terms" }) });
  const data = await res.json().catch(() => ({}));
  return Array.isArray(data.terms) ? data.terms.slice(0, 6) : [];
}
// Progress of the estimate the owner started, for the app (SNAPSHOT_STATUS).
async function snapStatus(patch) {
  const { snapshotStatus = {} } = await chrome.storage.local.get("snapshotStatus");
  await chrome.storage.local.set({ snapshotStatus: { ...snapshotStatus, ...patch, at: Date.now() } });
}
async function snapshotGroup(group, terms, licenseKey, gi = 0, gn = 1) {
  const base = groupBase(group.url);
  if (!base || !terms.length) return { ok: false, error: "Nothing to search for" };
  const posts = [];
  for (const [i, term] of terms.entries()) {
    await chrome.storage.session.set({ snapshotSince: Date.now(), visitingSince: Date.now() });
    await snapStatus({ state: "running", message: `Searching ${group.name || "group"} (${gi + 1} of ${gn}) for "${term}" (${i + 1} of ${terms.length})` });
    const st = await getCycleState();
    const tabId = await loadInMonitorWindow(st, `${base}search/?q=${encodeURIComponent(term)}`);
    if (!tabId) return { ok: false, error: "The AnyoneNear window is in use" };
    await waitForTabComplete(tabId, 30_000);
    await sleep(rand(3000, 5000));
    const r = await chrome.tabs.sendMessage(tabId, { type: "SNAPSHOT_READ", steps: 4 }).catch(() => null);
    if (r?.reason === "restricted" || r?.reason === "logged_out") { await facebookTrouble(r.reason); return { ok: false, error: "Facebook needs attention" }; }
    for (const p of r?.posts || []) posts.push(p);
    if (i < terms.length - 1) await wakefulSleep(rand(15_000, 35_000));
  }
  const res = await fetch(`${BACKEND_URL}/group-snapshot`, { method: "POST",
    headers: backendHeaders({ "Authorization": `Bearer ${licenseKey}` }),
    body: JSON.stringify({ action: "submit", group: { url: group.url, name: group.name || "" }, terms, posts }) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return { ok: false, error: data.error || `Server error ${res.status}` };
  const { snapshotDoneAt = {} } = await chrome.storage.local.get("snapshotDoneAt");
  snapshotDoneAt[group.url] = Date.now();
  await chrome.storage.local.set({ snapshotDoneAt });
  log(`Snapshot ${group.name || group.url}: ${data.buyerPosts} requests in ${data.found} posts, ~${data.perMonth}/month`);
  return { ok: true, group: group.name || group.url, ...data };
}
// "all": every watched group (the owner asked); otherwise the first group
// that has none yet, when the computer isn't busy.
async function snapshotGroups(all = false) {
  if (await restrictedUntil()) return { ok: false, error: "Facebook is limiting this account right now" };
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  if (licenseStatus !== "active" || !licenseKey) return { ok: false, error: "Sign this computer in first" };
  const { visitingSince, postingSince, snapshotSince } = await chrome.storage.session.get(["visitingSince", "postingSince", "snapshotSince"]);
  if (snapshotSince && Date.now() - snapshotSince < 20 * 60_000) return { ok: false, error: "An estimate is already running." };
  // A regular visit or a reply in progress: wait for it (up to 10 minutes)
  // instead of giving up; the owner asked for this.
  if (all) await snapStatus({ state: "running", message: "Waiting for the current group visit to finish…", started: Date.now() });
  for (let w = 0; w < 120; w++) {
    const s = await chrome.storage.session.get(["visitingSince", "postingSince"]);
    const busy = (s.visitingSince && Date.now() - s.visitingSince < 10 * 60_000) || (s.postingSince && Date.now() - s.postingSince < 5 * 60_000);
    if (!busy) break;
    if (!all) return { ok: false, error: "busy" };
    await sleep(5000);
  }
  const { snapshotDoneAt = {} } = await chrome.storage.local.get("snapshotDoneAt");
  const groups = (await cycleStops()).filter((g) => !g.feed && groupBase(g.url));
  const todo = all ? groups : groups.filter((g) => !snapshotDoneAt[g.url] || Date.now() - snapshotDoneAt[g.url] > SNAPSHOT_EVERY_MS).slice(0, 1);
  if (!todo.length) return { ok: true, results: [] };
  const terms = await snapshotTerms(licenseKey).catch(() => []);
  if (!terms.length) return { ok: false, error: "Pick your services first (Watch → Keywords in the app)" };
  const results = [];
  try {
    for (const [gi, g] of todo.entries()) {
      const r = await snapshotGroup(g, terms, licenseKey, gi, todo.length).catch((e) => ({ ok: false, error: e.message }));
      results.push(r);
      if (!r.ok && /Facebook needs attention|in use/.test(r.error || "")) break;
    }
  } finally {
    await chrome.storage.session.remove(["snapshotSince", "visitingSince"]).catch(() => {});
  }
  const done = results.filter((r) => r.ok);
  if (all) {
    const failed = results.find((r) => !r.ok);
    await snapStatus(done.length ? { state: "done", message: `Done: ${done.length} of ${todo.length} group${todo.length === 1 ? "" : "s"} estimated.${failed ? ` One stopped: ${failed.error}` : ""}` }
      : { state: "error", message: failed?.error || "Nothing could be estimated" });
    if (!done.length) chrome.notifications.create(`snap_${Date.now()}`, { type: "basic", iconUrl: "icons/icon128.png", priority: 1,
      title: "AnyoneNear: demand estimate stopped", message: failed?.error || "Nothing could be estimated" }, () => void chrome.runtime.lastError);
  }
  if (all && done.length) {
    const total = Math.round(done.reduce((s, r) => s + (r.perMonth || 0), 0) * 10) / 10;
    chrome.notifications.create(`snap_${Date.now()}`, { type: "basic", iconUrl: "icons/icon128.png", priority: 1,
      title: "AnyoneNear: demand estimate ready",
      message: `About ${total} people a month asked for what you do in ${done.length} group${done.length === 1 ? "" : "s"} over the past year. Details are in the app (Watch → Groups).` }, () => void chrome.runtime.lastError);
  }
  return { ok: true, results };
}
async function maybeAutoSnapshot() {
  const { monitoringOn, autoSnapshotAt = 0 } = await chrome.storage.local.get(["monitoringOn", "autoSnapshotAt"]);
  if (!monitoringOn || Date.now() - autoSnapshotAt < 3 * 3600_000 || (await sleepWindow())) return;
  await chrome.storage.local.set({ autoSnapshotAt: Date.now() });
  await snapshotGroups(false);
}

// Commands from the server (2026-10-13):
//   restartCycle — it saw monitoring on but nothing read for 2 hours
//   testVisit    — the owner tapped "Test it now" on their phone
async function handleCommands(data) {
  if (!data) return;
  const { monitoringOn } = await chrome.storage.local.get("monitoringOn");
  if (data.restartCycle && monitoringOn && !(await restrictedUntil()) && !(await sleepWindow())) {
    const { visitingSince } = await chrome.storage.session.get("visitingSince");
    if (!visitingSince || Date.now() - visitingSince > 15 * 60_000) {
      log("Server: nothing read for 2 hours, restarting the cycle");
      await chrome.alarms.clear(CYCLE_ALARM);
      await startCycling();
    }
  }
  if (data.testVisit) {
    log("Test visit requested from the app");
    await testVisit();
  }
  if (data.snapshotGroups) {
    log("Demand estimate requested from the app");
    await snapshotGroups(true);
  }
}

// "Test it now" (from the app on this computer, or from the phone): one
// visit, then a notification with the result. The visit window is usually in
// front while it runs, so the app's own message is easy to miss.
const TEST_WHY = { caught_up: "it's up to date", end_of_feed: "it reached the end of the group", cap: "it read as far as it goes", not_loading: "Facebook stopped loading more", unavailable: "Facebook says the group isn't available", logged_out: "Facebook is signed out in this Chrome", restricted: "Facebook is limiting the account", interrupted: "it was interrupted", old_posts: "it reached older posts" };
async function testVisit() {
  const r = await runTestVisit().catch((e) => ({ ok: false, error: e.message }));
  const message = !r.ok ? r.error
    : r.read > 0 ? `Read ${r.read} posts in ${r.group} in ${r.seconds}s (${r.newPosts} new, ${r.matches} matched your keywords).`
    : `Opened ${r.group} but read nothing: ${TEST_WHY[r.stopReason] || r.stopReason}.${r.hidden ? " Keep part of the AnyoneNear window on screen." : ""}`;
  chrome.notifications.create(`test_${Date.now()}`, { type: "basic", iconUrl: "icons/icon128.png", priority: 2,
    title: r.ok && r.read > 0 ? "AnyoneNear test: working ✓" : "AnyoneNear test: needs a look", message }, () => void chrome.runtime.lastError);
  return r;
}

// One visit now, to the first watched group. Recorded in the Scan log like
// any visit (marked as a test).
async function runTestVisit() {
  if (await restrictedUntil()) return { ok: false, error: "Facebook is limiting this account right now, so AnyoneNear is paused. Open Facebook in Chrome and clear any warning first." };
  const { licenseStatus } = await chrome.storage.local.get("licenseStatus");
  if (licenseStatus !== "active") return { ok: false, error: "Sign this computer in first" };
  const groups = (await cycleStops()).filter((g) => !g.feed);
  if (!groups.length) return { ok: false, error: "Add a group to watch first" };
  const { visitingSince, postingSince } = await chrome.storage.session.get(["visitingSince", "postingSince"]);
  if ((visitingSince && Date.now() - visitingSince < 10 * 60_000) || (postingSince && Date.now() - postingSince < 5 * 60_000))
    return { ok: false, error: "Your computer is checking a group right now. Look at the Scan log in a few minutes." };
  const group = groups[0];
  await chrome.storage.session.set({ visitingSince: Date.now() });
  try {
    const st = await getCycleState();
    const tabId = await loadInMonitorWindow(st, newestFirst(group.url));
    if (!tabId) return { ok: false, error: "The AnyoneNear window is in use on that computer. Try again in a minute." };
    await waitForTabComplete(tabId, 30_000);
    await sleep(rand(3000, 5000));
    const st2 = await getCycleState();
    const winState = await windowStateOfTab(tabId, st2.windowId);
    const v = await runVisit(tabId, { ...group, test: true }, winState, { away: (await userState()) !== "active" });
    if (v.newPosts + v.seenPosts > 0) await chrome.storage.local.set({ lastReadAt: Date.now(), lastCheckAt: Date.now() });
    if (v.stopReason === "restricted" || v.stopReason === "logged_out") await facebookTrouble(v.stopReason);
    return { ok: true, group: group.name || group.url, read: v.newPosts + v.seenPosts, newPosts: v.newPosts, matches: v.matches, stopReason: v.stopReason, seconds: v.seconds, hidden: v.pageHidden === true };
  } finally {
    await chrome.storage.session.remove("visitingSince").catch(() => {});
  }
}

async function sendHeartbeat() {
  await recordUptime();
  await cycleWatchdog().catch((e) => log("Watchdog error:", e.message));
  let { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  // Refused earlier: ask again every hour instead of once a day (it used to
  // stay off until someone pasted the key again).
  if (licenseStatus === "invalid" && licenseKey) {
    await revalidateLicense();
    ({ licenseStatus } = await chrome.storage.local.get("licenseStatus"));
  }
  if (licenseStatus !== "active" || !licenseKey) return;
  const { monitoringOn, lastCheckAt, lastReadAt } = await chrome.storage.local.get(["monitoringOn", "lastCheckAt", "lastReadAt"]);
  try {
    const res = await fetch(`${BACKEND_URL}/activate`, {
      method:  "POST",
      headers: backendHeaders(),
      // "Last check" for the app and the server = the last visit that actually
      // read posts, so a blind or logged-out visit doesn't look healthy.
      body:    JSON.stringify({ licenseKey, deviceId: await getDeviceId(), heartbeat: true,
                                monitoringOn: !!monitoringOn, lastCheckAt: (lastReadAt ?? lastCheckAt) || 0,
                                state: await extensionState(), configVersion: await watchConfigVersion(), diag: await diagnostics() }),
    });
    if (res.ok) {
      const data = await res.clone().json().catch(() => ({}));
      await applyWatchSync(data);
      if (typeof data.autoPostDefault === "boolean") await chrome.storage.local.set({ autoPostDefault: data.autoPostDefault });
      if (typeof data.scanAllGroups === "boolean") await chrome.storage.local.set({ scanAllGroups: data.scanAllGroups });
      // The Piano Project network (2026-10-25): fellow members' keywords.
      if (Array.isArray(data.network)) await chrome.storage.local.set({ networkMembers: data.network });
      await handleCommands(data).catch((e) => log("Command error:", e.message));
    }
    uploadScanLog(true).catch(() => {});
    // The server refuses a canceled, unpaid or deleted license. Act on it
    // within the hour instead of waiting for the daily re-validation.
    if (res.status === 401 || res.status === 403) {
      const data = await res.json().catch(() => ({}));
      await deactivateLocally(data.error || "License not active");
    }
  } catch (err) {
    log("Heartbeat failed:", err.message);   // offline — try again next hour
  }
}

// ─── Cloud scan pick-up ───────────────────────────────────────────────────────
// The backend scans public groups hourly (cloud-scan) and queues qualified
// posts. Every 15 minutes this collects them and runs each through the normal
// lead flow (auto-post or "reply waiting"), skipping any post this browser
// already found itself. Replies still post from this browser, as always.
const CLOUD_ALARM = "cloud-poll";
async function pollCloudLeads() {
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  if (licenseStatus !== "active" || !licenseKey) return;
  const { cloud } = await chrome.storage.local.get("cloud");
  if (!cloud?.enabled) return;
  try {
    const res = await fetch(`${BACKEND_URL}/activate`, {
      method: "POST", headers: backendHeaders(),
      body: JSON.stringify({ licenseKey, deviceId: await getDeviceId(), cloudPoll: true }),
    });
    if (!res.ok) return;
    const data = await res.json();
    if (data.cloud) await chrome.storage.local.set({ cloud: data.cloud });
    for (const r of data.leads || []) {
      const lead = {
        id: r.lead_id, source: "cloud_scan",
        groupName: r.group_name || "", groupId: r.group_key || "",
        authorName: r.author_name || "", postUrl: r.post_url || null,
        postText: r.post_text || "", snippet: String(r.post_text || "").slice(0, 200),
        matchedKeywords: r.matched_keywords || [], detectedAt: Date.now(),
        // The post time the cloud scan read — for the response-speed stat.
        ...(r.posted_at ? { postedAt: r.posted_at, timestamp: r.posted_at } : {}),
      };
      await handleNewLead(lead, { isBuyer: true, score: r.score, reason: r.reason, summary: r.summary, commentText: r.comment_text });
    }
    if ((data.leads || []).length) log("Cloud scan: picked up", data.leads.length, "post(s)");
  } catch (err) {
    log("Cloud poll failed:", err.message);
  }
}
// Created once. Re-creating it every time the worker woke up (every few
// minutes while monitoring) reset the timer, so it fired about every 2
// minutes instead of every 15.
chrome.alarms.get(CLOUD_ALARM).then((a) => {
  if (!a) chrome.alarms.create(CLOUD_ALARM, { delayInMinutes: 2, periodInMinutes: 15 });
});

// Settings → Hourly cloud scan: save and return the server-side settings.
async function saveCloudSettings(settings) {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (!licenseKey) return { ok: false, error: "Activate your license first." };
  const res = await fetch(`${BACKEND_URL}/activate`, {
    method: "POST", headers: backendHeaders(),
    body: JSON.stringify({ licenseKey, deviceId: await getDeviceId(), cloudSettings: settings }),
  }).catch(() => null);
  const data = res ? await res.json().catch(() => ({})) : {};
  if (!res?.ok || !data.ok) return { ok: false, error: data.error || "Couldn't save. Check your connection and try again." };
  await chrome.storage.local.set({ cloud: data.cloud });
  return { ok: true, cloud: data.cloud };
}

// ─── Uptime ───────────────────────────────────────────────────────────────────
// Each hourly check-in marks its hour as "on" (monitoring switched on and a
// group checked in the last 90 minutes) or "off". Hours with no check-in at all
// mean the computer was asleep or Chrome was closed — the gap Keep It Running
// fixes. Kept 14 days; the dashboard shows the share of active hours that were on.
const HOUR_MS = 60 * 60 * 1000;
async function recordUptime() {
  const { monitoringOn, lastCheckAt, uptimeLog = {} } = await chrome.storage.local.get(["monitoringOn", "lastCheckAt", "uptimeLog"]);
  const now = Date.now(), hour = Math.floor(now / HOUR_MS);
  const on = !!monitoringOn && (lastCheckAt || 0) > now - 90 * 60 * 1000;
  const log = { ...uptimeLog, [hour]: on || uptimeLog[hour] === 1 ? 1 : 0 };
  for (const h of Object.keys(log)) if (Number(h) < hour - 14 * 24) delete log[h];
  await chrome.storage.local.set({ uptimeLog: log });
}

// Share of the last 7 days' active hours (Settings → Safety limits, local time)
// that were "on". Hours before the first record (a new install) don't count.
async function uptimeSummary() {
  const { uptimeLog = {} } = await chrome.storage.local.get("uptimeLog");
  const s = await getSafety();
  const hours = Object.keys(uptimeLog).map(Number);
  const nowHour = Math.floor(Date.now() / HOUR_MS);
  if (!hours.length) return { pct: null, activeHours: 0, onHours: 0 };
  const from = Math.max(Math.min(...hours), nowHour - 7 * 24);
  let active = 0, on = 0;
  for (let h = from; h < nowHour; h++) {
    const local = new Date(h * HOUR_MS).getHours();
    if (local < s.activeStartHour || local >= s.activeEndHour) continue;
    active++;
    if (uptimeLog[h] === 1) on++;
  }
  return { pct: active ? Math.round((on / active) * 100) : null, activeHours: active, onHours: on };
}

// What this install is set up to do, for the admin view: keywords, groups and
// settings otherwise live only in this browser.
async function extensionState() {
  const sync = await chrome.storage.local.get(["keywords", "businessPageName", "messengerUrl", "tagPageInReplies", "replyMode", "autoPostDefault", "safety", "plan", "areaWords", "skipWords", "maxPostAgeDays", "replyAnyTime"]);
  const { monitorGroups = [] } = await chrome.storage.local.get("monitorGroups");
  const safety = await getSafety();
  return {
    version:  chrome.runtime.getManifest().version,
    keywords: sync.keywords || [],
    groups:   monitorGroups.map((g) => ({ name: g.name || "", url: g.url || "", active: g.active !== false, areaOnly: g.areaOnly === true })),
    settings: {
      businessPageName: sync.businessPageName || "",
      messengerUrl:     sync.messengerUrl || "",
      tagPageInReplies: sync.tagPageInReplies !== false,
      replyMode:        await getReplyMode(),
      replyModePinned:  sync.replyMode || "",
      dailyCap:         safety.dailyCap,
      minGapMin:        safety.minGapMin,
      maxGapMin:        safety.maxGapMin,
      activeStartHour:  safety.activeStartHour,
      activeEndHour:    safety.activeEndHour,
      safetyPreset:     sync.safety?.preset || "careful",
      areaWords:        (Array.isArray(sync.areaWords) ? sync.areaWords : []).join(","),
      ...(Array.isArray(sync.skipWords) ? { skipWords: sync.skipWords } : {}),
      ...(Number.isFinite(sync.maxPostAgeDays) ? { maxPostAgeDays: sync.maxPostAgeDays } : {}),
      ...(typeof sync.replyAnyTime === "boolean" ? { replyAnyTime: sync.replyAnyTime } : {}),
      uptimePct7d:      (await uptimeSummary()).pct ?? -1,
      timeZone:         Intl.DateTimeFormat().resolvedOptions().timeZone,   // for the morning check and the app's "paused for the night"
    },
  };
}

// Keywords or groups changed: check in a minute later (an alarm, since the
// service worker may sleep) so the admin view doesn't wait for the hourly one.
chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === "local" && "keywords" in changes) || (area === "local" && "monitorGroups" in changes)) {
    chrome.alarms.create("state-sync", { delayInMinutes: 1 });
  }
});

// "Sign out of this license" (Settings): frees this browser's device slot on
// the server, then forgets the key locally and stops monitoring. Keywords and
// groups stay, so signing back in picks up where it left off.
async function signOutLicense() {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (licenseKey) {
    await fetch(`${BACKEND_URL}/activate`, {
      method: "POST", headers: backendHeaders(),
      body: JSON.stringify({ licenseKey, deviceId: await getDeviceId(), signOut: true }),
    }).catch(() => {});   // offline: the slot frees when an admin resets devices
  }
  await stopCycling().catch(() => {});
  chrome.alarms.clear(REVALIDATE_ALARM);
  chrome.alarms.clear(HEARTBEAT_ALARM);
  await chrome.storage.local.remove(["licenseKey", "licenseExpiresAt", "customerId", "plan"]);
  await chrome.storage.local.set({ licenseStatus: "signed_out", licenseError: "" });
  const tabs = await chrome.tabs.query({ url: "https://www.facebook.com/*" });
  tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { type: "CONFIG_UPDATED" }).catch(() => {}));
  chrome.action.setBadgeText({ text: "" });
  return { ok: true };
}

// License refused by the server: stop scanning and monitoring, tell open
// Facebook tabs (their badge switches to "license not active") and flag the
// toolbar icon. Queued replies stay put and post if the license comes back.
async function deactivateLocally(reason) {
  log("License refused by server:", reason);
  await chrome.storage.local.set({ licenseStatus: "invalid", licenseError: reason });
  // The owner's on/off choice (monitoringOn) stays as it was: when the license
  // works again (a device slot freed, a payment fixed) monitoring resumes by
  // itself. The heartbeat re-checks the license every hour meanwhile.
  await pauseForLicense().catch(() => {});
  const tabs = await chrome.tabs.query({ url: "https://www.facebook.com/*" });
  tabs.forEach(tab => chrome.tabs.sendMessage(tab.id, { type: "CONFIG_UPDATED" }).catch(() => {}));
  chrome.action.setBadgeText({ text: "!" });
  chrome.action.setBadgeBackgroundColor({ color: "#f85149" });
}

function scheduleHeartbeat() {
  chrome.alarms.create(HEARTBEAT_ALARM, { delayInMinutes: 1, periodInMinutes: 60 });
  chrome.alarms.create(CONFIG_ALARM, { delayInMinutes: 2, periodInMinutes: 10 });
}

// ─── One app: settings edited in the phone app ────────────────────────────────
// Keywords, groups and reply settings live on the server too (watch_config),
// so the phone app can edit them. Every 10 minutes (and with each heartbeat)
// this install sends the version it last applied; the server answers with its
// copy when that's newer, or takes this computer's copy when it was changed
// here. Safety presets mirror dashboard.js.
const CONFIG_ALARM = "config-check";
const WATCH_SAFETY_PRESETS = {
  careful:  { ...SAFETY_DEFAULTS },
  balanced: { dailyCap: 15, minGapMin: 3, maxGapMin: 12, dwellMinSec: 90, dwellMaxSec: 240, activeStartHour: 6, activeEndHour: 23 },
  busy:     { dailyCap: 25, minGapMin: 2, maxGapMin: 8,  dwellMinSec: 60, dwellMaxSec: 180, activeStartHour: 0, activeEndHour: 24 },
};

async function watchConfigVersion() {
  const { watchConfigVersion: v } = await chrome.storage.local.get("watchConfigVersion");
  return Number.isInteger(v) && v >= 0 ? v : 0;
}

async function checkWatchConfig() {
  const { licenseStatus, licenseKey } = await chrome.storage.local.get(["licenseStatus", "licenseKey"]);
  if (licenseStatus !== "active" || !licenseKey) return { ok: false, error: "Not signed in" };
  try {
    const res = await fetch(`${BACKEND_URL}/activate`, {
      method: "POST", headers: backendHeaders(),
      body: JSON.stringify({ licenseKey, deviceId: await getDeviceId(), configCheck: true,
                             configVersion: await watchConfigVersion(), state: await extensionState() }),
    });
    if (!res.ok) return { ok: false, error: `Server ${res.status}` };
    const data = await res.json().catch(() => ({}));
    const applied = await applyWatchSync(data);
    await handleCommands(data).catch((e) => log("Command error:", e.message));
    return { ok: true, configVersion: data.configVersion ?? null, applied };
  } catch (err) {
    log("Config check failed:", err.message);
    return { ok: false, error: err.message };
  }
}

// Storm mode (server _shared/storm.ts): while it's on, its storm words join
// the business's keywords (content.js). The checking pace doesn't change.
async function applyStorm(data) {
  if (!data || !("storm" in data)) return;
  const s = data.storm && typeof data.storm === "object" && Date.parse(data.storm.until) > Date.now() ? data.storm : null;
  const { storm: was } = await chrome.storage.local.get("storm");
  if (JSON.stringify(was || null) === JSON.stringify(s)) return;
  await chrome.storage.local.set({ storm: s });
  log(s ? `Storm mode on (${s.event}) until ${s.until}` : "Storm mode off");
}

// Apply the server's copy (if sent) and remember its version.
async function applyWatchSync(data) {
  await applyStorm(data).catch(() => {});
  if (!data || !Number.isInteger(data.configVersion)) return false;
  const c = data.config;
  if (c && typeof c === "object") {
    const sync = {};
    if (Array.isArray(c.keywords)) sync.keywords = c.keywords.map(String);
    const st = c.settings || {};
    if (typeof st.tagPageInReplies === "boolean") sync.tagPageInReplies = st.tagPageInReplies;
    if (st.safetyPreset && WATCH_SAFETY_PRESETS[st.safetyPreset]) {
      const { safety } = await chrome.storage.local.get("safety");
      if ((safety?.preset || "careful") !== st.safetyPreset) sync.safety = { ...WATCH_SAFETY_PRESETS[st.safetyPreset], preset: st.safetyPreset };
    }
    if (st.replyMode === "auto" || st.replyMode === "review") sync.replyMode = st.replyMode;
    if (Array.isArray(st.areaWords)) sync.areaWords = st.areaWords.map(String);
    if (Array.isArray(st.skipWords)) sync.skipWords = st.skipWords.map(String);
    if (Number.isFinite(st.maxPostAgeDays)) sync.maxPostAgeDays = st.maxPostAgeDays;
    if (typeof st.replyAnyTime === "boolean") { sync.replyAnyTime = st.replyAnyTime; scheduleQueue().catch(() => {}); }
    await chrome.storage.local.set(sync);
    if (st.replyMode === "") await chrome.storage.local.remove("replyMode");
    if (Array.isArray(c.groups)) {
      // Keep what this computer knows about each group (its stats); add new
      // ones, drop removed ones, and take the name and on/off from the server.
      const idOf = (u) => { const x = String(u || "").match(/facebook\.com\/groups\/([^/?#]+)/i); return x ? decodeURIComponent(x[1]).toLowerCase() : ""; };
      await updateStore("monitorGroups", (groups) => {
        const have = new Map((Array.isArray(groups) ? groups : []).map((g) => [idOf(g.url), g]));
        return c.groups.filter((g) => idOf(g.url)).map((g) => ({ ...(have.get(idOf(g.url)) || {}), url: g.url, name: g.name, active: g.active !== false, areaOnly: g.areaOnly === true }));
      }, []);
    }
    log("Applied settings from the phone app, version", data.configVersion);
  }
  await chrome.storage.local.set({ watchConfigVersion: data.configVersion });
  return !!c;
}

// The AnyoneNear app (where settings live since 1.11): the server's app URL
// (OWNER_APP_URL, saved at sign-in) or the default.
const DEFAULT_APP_URL = "https://anyonenear-app.vercel.app";
async function openApp(hash = "") {
  const { ownerAppUrl } = await chrome.storage.local.get("ownerAppUrl");
  const base = /^https:\/\//.test(ownerAppUrl || "") ? ownerAppUrl.replace(/\/+$/, "") : DEFAULT_APP_URL;
  await chrome.tabs.create({ url: base + "/" + hash });
}

// ─── Messages from the phone app (externally_connectable) ─────────────────────
// The app (anyonenear-app.vercel.app) can check this install is here, sign it
// in with the business's license key, ask it to pick up new settings now, and
// run the group finder (which needs this browser's Facebook login).
const APP_ORIGINS = ["https://anyonenear-app.vercel.app"];
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!APP_ORIGINS.includes(sender.origin || new URL(sender.url || "about:blank").origin)) { sendResponse({ ok: false, error: "Not allowed" }); return false; }
  (async () => {
    const { licenseStatus, customerId } = await chrome.storage.local.get(["licenseStatus", "customerId"]);
    switch (message?.type) {
      case "PING": {
        const { monitoringOn, lastCheckAt, monitorGroups = [] } = await chrome.storage.local.get(["monitoringOn", "lastCheckAt", "monitorGroups"]);
        return { ok: true, version: chrome.runtime.getManifest().version, signedIn: licenseStatus === "active", customerId: customerId || null,
                 monitoringOn: !!monitoringOn, lastCheckAt: lastCheckAt || 0, groups: monitorGroups.length, configVersion: await watchConfigVersion() };
      }
      case "LINK": {
        const key = String(message.licenseKey || "");
        if (!/^[a-zA-Z0-9_-]{8,64}$/.test(key)) return { ok: false, error: "Invalid license key" };
        const r = await activateLicense(key, await getDeviceId());
        if (r?.valid !== false) await checkWatchConfig();
        return { ok: r?.valid !== false, error: r?.error || null };
      }
      case "TEST_VISIT":
        return await testVisit();
      case "SNAPSHOT_GROUPS":
        // Takes a few minutes per group: start it and answer right away; the
        // app follows along with SNAPSHOT_STATUS.
        await snapStatus({ state: "running", message: "Starting…", started: Date.now() });
        snapshotGroups(true).then(async (r) => { if (!r.ok) await snapStatus({ state: "error", message: r.error }); },
          async (e) => { log("Snapshot error:", e.message); await snapStatus({ state: "error", message: e.message }); });
        return { ok: true, started: true };
      case "DIAG":
        return { ok: true, diag: await diagnostics() };
      case "SNAPSHOT_STATUS": {
        const { snapshotStatus = null } = await chrome.storage.local.get("snapshotStatus");
        return { ok: true, status: snapshotStatus };
      }
      case "SYNC_NOW": {
        const r = await checkWatchConfig();
        await cycleWatchdog().catch(() => {});   // "Update it now" also revives a stalled cycle
        return r;
      }
      case "FIND_GROUPS":
        if (licenseStatus !== "active") return { ok: false, error: "Sign this computer in first" };
        return message.topic ? await findGroupsByTopic(String(message.topic)) : await findGroups(String(message.town || ""));
      case "MY_GROUPS":
        if (licenseStatus !== "active") return { ok: false, error: "Sign this computer in first" };
        return await myGroups(String(message.town || ""));
      case "GROUP_NAME":
        return await groupName(String(message.url || ""));
      case "PAGE_TEXT":
        if (licenseStatus !== "active") return { ok: false, error: "Sign this computer in first" };
        return await pageText(String(message.page || ""));
      case "START_MONITORING":
        if (licenseStatus !== "active") return { ok: false, error: "Sign this computer in first" };
        await chrome.storage.local.remove("fbRestrictedUntil");   // the owner chose to restart
        return await startCycling().then(() => ({ ok: true }), (e) => ({ ok: false, error: e.message }));
      case "STOP_MONITORING":
        return await stopCycling().then(() => ({ ok: true }), (e) => ({ ok: false, error: e.message }));
    }
    return { ok: false, error: "Unknown request" };
  })().then(sendResponse, (e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

// ─── Alarms ───────────────────────────────────────────────────────────────────
updatePendingBadge();

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === REVALIDATE_ALARM) await revalidateLicense();
  if (alarm.name === CYCLE_ALARM)      await cycleStep();
  if (alarm.name === QUEUE_ALARM)      await processQueue();
  if (alarm.name === HEARTBEAT_ALARM || alarm.name === "state-sync") await sendHeartbeat();
  if (alarm.name === REPLY_SYNC_ALARM) await syncReplies();
  if (alarm.name === CLOUD_ALARM) await pollCloudLeads();
  if (alarm.name === CONFIG_ALARM) { await checkWatchConfig(); await cycleWatchdog().catch((e) => log("Watchdog error:", e.message)); await runRetries().catch((e) => log("Retry error:", e.message)); await maybeAutoSnapshot().catch((e) => log("Snapshot error:", e.message)); }
});

// ─── Install / startup ────────────────────────────────────────────────────────
// Earlier dev builds wrote a fake "active" license (DEV-BYPASS). Clear it so
// the customer is asked for a real key instead of silently getting nothing.
async function clearDevBypass() {
  const { licenseKey } = await chrome.storage.local.get("licenseKey");
  if (licenseKey === "DEV-BYPASS") {
    await chrome.storage.local.set({ licenseStatus: "none", licenseKey: "", plan: "" });
    log("Cleared leftover DEV-BYPASS license");
  }
}

// Pick monitoring back up whenever Chrome starts (or the extension updates),
// and tell the customer either way — a paused monitor catches nothing.
async function resumeMonitoring(reason) {
  const { monitoringOn, monitorGroups = [] } = await chrome.storage.local.get(["monitoringOn", "monitorGroups"]);
  const { licenseStatus } = await chrome.storage.local.get("licenseStatus");
  if (licenseStatus !== "active" || monitorGroups.length === 0) { updateActionStatus(); return; }

  if (monitoringOn) {
    await startCycling();
    if (reason === "startup") {
      chrome.notifications.create("monitor_resumed", {
        type: "basic", iconUrl: "icons/icon48.png",
        title: "AnyoneNear is watching your groups",
        message: `Monitoring ${monitorGroups.length} group${monitorGroups.length === 1 ? "" : "s"} in the AnyoneNear window. Don't minimize it: move it to a corner or another screen and keep part of it visible, so Facebook loads the posts.`,
        priority: 0,
      });
    }
  } else if (reason === "startup") {
    chrome.notifications.create("monitor_paused", {
      type: "basic", iconUrl: "icons/icon48.png",
      title: "AnyoneNear is paused",
      message: "Your groups aren't being watched. Click to open the dashboard and start monitoring.",
      priority: 1, requireInteraction: true,
    });
  }
  updateActionStatus();
}

// Scans first (2026-10-18). A screen that goes to sleep makes Chrome treat
// every window as hidden, and Facebook then stops loading posts (a computer
// on a dedicated screen read nothing for hours). While visits are happening:
//   - the display stays on (chrome.power, released 45 minutes after the last
//     visit, so it never holds the screen on once monitoring stops);
//   - Chrome's Memory Saver may not unload the scanning tab.
const KEEP_AWAKE_ALARM = "keepAwakeCheck";
async function keepScanning(tabId) {
  try { chrome.power?.requestKeepAwake("display"); } catch { /* no power permission (older install) */ }
  if (Number.isInteger(tabId)) await chrome.tabs.update(tabId, { autoDiscardable: false }).catch(() => {});
  await chrome.storage.local.set({ keepAwakeAt: Date.now() });
  chrome.alarms.create(KEEP_AWAKE_ALARM, { delayInMinutes: 15, periodInMinutes: 15 });
}
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== KEEP_AWAKE_ALARM) return;
  const { keepAwakeAt = 0 } = await chrome.storage.local.get("keepAwakeAt");
  if (Date.now() - keepAwakeAt < 45 * 60_000) return;
  try { chrome.power?.releaseKeepAwake(); } catch { /* fine */ }
  chrome.alarms.clear(KEEP_AWAKE_ALARM);
});

chrome.runtime.onStartup.addListener(async () => {
  await STORAGE_MIGRATION;
  // Window and tab ids don't survive a Chrome restart: forget the old monitor
  // window so we never navigate or close one of the owner's own windows.
  await chrome.storage.local.remove("monitorWindowId");
  await setCycleState({ windowId: null, tabId: null });
  await clearDevBypass();
  await chrome.storage.session.set({ queueBusyUntil: 0 });
  await sweepInterruptedReplies(0);
  await scheduleQueue();
  scheduleHeartbeat();
  scheduleReplySync(10_000);
  await resumeMonitoring("startup");
});

chrome.runtime.onInstalled.addListener(async (details) => {
  await STORAGE_MIGRATION;
  await clearDevBypass();
  await ensureReviewPeriod();
  scheduleHeartbeat();
  scheduleReplySync(10_000);
  if (details.reason === "update") {
    // The popup's old on/off switch could leave reading off while monitoring
    // looked on (1.11.22 replaced it); turn reading back on.
    await chrome.storage.local.set({ enabled: true });
    await resumeMonitoring("update");
  }
  if (details.reason === "install") {
    await chrome.storage.local.set({ licenseStatus: "none", enabled: true, keywords: [] });
    // Open dashboard to first-run license screen
    // Setup happens in the AnyoneNear app: sign in there, then "Connect this
    // computer" on the Watch screen signs this extension in.
    await openApp("#/watch");
  }
  log("AnyoneNear ready");
});
