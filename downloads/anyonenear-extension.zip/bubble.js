// AnyoneNear — on-page bubble.
//
// The main control surface on Facebook. A pill in the bottom-left corner that
// expands into a panel:
//   - Replies waiting: the post, the AI's draft (editable), Send / Skip
//   - This group: watching or "+ Watch this group"
//   - Monitoring: start / stop, what it's doing
//   - Recent activity: what happened to each post it looked at, and why
//   - Today: posts checked, leads, replies posted vs. the daily limit
//
// Shown on group pages always, and on every other Facebook page whenever
// replies are waiting, so a waiting reply is never hidden in a popup.
// Everything it shows comes from chrome.storage, so it survives refreshes and
// updates live. content.js reports the scanner's state through
// window.FB1Bubble.status(). Loaded before content.js (same isolated world).

(function () {
  "use strict";

  const S = {
    host: null, root: null,
    open: false, dismissed: false,
    state: "idle", detail: "",
    data: {}, flash: {},               // flash: leadId -> message after Send/Skip
    loadTimer: null,
  };

  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const groupIdOf = (u) => { const m = String(u || "").match(/facebook\.com\/groups\/([^/?#]+)/); return m ? decodeURIComponent(m[1]) : null; };
  const onGroupPage = () => !!groupIdOf(location.href);
  const today = () => new Date().toDateString();

  function ago(t) {
    const m = Math.floor((Date.now() - Number(t || 0)) / 60000);
    if (!t || m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    if (m < 1440) return `${Math.floor(m / 60)}h ago`;
    return `${Math.floor(m / 1440)}d ago`;
  }
  const clock = (t) => new Date(t).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });

  // ─── Data ──────────────────────────────────────────────────────────────────
  async function load() {
    if (!alive()) return;
    try {
      const [local, sync, cycle] = await Promise.all([
        chrome.storage.local.get(["pendingApprovals", "commentQueue", "activityLog", "monitorGroups",
                                  "scanToday", "commentLog", "bubbleOpen", "focusLeadId", "nextCommentAt"]),
        chrome.storage.sync.get(["licenseStatus", "licenseError", "maxGroups", "enabled", "safety", "theme"]),
        chrome.runtime.sendMessage({ type: "GET_CYCLE_STATUS" }).catch(() => null),
      ]);
      S.data = { ...local, ...sync, cycle };
      if (local.bubbleOpen !== undefined && S.host === null) S.open = !!local.bubbleOpen;

      // Opened from a desktop notification: expand on that reply.
      if (local.focusLeadId && (local.pendingApprovals || {})[local.focusLeadId]) {
        S.open = true; S.dismissed = false;
        chrome.storage.local.remove("focusLeadId");
        S.focus = local.focusLeadId;
      }
    } catch { /* extension reloaded mid-call */ }
    render();
  }

  // Facebook fills in the group header after load, and joining doesn't reload
  // the page, so re-check membership while an unwatched group is open.
  setInterval(() => {
    if (!S.root || !S.open || !onGroupPage()) return;
    const gid = groupIdOf(location.href);
    if ((S.data.monitorGroups || []).some((g) => groupIdOf(g.url) === gid)) return;
    if (groupMembership() !== S.renderedMembership) render();
  }, 3000);

  function scheduleLoad() {
    clearTimeout(S.loadTimer);
    S.loadTimer = setTimeout(load, 150);
  }

  const pending = () => Object.entries(S.data.pendingApprovals || {})
    .map(([id, p]) => ({ id, ...p }))
    .sort((a, b) => Number(b.lead?.timestamp || 0) - Number(a.lead?.timestamp || 0));

  // ─── Render ────────────────────────────────────────────────────────────────
  function ensureHost() {
    if (S.host || !document.body) return;
    S.host = document.createElement("div");
    S.host.style.cssText = "position:fixed;left:16px;bottom:16px;z-index:2147483647;";
    S.root = S.host.attachShadow({ mode: "open" });
    if (!document.getElementById("an-fonts") && document.head) {
      const st = document.createElement("style"); st.id = "an-fonts"; st.textContent = FONT_FACE; document.head.appendChild(st);
    }
    S.root.addEventListener("click", onClick);
    document.body.appendChild(S.host);
  }

  function removeHost() {
    if (S.host) { S.host.remove(); S.host = null; S.root = null; }
  }

  function render() {
    const waiting = pending();
    const licensed = S.data.licenseStatus === "active";
    const show = !S.dismissed && (onGroupPage() || waiting.length > 0 || S.state === "off-orphan");
    if (!show) { removeHost(); return; }
    ensureHost();
    if (!S.root) return;

    // Keep what the user is typing in a draft across re-renders.
    const drafts = {};
    S.root.querySelectorAll("textarea[data-id]").forEach((t) => { drafts[t.dataset.id] = t.value; });
    const focusedId = S.root.activeElement?.dataset?.id;

    const dot = !licensed ? "off" : S.state === "on" ? "on" : S.state === "idle" ? "idle" : "off";
    const pillText = !licensed && S.data.licenseStatus
      ? "license not active — open the dashboard"
      : onGroupPage() ? (S.detail || "starting…") : "";

    const theme = S.data.theme === "light" || S.data.theme === "dark" ? S.data.theme : "system";
    S.root.innerHTML = `${STYLE}<div class="an" data-theme="${theme}">
      ${S.open ? panel(waiting, drafts) : ""}
      <div class="pill" data-act="toggle" role="button" tabindex="0" aria-expanded="${S.open}">
        <span class="dot ${dot}"></span>
        <span class="txt"><span class="wm">any<b>one</b>near<i>?</i></span>${pillText ? " · " + esc(pillText) : ""}</span>
        ${waiting.length ? `<span class="waiting">${waiting.length} repl${waiting.length === 1 ? "y" : "ies"} waiting</span>` : ""}
        <span class="chev">${S.open ? "▾" : "▴"}</span>
        <span class="x" data-act="dismiss" title="Hide until next page">×</span>
      </div></div>`;

    if (focusedId) S.root.querySelector(`textarea[data-id="${CSS.escape(focusedId)}"]`)?.focus();
    if (S.focus) {
      S.root.querySelector(`[data-card="${CSS.escape(S.focus)}"]`)?.scrollIntoView({ block: "nearest" });
      S.focus = null;
    }
  }

  function panel(waiting, drafts) {
    return `<div class="panel" role="dialog" aria-label="AnyoneNear">
      <div class="head"><span class="wm">any<b>one</b>near<i>?</i></span>
        <button class="link" data-act="dashboard">Open dashboard</button></div>
      ${sectionWaiting(waiting, drafts)}
      ${onGroupPage() ? sectionGroup() : ""}
      ${sectionMonitor()}
      ${sectionToday()}
      ${sectionActivity()}
    </div>`;
  }

  function sectionWaiting(waiting, drafts) {
    if (!waiting.length) {
      return `<section><h4>Replies waiting</h4><p class="muted">Nothing waiting. New replies show up here the moment a lead is found.</p></section>`;
    }
    return `<section><h4>Replies waiting · ${waiting.length}</h4>${waiting.map((p) => {
      const l = p.lead || {};
      const score = Math.min(10, Math.max(0, Math.round(Number(l.intentScore)) || 0));
      const flash = S.flash[p.id];
      return `<div class="card" data-card="${esc(p.id)}">
        <div class="meta">${esc(l.groupName || "Facebook group")} · ${ago(l.timestamp)}${score ? ` · <span class="score">${score}/10</span>` : ""}${l.mention ? ` · <span class="star">recommended you</span>` : ""}</div>
        <div class="post">${esc(l.authorName && l.authorName !== "Unknown" ? l.authorName + ": " : "")}“${esc((l.postText || l.snippet || "").slice(0, 220))}”</div>
        ${l.intentSummary ? `<div class="why">${esc(l.intentSummary)}</div>` : ""}
        <label class="lbl" for="d-${esc(p.id)}">Your reply · edit it to fit and your assistant learns how you write</label>
        <textarea id="d-${esc(p.id)}" data-id="${esc(p.id)}" rows="4">${esc(drafts[p.id] ?? p.commentText ?? "")}</textarea>
        ${flash ? `<div class="flash">${esc(flash)}</div>` : ""}
        <div class="row">
          <button class="primary" data-act="send" data-id="${esc(p.id)}">Send</button>
          <button data-act="skip" data-id="${esc(p.id)}">Skip</button>
          ${l.postUrl ? `<button class="link" data-act="view" data-url="${esc(l.postUrl)}">View post</button>` : ""}
        </div>
      </div>`;
    }).join("")}</section>`;
  }

  // Facebook shows "Join group" (or "Cancel request" while approval is pending)
  // in the group header when you're not a member. Replies can't be posted in a
  // group you haven't joined, so the bubble shouldn't offer to watch it yet.
  // Only the group's own header counts: "Suggested groups" cards in the feed
  // and the side column carry "Join" buttons too, which made a group the
  // customer belongs to read as "not a member".
  function groupMembership() {
    const main = document.querySelector('[role="main"]');
    if (!main) return "member";
    const feed = main.querySelector('[role="feed"]');
    for (const el of main.querySelectorAll('[role="button"], button')) {
      if (el.closest('[role="feed"], [role="article"], [role="complementary"]')) continue;
      if (feed && (feed.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
      const t = (el.getAttribute("aria-label") || el.textContent || "").trim().toLowerCase();
      if (t.length > 20) continue;
      if (t === "join group" || t === "join") return "none";
      if (t === "cancel request") return "pending";
    }
    return "member";
  }

  function sectionGroup() {
    const gid = groupIdOf(location.href);
    const groups = S.data.monitorGroups || [];
    const watched = groups.some((g) => groupIdOf(g.url) === gid);
    const max = S.data.maxGroups ?? 3;
    const membership = watched ? "member" : groupMembership();
    S.renderedMembership = membership;
    return `<section><h4>This group</h4>${watched
      ? `<p>✓ Watching this group. Monitoring checks it every cycle.</p>`
      : membership === "pending"
      ? `<p class="muted">Your request to join is waiting for an admin. Once you're approved, you can watch this group here.</p>`
      : membership === "none"
      ? `<p class="muted">You're not a member of this group. Join it on Facebook first, since replies can only be posted in groups you've joined.</p>`
      : `<p class="muted">Not in your watched groups (${groups.length} of ${max} used).</p>
         <div class="row"><button class="primary" data-act="watch" ${groups.length >= max ? "disabled" : ""}>+ Watch this group</button></div>
         ${groups.length >= max ? `<p class="muted small">Your plan covers ${max} groups. Remove one in the dashboard, or upgrade for more.</p>` : ""}`}
    </section>`;
  }

  function sectionMonitor() {
    const c = S.data.cycle || {};
    const on = !!c.active;
    const status = !on ? "Off. Groups are only checked while you have them open."
      : c.paused ? `On, but paused until ${c.resumeAt ? clock(c.resumeAt) : "your active hours start"}. <button class="link" data-act="settings">Change active hours</button>`
      : `Checking ${esc(c.groupName || "your groups")} (${((c.index || 0) % Math.max(1, c.total || 1)) + 1} of ${Math.max(1, c.total || 1)}).`;
    return `<section><h4>Monitoring</h4><p>${status}</p>
      <div class="row"><button ${on ? "" : 'class="primary"'} data-act="${on ? "stop" : "start"}">${on ? "Stop monitoring" : "Start monitoring"}</button></div>
    </section>`;
  }

  function sectionToday() {
    const st = S.data.scanToday && S.data.scanToday.day === today() ? S.data.scanToday : { checked: 0, matched: 0 };
    const log = (S.data.activityLog || []).filter((a) => new Date(a.t).toDateString() === today());
    const leads = log.filter((a) => ["reply_waiting", "auto_queued", "lead_manual"].includes(a.kind)).length;
    const cap = (S.data.safety && S.data.safety.dailyCap) || 8;
    // The limit is a safety ceiling (rolling 24 h), not a goal: only mention it
    // once replies are waiting or it's reached, never as "0/8".
    const log24 = (S.data.commentLog || []).filter((t) => Date.now() - t < 24 * 3600 * 1000);
    const posted = log24.filter((t) => new Date(t).toDateString() === today()).length;
    const queued = (S.data.commentQueue || []).length;
    const next = queued && S.data.nextCommentAt > Date.now() ? ` Next one around ${clock(S.data.nextCommentAt)}.` : "";
    const limit = log24.length >= cap
      ? `<p class="muted small">Safety limit reached: ${cap} replies in 24 hours. More replies wait until it frees up.</p>`
      : queued ? `<p class="muted small">${queued} repl${queued === 1 ? "y" : "ies"} queued to post, spaced out to keep your account safe (up to ${cap} a day).${next}</p>` : "";
    return `<section><h4>Today</h4>
      <div class="stats">
        <div><b>${st.checked}</b><span>posts checked</span></div>
        <div><b>${st.matched}</b><span>matched keywords</span></div>
        <div><b>${leads}</b><span>leads</span></div>
        <div><b>${posted}</b><span>replies posted</span></div>
      </div>
      ${limit}
      <p class="muted small">A post "matches" when it has one of your keywords, e.g. <i>deep clean</i> + <i>looking for</i>. The AI then checks whether they're really looking to hire.</p>
    </section>`;
  }

  const KIND = {
    reply_waiting: ["Lead found · reply waiting", "good"],
    auto_queued:   ["Lead found · reply queued automatically", "good"],
    lead_manual:   ["Lead found · reply by hand (no post link)", "good"],
    not_buyer:     ["Checked by AI · not hiring", "dim"],
    approved:      ["You approved · queued to post", "good"],
    posted:        ["Reply posted", "good"],
    failed:        ["Reply not posted", "bad"],
    skipped:       ["You skipped it", "dim"],
    ai_error:      ["AI check failed", "bad"],
  };

  function sectionActivity() {
    const items = (S.data.activityLog || []).slice(0, 8);
    if (!items.length) return `<section><h4>Recent activity</h4><p class="muted">Nothing yet. Posts that match your keywords and what the AI decided will show here.</p></section>`;
    return `<section><h4>Recent activity</h4><ul class="act">${items.map((a) => {
      const [label, tone] = KIND[a.kind] || [a.kind, "dim"];
      return `<li><div class="al ${tone}">${esc(label)}${a.score ? ` · ${esc(a.score)}/10` : ""}<span class="t">${ago(a.t)}</span></div>
        <div class="as">${a.group ? esc(a.group) + ": " : ""}“${esc((a.snippet || "").slice(0, 110))}”</div>
        ${a.reason ? `<div class="ar">${esc(a.reason)}</div>` : ""}</li>`;
    }).join("")}</ul></section>`;
  }

  // ─── Actions ───────────────────────────────────────────────────────────────
  async function onClick(e) {
    const el = e.target.closest("[data-act]");
    if (!el || !alive()) return;
    const act = el.dataset.act;
    const id = el.dataset.id;

    if (act === "dismiss") { e.stopPropagation(); S.dismissed = true; render(); return; }
    if (act === "toggle") { S.open = !S.open; chrome.storage.local.set({ bubbleOpen: S.open }).catch(() => {}); render(); return; }
    if (act === "dashboard") { chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" }).catch(() => {}); return; }
    if (act === "settings") { chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD", panel: "settings" }).catch(() => {}); return; }
    if (act === "view") { window.open(el.dataset.url, "_blank", "noopener"); return; }

    if (act === "send") {
      const text = S.root.querySelector(`textarea[data-id="${CSS.escape(id)}"]`)?.value.trim();
      if (!text) { S.flash[id] = "The reply is empty. Write something or Skip."; render(); return; }
      el.disabled = true;
      const res = await chrome.runtime.sendMessage({ type: "APPROVE_COMMENT", leadId: id, commentText: text }).catch(() => null);
      if (res?.ok) {
        delete S.flash[id];
        toast(res.eta && res.eta - Date.now() > 90000 ? `Queued. Posts around ${clock(res.eta)}.` : "Queued. Posts shortly.");
      } else {
        if (res?.reason === "already_decided") { delete S.flash[id]; toast(res.status === "skipped" ? "Already skipped from your phone." : "Already sent from your phone."); }
        else { S.flash[id] = res?.reason === "no_permalink" ? "No direct link to this post. Reply to it by hand." : "Couldn't queue this reply. Try again."; el.disabled = false; }
      }
      scheduleLoad();
      return;
    }
    if (act === "skip") {
      await chrome.runtime.sendMessage({ type: "SKIP_LEAD", leadId: id }).catch(() => {});
      toast("Skipped. Nothing will be posted.");
      scheduleLoad();
      return;
    }
    if (act === "watch") {
      el.disabled = true;
      if (groupMembership() !== "member") {
        toast("Join this group on Facebook first, then watch it.");
        render();
        return;
      }
      const name = document.querySelector("h1")?.textContent.trim() || "";
      const res = await chrome.runtime.sendMessage({ type: "WATCH_GROUP", url: location.href, name }).catch(() => null);
      toast(res?.ok ? `Watching ${name || "this group"}` : res?.error || "Couldn't add this group");
      scheduleLoad();
      return;
    }
    if (act === "start" || act === "stop") {
      el.disabled = true;
      await chrome.runtime.sendMessage({ type: act === "start" ? "START_CYCLING" : "STOP_CYCLING" }).catch(() => {});
      scheduleLoad();
    }
  }

  function toast(msg) {
    if (!S.root) return;
    const t = document.createElement("div");
    t.className = "toast";
    t.textContent = msg;
    S.root.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }

  // ─── Wiring ────────────────────────────────────────────────────────────────
  if (alive()) {
    chrome.storage.onChanged.addListener((changes) => {
      if (!alive()) return;
      const keys = ["pendingApprovals", "commentQueue", "activityLog", "monitorGroups", "scanToday",
                    "commentLog", "licenseStatus", "maxGroups", "focusLeadId", "nextCommentAt", "safety",
                    "cycleStamp"];
      if (keys.some((k) => k in changes)) scheduleLoad();
    });
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg?.type === "CYCLE_STATUS") scheduleLoad();
    });
  }

  let lastUrl = location.href;
  setInterval(() => {                   // FB is a SPA: re-evaluate on navigation
    if (location.href !== lastUrl) { lastUrl = location.href; S.dismissed = false; S.detail = ""; scheduleLoad(); }
  }, 1000);

  window.FB1Bubble = {
    // content.js: the scanner's state for this page ("on" | "idle" | "off")
    status(state, detail) { S.state = state; S.detail = detail; render(); },
    refresh: scheduleLoad,
  };

  load();

  // ─── Style ─────────────────────────────────────────────────────────────────
  // Same tokens as the popup and dashboard (light + dark), so the three look
  // like one product. Fonts are bundled: Facebook's CSP blocks Google Fonts.
  const FONT = (f) => { try { return chrome.runtime.getURL("fonts/" + f); } catch { return ""; } };
  const FONT_FACE = `@font-face{font-family:"AN Sora";src:url("${FONT("sora.woff2")}") format("woff2");font-weight:100 800;font-display:swap}
@font-face{font-family:"AN Jakarta";src:url("${FONT("pjs.woff2")}") format("woff2");font-weight:200 800;font-display:swap}`;
  const LIGHT = `--bg:#f6f8fc;--bg2:#ffffff;--bg3:#eef2fa;--border:#d8e0ee;--border2:#c9d3e6;
      --text:#1b2433;--text2:#55607a;--text3:#7d88a0;--accent:#2f6bff;--accent2:#1f55e0;--accent-soft:#dce7ff;--on-accent:#ffffff;
      --coral:#ff7a59;--green:#1f8a5b;--amber:#b45309;--pill:#1b2433;--pill-text:#ffffff;--pill-one:#8fb0ff;--shadow:0 18px 44px rgba(27,36,51,.22)`;
  const DARK = `--bg:#0e1422;--bg2:#161e30;--bg3:#1c2640;--border:#2a3550;--border2:#344160;
      --text:#eaf0fa;--text2:#a3afc6;--text3:#7c89a6;--accent:#6e9bff;--accent2:#93b5ff;--accent-soft:#1a2a55;--on-accent:#0b1530;
      --coral:#ff9a7f;--green:#4cc794;--amber:#f5a524;--pill:#161e30;--pill-text:#eaf0fa;--pill-one:#93b5ff;--shadow:0 18px 44px rgba(0,0,0,.5)`;
  const STYLE = `<style>
    :host{all:initial}
    .an{${LIGHT}}
    .an[data-theme="dark"]{${DARK}}
    @media (prefers-color-scheme:dark){.an[data-theme="system"]{${DARK}}}
    .an,.an *{box-sizing:border-box;font-family:"AN Jakarta","Plus Jakarta Sans",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased}
    .wm{font-family:"AN Sora","Sora","AN Jakarta",sans-serif;font-weight:400;letter-spacing:-.02em;white-space:nowrap;color:var(--text)}
    .wm b{font-weight:700;color:var(--accent)}.wm i{font-style:normal;font-weight:700;color:var(--coral)}

    .pill{font-size:12.5px;line-height:1.4;background:var(--pill);color:var(--pill-text);border:1px solid rgba(255,255,255,.08);border-radius:999px;
      padding:7px 11px 7px 13px;display:flex;align-items:center;gap:9px;box-shadow:0 6px 18px rgba(27,36,51,.28);
      max-width:min(520px,calc(100vw - 32px));cursor:pointer;user-select:none}
    .pill .wm{font-size:13px;color:var(--pill-text)}.pill .wm b{color:var(--pill-one)}
    .pill:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
    .txt{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .dot{width:8px;height:8px;border-radius:50%;flex:none}
    .on{background:#3dd68c;box-shadow:0 0 0 3px rgba(61,214,140,.22)}.idle{background:#f5b942}.off{background:#7a879c}
    .waiting{background:var(--coral);color:#fff;font-weight:700;border-radius:999px;padding:2px 9px;white-space:nowrap;font-size:11.5px}
    .chev{color:#a9b4c6}
    .x{cursor:pointer;color:#a9b4c6;margin-left:2px;font-size:15px;line-height:1}
    .x:hover{color:var(--pill-text)}

    .panel{position:absolute;left:0;bottom:calc(100% + 10px);width:min(400px,calc(100vw - 32px));max-height:min(72vh,640px);
      overflow:auto;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:16px;
      box-shadow:var(--shadow);font-size:13.5px;line-height:1.5}
    .head{position:sticky;top:0;display:flex;justify-content:space-between;align-items:center;padding:12px 16px;
      background:var(--bg2);border-bottom:1px solid var(--border);z-index:1}
    .head .wm{font-size:17px}
    section{padding:14px 16px;border-bottom:1px solid var(--border)}
    section:last-child{border-bottom:0}
    h4{margin:0 0 8px;font-family:"AN Sora","Sora",sans-serif;font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);font-weight:600}
    p{margin:0 0 6px}
    .muted{color:var(--text2)}.small{font-size:12px}
    .card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:12px;margin-bottom:10px}
    .card:last-child{margin-bottom:0}
    .meta{font-size:11.5px;color:var(--text2);margin-bottom:6px}
    .score{color:var(--green);font-weight:700}.star{color:var(--coral);font-weight:600}
    .post{margin-bottom:6px;color:var(--text)}
    .why{font-size:12.5px;color:var(--text2);margin-bottom:8px}
    .lbl{display:block;font-size:11px;color:var(--text2);margin-bottom:4px;font-weight:600}
    textarea{width:100%;resize:vertical;background:var(--bg);color:var(--text);border:1px solid var(--border2);border-radius:10px;
      padding:9px 10px;font-size:13.5px;line-height:1.5}
    textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
    .row{display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap}
    button{font-size:12.5px;font-weight:600;border-radius:10px;border:1px solid var(--border2);background:var(--bg2);color:var(--text2);
      padding:7px 13px;cursor:pointer;font-family:inherit}
    button:hover:not(:disabled){border-color:var(--accent);color:var(--accent)}
    button:disabled{opacity:.5;cursor:default}
    button:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
    button.primary{background:var(--accent);border-color:var(--accent);color:var(--on-accent)}
    button.primary:hover:not(:disabled){background:var(--accent2);border-color:var(--accent2);color:var(--on-accent)}
    button.link{background:none;border:0;color:var(--accent);padding:4px 2px;font-weight:600}
    button.link:hover{text-decoration:underline}
    .flash{margin-top:6px;font-size:12px;color:var(--amber)}
    .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}
    .stats div{background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:8px 4px;text-align:center}
    .stats b{display:block;font-family:"AN Sora","Sora",sans-serif;font-size:17px;font-weight:700;color:var(--text);font-variant-numeric:tabular-nums}
    .stats span{font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.05em;font-weight:600}
    .act{list-style:none;margin:0;padding:0;display:grid;gap:8px}
    .al{font-size:12.5px;font-weight:600;display:flex;justify-content:space-between;gap:8px}
    .al .t{font-weight:400;color:var(--text3);white-space:nowrap}
    .good{color:var(--green)}.bad{color:var(--coral)}.dim{color:var(--text3)}
    .as{font-size:12.5px}
    .ar{font-size:11.5px;color:var(--text2)}
    .toast{position:absolute;left:0;bottom:calc(100% + 10px);background:var(--pill);color:var(--pill-text);padding:7px 13px;border-radius:10px;
      font-size:12.5px;white-space:nowrap;box-shadow:0 6px 18px rgba(27,36,51,.28)}
    @media (prefers-reduced-motion:no-preference){.panel{animation:rise .14s ease-out}}
    @keyframes rise{from{transform:translateY(6px);opacity:.5}to{transform:none;opacity:1}}
  </style>`;
})();
