// ── STATE ──────────────────────────────────────────────────────────────────────
let config = {
  groups:       [],
  keywords:     [],
  ghlLocationId:'',
  ownerAppUrl:  '',
  ghlSetup:     null,
  maxGroups:    3,
  businessPageName: '',
  messengerUrl: '',
};

// Must match SAFETY_DEFAULTS in background.js.
const SAFETY_DEFAULTS = {
  dailyCap: 8, minGapMin: 5, maxGapMin: 20,
  dwellMinSec: 120, dwellMaxSec: 360,
  activeStartHour: 7, activeEndHour: 22,
};

// The three plain-language choices in Settings; "custom" exposes the numbers.
const SAFETY_PRESETS = {
  careful:  { ...SAFETY_DEFAULTS },
  balanced: { dailyCap: 15, minGapMin: 3, maxGapMin: 12, dwellMinSec: 90, dwellMaxSec: 240, activeStartHour: 6, activeEndHour: 23 },
  busy:     { dailyCap: 25, minGapMin: 2, maxGapMin: 8,  dwellMinSec: 60, dwellMaxSec: 180, activeStartHour: 0, activeEndHour: 24 },
};

let leads        = [];
let cycleActive  = false;
let cycleIndex   = 0;
let cycleTimer   = null;
let wizStep      = 1;
let wizKeywords  = [];
let wizGroups    = [];

// ── INIT ──────────────────────────────────────────────────────────────────────
async function init() {
  await loadConfig();

  const params   = new URLSearchParams(window.location.search);
  const firstRun = params.get('firstrun') === '1';
  const sync = await chrome.storage.sync.get(['licenseStatus']);
  const licenseStatus = sync.licenseStatus;

  if (firstRun || !licenseStatus || licenseStatus === 'none' || licenseStatus === 'invalid' || licenseStatus === 'signed_out') {
    isLicensed = false;
    hideSidebar();
    showPanel('license');
    return;
  }

  // Licensed — unlock everything
  isLicensed = true;
  showSidebar();
  renderAll();
  updateSidebarStatus();
  startLeadPolling();
  updateLicenseStatusCard();
  syncCycleState(); // sync cycling state from background.js
  refreshFromServer();

  // Auto-open setup wizard if no groups configured yet
  if (config.groups.length === 0) {
    setTimeout(() => {
      if (typeof window.openWizard === 'function') window.openWizard();
      else showPanel('wizard');
    }, 400);
  } else {
    const wanted = location.hash.slice(1);
    showPanel(wanted && document.getElementById(`panel-${wanted}`) ? wanted : 'monitor');
  }
}

// Re-run activation in the background whenever the dashboard opens, so the
// sub-account link, setup checklist, add-ons and plan limits reflect the
// server now — not whatever was stored the last time activation happened
// (possibly by an older build, or never, under the old dev bypass).
async function refreshFromServer() {
  const { licenseKey } = await chrome.storage.sync.get('licenseKey');
  if (!licenseKey) return;
  const { deviceId } = await chrome.storage.local.get('deviceId');
  const res = await chrome.runtime.sendMessage({ type: 'ACTIVATE_LICENSE', licenseKey, deviceId }).catch(() => null);
  if (!res?.valid) return;   // an invalid key flips the dashboard to the license screen via storage.onChanged
  await loadConfig();
  renderAll();
  updateSidebarStatus();
  updateLicenseStatusCard();
}

function hideSidebar() {
  const sidebar = document.querySelector('.sidebar');
  if (sidebar) sidebar.style.display = 'none';
}

function showSidebar() {
  const sidebar = document.querySelector('.sidebar');
  if (sidebar) sidebar.style.display = '';
}

// Appearance: "system" (default) follows the computer; light/dark are fixed.
function applyTheme(theme) {
  if (theme === 'light' || theme === 'dark') document.documentElement.dataset.theme = theme;
  else delete document.documentElement.dataset.theme;
}
chrome.storage.sync.get('theme').then(({ theme }) => applyTheme(theme)).catch(() => {});
document.addEventListener('change', async (e) => {
  if (e.target?.name !== 'theme') return;
  applyTheme(e.target.value);
  await chrome.storage.sync.set({ theme: e.target.value });
});

async function loadConfig() {
  try {
    const sync  = await chrome.storage.sync.get(null);
    const local = await chrome.storage.local.get(['leads', 'monitorGroups', 'ghlSetup', 'addons', 'usage']);

    config.keywords         = sync.keywords         || [];
    config.businessPageName = sync.businessPageName || '';
    config.messengerUrl     = sync.messengerUrl     || '';
    config.ghlLocationId    = sync.ghlLocationId    || '';
    config.ownerAppUrl      = sync.ownerAppUrl      || '';
    config.maxGroups        = sync.maxGroups        ?? 3;
    config.ghlSetup         = local.ghlSetup        || null;
    config.addons           = local.addons          || {};
    config.usage            = local.usage           || null;
    config.groups           = local.monitorGroups   || [];
    leads                   = local.leads           || [];
  } catch (err) {
    console.error('loadConfig error:', err);
  }
}

async function saveConfig(partial) {
  Object.assign(config, partial);
  const { groups, ...syncable } = partial;
  try {
    if (Object.keys(syncable).length) {
      await chrome.storage.sync.set(syncable);
    }
    if (groups !== undefined) {
      await chrome.storage.local.set({ monitorGroups: config.groups });
    }
  } catch (err) {
    console.error('saveConfig error:', err);
  }
}

// ── PANEL ROUTING ─────────────────────────────────────────────────────────────
// Track license state globally so showPanel can gate access
let isLicensed = false;

// #settings etc. in the URL opens that panel (the bubble links here).
window.addEventListener('hashchange', () => { const p = location.hash.slice(1); if (p && document.getElementById(`panel-${p}`)) showPanel(p); });

function showPanel(name) {
  // Gate — only license panel accessible without active license
  if (!isLicensed && name !== 'license') {
    showPanel('license');
    return;
  }

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(`panel-${name}`)?.classList.add('active');
  document.getElementById(`nav-${name}`)?.classList.add('active');

  if (name === 'groups')   renderGroups();
  if (name === 'keywords') renderKeywords();
  if (name === 'leads')    renderAllLeads();
  if (name === 'settings') populateSettings();
  if (name === 'cloud')    populateCloudCard();
  if (name === 'ghl')      populateGhl();
  if (name === 'guide')    renderHealthChecklist();
  renderUpgrades();
}

// "Is AnyoneNear working?" — one list of everything that has to be true for
// leads to come in, from what this install knows. Shown on Start here.
async function renderHealthChecklist() {
  const el = document.getElementById('health-checklist');
  if (!el) return;
  const [sync, local, uptime] = await Promise.all([
    chrome.storage.sync.get(['licenseStatus', 'vertical', 'safety']),
    chrome.storage.local.get(['monitoringOn', 'lastCheckAt', 'monitorGroups']),
    chrome.runtime.sendMessage({ type: 'GET_UPTIME' }).catch(() => null),
  ]);
  const s = { ...SAFETY_DEFAULTS, ...(sync.safety || {}) };
  const h = new Date().getHours();
  const inHours = s.activeStartHour <= s.activeEndHour
    ? h >= s.activeStartHour && h < s.activeEndHour
    : h >= s.activeStartHour || h < s.activeEndHour;
  const groups = (local.monitorGroups || []).length;
  const kws = (config.keywords || []).length;
  const ago = local.lastCheckAt ? Math.round((Date.now() - local.lastCheckAt) / 60000) : null;
  const agoText = ago === null ? 'never' : ago < 60 ? `${ago} min ago` : ago < 1440 ? `${Math.round(ago / 60)} h ago` : `${Math.round(ago / 1440)} days ago`;
  const recent = ago !== null && ago <= 90;

  // [label, ok (true / false / null = can't tell), what to do when not ok]
  const rows = [
    ['License active', sync.licenseStatus === 'active', 'Enter your license key on the License tab.'],
    ['Trade picked in setup', !!sync.vertical, 'Run the setup wizard so it knows what to look for.'],
    [`Groups watched: ${groups}`, groups > 0, 'Add your town’s Facebook groups on the Groups tab.'],
    [`Keywords: ${kws}`, kws > 0, 'Run the setup wizard or add keywords on the Keywords tab.'],
    ['Monitoring switched on', !!local.monitoringOn, 'Click the AnyoneNear icon and turn monitoring on.'],
    [`Last group check: ${agoText}`, recent ? true : inHours ? false : null,
      inHours ? 'Keep Chrome open on this computer; checks run every few minutes during your active hours.'
              : `Outside your active hours (${s.activeStartHour}:00–${s.activeEndHour}:00); checks resume then.`],
    ['Replies point people to your Page', !!(config.businessPageName || config.messengerUrl), 'Add your Facebook Page name in Settings.'],
    ['Leads go to your lead inbox', !!config.ghlLocationId, 'Your account isn’t linked yet — contact support.'],
  ];
  if (uptime && uptime.pct !== null && uptime.activeHours >= 6) {
    rows.push([`Uptime, last 7 days: ${uptime.pct}%`, uptime.pct >= 90, 'Leave this computer on and Chrome open during your active hours.']);
  }

  const mark = (ok) => ok === true ? '<span style="color:var(--green2);">✓</span>'
    : ok === false ? '<span style="color:var(--red);">✗</span>' : '<span style="color:var(--dim);">–</span>';
  const allOk = rows.every(([, ok]) => ok !== false);
  el.style.background  = allOk ? 'rgba(63,185,80,0.06)' : 'rgba(248,81,73,0.06)';
  el.style.borderColor = allOk ? 'rgba(63,185,80,0.2)'  : 'rgba(248,81,73,0.25)';
  el.innerHTML = `
    <div style="font-size:13px;font-weight:600;color:${allOk ? 'var(--green2)' : 'var(--off)'};margin-bottom:10px;">
      ${allOk ? '✓ AnyoneNear is set up and watching your groups' : 'Is AnyoneNear working? A few things need attention'}</div>
    <div style="display:flex;flex-direction:column;gap:7px;font-size:13px;color:var(--muted);">
      ${rows.map(([label, ok, fix]) => `<div style="display:flex;gap:10px;">${mark(ok)}<div>${escHtml(label)}${ok === true ? '' : `<div style="font-size:12px;color:var(--dim);">${escHtml(fix)}</div>`}</div></div>`).join('')}
    </div>
    <div style="font-size:12px;color:var(--dim);margin-top:10px;">The AnyoneNear phone app shows the same “monitoring” status, so you can check from anywhere.</div>`;
}

// ── RENDER ─────────────────────────────────────────────────────────────────────
function renderAll() {
  renderUptime();
  renderGroups();
  renderKeywords();
  renderLeadFeed();
  updateStats();
  populateSettings();
  populateGhl();
  renderHealthChecklist();
}

// Uptime card: how much of the last 7 days' active hours monitoring was on.
// Below 90% it explains why posts were missed.
async function renderUptime() {
  const el = document.getElementById('uptime-card');
  if (!el) return;
  const u = await chrome.runtime.sendMessage({ type: 'GET_UPTIME' }).catch(() => null);
  if (!u || u.pct === null || u.activeHours < 6) { el.style.display = 'none'; return; }
  const good = u.pct >= 90;
  const color = good ? 'var(--green)' : u.pct >= 60 ? 'var(--orange)' : 'var(--red)';
  el.style.display = 'block';
  el.innerHTML = `
    <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;">
      <span style="font-size:22px;font-weight:700;color:${color};">${u.pct}%</span>
      <span style="color:var(--off);font-weight:600;">Uptime, last 7 days</span>
      <span style="color:var(--muted);">${u.onHours} of ${u.activeHours} active hours watched</span>
    </div>
    ${good
      ? '<div style="color:var(--muted);margin-top:4px;">Monitoring is running through your active hours.</div>'
      : `<div style="color:var(--light);margin-top:6px;">Your computer was asleep or Chrome was closed for part of your active hours, so posts in that time were missed.
         Leave this computer on and Chrome open during your active hours to catch every post.</div>`}`;
}

function renderGroups() {
  const list = document.getElementById('group-list');
  if (!list) return;

  if (config.groups.length === 0) {
    list.innerHTML = '<div style="color:var(--dim);font-size:13px;padding:16px 0;">No groups added yet. Add your first group above.</div>';
    return;
  }

  list.innerHTML = config.groups.map((g, i) => `
    <div class="group-item" id="gi-${i}">
      <div class="gi-icon" aria-hidden="true">${GROUP_ICON}</div>
      <div class="gi-info">
        <div class="gi-name" id="gi-name-${i}">${escHtml(g.name || extractGroupName(g.url))}</div>
        <div class="gi-url">${escHtml(g.url)}</div>
      </div>
      <div class="gi-status">
        <span class="badge ${g.active ? 'badge-green' : 'badge-dim'}">${g.active ? '● Live' : '○ Idle'}</span>
      </div>
      <div class="gi-actions">
        <button class="btn btn-ghost btn-sm" data-action="rename-group" data-index="${i}" title="Rename">Rename</button>
        <button class="btn btn-ghost btn-sm" data-action="open-group" data-url="${escHtml(g.url)}">Open</button>
        <button class="btn btn-danger btn-sm" data-action="remove-group" data-index="${i}">Remove</button>
      </div>
    </div>
  `).join('');
}

function renderKeywords() {
  const singles = config.keywords.filter(k => !k.includes('+'));
  const ands    = config.keywords.filter(k => k.includes('+'));

  const renderWrap = (id, kws) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = kws.length === 0
      ? '<span style="color:var(--dim);font-size:12px;">None added yet</span>'
      : kws.map(k => `
          <span class="kw-tag">
            ${k.includes('+')
              ? k.split('+').map((t,i) => (i>0 ? '<span class="kw-and"> + </span>' : '') + escHtml(t)).join('')
              : escHtml(k)}
            <button class="kw-remove" data-action="remove-keyword" data-kw="${escHtml(k)}">×</button>
          </span>
        `).join('');
  };

  renderWrap('single-kw-wrap', singles);
  renderWrap('and-kw-wrap', ands);
  const sb = document.getElementById('clear-single-kw'), ab = document.getElementById('clear-and-kw');
  if (sb) sb.style.display = singles.length ? '' : 'none';
  if (ab) ab.style.display = ands.length ? '' : 'none';
}

// Removes every keyword of one type after a confirmation. The other type stays.
async function clearKeywords(type) {
  const isAnd = type === 'and';
  const gone = config.keywords.filter(k => k.includes('+') === isAnd);
  if (!gone.length) return;
  if (!confirm(`Remove all ${gone.length} ${isAnd ? 'AND groups' : 'single keywords'}? This can't be undone.`)) return;
  config.keywords = config.keywords.filter(k => k.includes('+') !== isAnd);
  await saveConfig({ keywords: config.keywords });
  renderKeywords();
  toast(`Cleared ${gone.length} ${isAnd ? 'AND groups' : 'single keywords'}`);
}

function renderLeadFeed() {
  const feed = document.getElementById('lead-feed');
  if (!feed) return;

  const recent = leads.slice(0, 30);

  if (recent.length === 0) {
    feed.innerHTML = '<div class="lf-empty">📡 No leads yet — start monitoring to begin detecting buyer intent posts in your groups.</div>';
    document.getElementById('lf-count').textContent = '0 leads';
    return;
  }

  document.getElementById('lf-count').textContent = `${leads.length} lead${leads.length !== 1 ? 's' : ''}`;
  feed.innerHTML = recent.map(lead => renderLeadRow(lead)).join('');
  attachLeadActions(feed);
}

function renderAllLeads() {
  const feed = document.getElementById('all-leads-feed');
  if (!feed) return;

  if (leads.length === 0) {
    feed.innerHTML = '<div class="lf-empty">No leads stored yet.</div>';
    return;
  }

  feed.innerHTML = leads.map(lead => renderLeadRow(lead)).join('');
  attachLeadActions(feed);
}

// Comment status as recorded by background.js (older leads predate the field).
function leadStatus(lead) {
  return lead.commentStatus || (lead.commented ? 'posted' : lead.postUrl ? 'pending' : 'manual');
}

function renderLeadRow(lead) {
  // Coerced to a number — the score comes back from the model and used to be
  // inserted into innerHTML as-is.
  const score = Math.min(10, Math.max(0, Math.round(Number(lead.intentScore)) || 0));
  const scoreClass = score >= 8 ? 'high' : score >= 5 ? 'medium' : 'low';
  const scoreLabel = score ? `${score}` : '?';
  const time = formatTime(lead.timestamp);
  const kws = (lead.matchedKeywords || []).map(k => `<span class="lr-kw">${escHtml(k)}</span>`).join('');

  const id   = escHtml(lead.id);
  const url  = escHtml(lead.postUrl || lead.sourceUrl || '');
  const view = url ? `<button class="btn btn-ghost btn-sm" data-action="open-group" data-url="${url}">View</button>` : '';
  const actions = {
    posted:  `<span class="badge badge-green">✓ Posted</span>`,
    queued:  `<span class="badge badge-blue">⏳ Queued</span>`,
    failed:  `<span class="badge badge-red" title="${escHtml(lead.commentError || '')}">Not posted</span>${view}`,
    skipped: `<span class="badge badge-dim">Skipped</span>`,
    expired: `<span class="badge badge-dim">Expired</span>${view}`,
    manual:  `<span class="badge badge-dim" title="No direct post link — reply by hand">Reply by hand</span>${view}`,
    pending: `<button class="btn btn-primary btn-sm lr-send" data-id="${id}">Send →</button>
              <button class="btn btn-ghost btn-sm lr-skip" data-id="${id}">Skip</button>`,
  }[leadStatus(lead)] || '';

  return `
    <div class="lead-row" data-id="${escHtml(lead.id)}">
      <div class="lr-score ${scoreClass}">${scoreLabel}</div>
      <div class="lr-info">
        <div class="lr-meta">
          <span class="lr-group">${escHtml(lead.groupName || 'Unknown group')}</span>
          <span class="lr-time">${time}</span>
        </div>
        ${lead.intentSummary ? `<div class="lr-summary">${escHtml(lead.intentSummary)}</div>` : ''}
        <div class="lr-text">${escHtml(lead.snippet || lead.postText || '')}</div>
        <div class="lr-kws">${kws}</div>
      </div>
      <div class="lr-actions">${actions}</div>
    </div>
  `;
}

function attachLeadActions(container) {
  container.querySelectorAll('.lr-send').forEach(btn => {
    btn.addEventListener('click', () => {
      const leadId = btn.dataset.id;
      // Approval only QUEUES the comment; background.js posts it when the
      // safety limits allow and records the real outcome on the lead, which
      // re-renders the feed through the storage listener.
      chrome.runtime.sendMessage({ type: 'APPROVE_COMMENT', leadId }, (res) => {
        if (res?.ok) {
          const when = res.eta && res.eta - Date.now() > 90000
            ? `around ${new Date(res.eta).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
            : 'shortly';
          toast(`Comment queued ✓ — posts ${when}`, 'success');
        } else if (res?.reason === 'no_permalink') {
          toast('No direct link to this post — reply to it by hand', 'error');
        } else if (res?.reason === 'already_decided') {
          toast(res.status === 'skipped' ? 'Already skipped from your phone' : 'Already sent from your phone', 'success');
        } else {
          toast('Too late — this lead expired, nothing was posted', 'error');
        }
      });
    });
  });

  container.querySelectorAll('.lr-skip').forEach(btn => {
    btn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'SKIP_LEAD', leadId: btn.dataset.id });
    });
  });
}

// ── STATS ──────────────────────────────────────────────────────────────────────
function updateStats() {
  const today = new Date().toDateString();
  const todayLeads = leads.filter(l => new Date(l.timestamp).toDateString() === today);
  const qualified  = todayLeads.filter(l => l.intentScore >= 7);
  const commented  = leads.filter(l => leadStatus(l) === 'posted');

  document.getElementById('stat-leads-today').textContent = todayLeads.length;
  document.getElementById('stat-qualified').textContent   = qualified.length;
  document.getElementById('stat-commented').textContent   = commented.length;
  document.getElementById('stat-groups').textContent      = config.groups.length;

  renderLimitNotice();

  const badge = document.getElementById('leads-badge');
  const pending = leads.filter(l => leadStatus(l) === 'pending').length;
  if (pending > 0) {
    badge.textContent = pending;
    badge.style.display = 'inline';
  } else {
    badge.style.display = 'none';
  }
}

// ── SIDEBAR STATUS ─────────────────────────────────────────────────────────────
function updateSidebarStatus() {
  const dot  = document.getElementById('monitor-status-dot');
  const text = document.getElementById('monitor-status-text');
  const sub  = document.getElementById('monitor-status-sub');

  if (cycleActive) {
    dot.className  = 'status-dot active';
    text.textContent = 'Monitoring active';
    sub.textContent  = `${config.groups.length} groups · cycling`;
  } else if (config.groups.length === 0) {
    dot.className  = 'status-dot inactive';
    text.textContent = 'No groups added';
    sub.textContent  = 'Add groups to start';
  } else {
    dot.className  = 'status-dot warning';
    text.textContent = 'Monitor paused';
    sub.textContent  = `${config.groups.length} groups ready`;
  }
}

// ── LEAD POLLING ───────────────────────────────────────────────────────────────
// Re-render on every change to the stored leads — new leads AND status
// changes (queued → posted / failed). The old 2s poll only noticed new leads.
let leadListenerInstalled = false;
function startLeadPolling() {
  if (leadListenerInstalled) return;
  leadListenerInstalled = true;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.leads) {
      leads = changes.leads.newValue || [];
      renderLeadFeed();
      renderAllLeads();
      updateStats();
    }
    if (changes.backendLimit) renderLimitNotice();
    if (changes.ghlSetup) { config.ghlSetup = changes.ghlSetup.newValue || null; populateGhl(); }
    if (changes.addons)   { config.addons   = changes.addons.newValue   || {};   populateGhl(); renderUpgrades(); }
    if (changes.usage)    { config.usage    = changes.usage.newValue    || null; renderUpgrades(); }
    if (changes.ownerAppUrl) { config.ownerAppUrl = changes.ownerAppUrl.newValue || ''; populateOwnerApp(); }
  });
}

// Surfaces a group-cap / monthly-quota rejection from the backend, which
// otherwise just silently drops leads.
async function renderLimitNotice() {
  const el = document.getElementById('limit-notice');
  if (!el) return;
  const { backendLimit } = await chrome.storage.local.get('backendLimit');
  if (backendLimit && Date.now() - backendLimit.at < 24 * 60 * 60 * 1000) {
    el.textContent = `⚠️ ${backendLimit.message} Leads from this are being skipped.`;
    el.style.display = 'block';
  } else {
    el.style.display = 'none';
  }
}

// ── TAB CYCLING ENGINE ─────────────────────────────────────────────────────────
// Opens a single background Facebook tab and cycles through each monitored group.
// The content script scans each group and reports leads back via storage.

// ── Tab Cycling — delegated to background.js ──────────────────────────────────
// Cycling now runs in background.js so it persists when the dashboard closes
// and never accidentally navigates a tab the user is actively using.
// Dashboard sends START_CYCLING/STOP_CYCLING messages and listens for status.

let cycleTabId = null; // unused — kept to avoid reference errors

async function toggleCycling() {
  if (cycleActive) stopCycling();
  else startCycling();
}

async function startCycling() {
  if (config.groups.length === 0) {
    toast('Add at least one group first', 'error');
    showPanel('groups');
    return;
  }
  cycleActive = true;
  const btn = document.getElementById('cycle-btn');
  const bar = document.getElementById('scanning-bar');
  if (btn) btn.textContent = '⏹ Stop cycling';
  if (bar) bar.style.display = 'flex';
  updateSidebarStatus();

  // background.js reads the groups from storage and picks a randomized
  // per-group dwell from the Safety limits.
  chrome.runtime.sendMessage({ type: 'START_CYCLING' });
}

function stopCycling() {
  cycleActive = false;
  const btn = document.getElementById('cycle-btn');
  const bar = document.getElementById('scanning-bar');
  if (btn) btn.textContent = '▶ Start cycling';
  if (bar) bar.style.display = 'none';
  config.groups.forEach(g => g.active = false);
  renderGroups();
  updateSidebarStatus();
  chrome.runtime.sendMessage({ type: 'STOP_CYCLING' });
}

// Receive cycle status updates from background.js
chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== 'CYCLE_STATUS') return;
  const nameEl   = document.getElementById('sb-group-name');
  const statusEl = document.getElementById('sb-status-text');
  const progEl   = document.getElementById('sb-progress');
  const bar      = document.getElementById('scanning-bar');
  const btn      = document.getElementById('cycle-btn');

  if (message.active) {
    cycleActive = true;
    if (bar)      bar.style.display  = 'flex';
    if (btn)      btn.textContent    = '⏹ Stop cycling';
    if (nameEl)   nameEl.textContent   = message.paused ? `Paused until ${message.resumeAt ? new Date(message.resumeAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : 'your active hours start'}` : (message.groupName || 'Scanning…');
    if (statusEl) statusEl.innerHTML   = message.paused ? 'Outside your active hours. <a href="#settings" data-action="nav" data-panel="settings" style="color:var(--blue2);">Change them in Settings</a>' : 'Scanning posts…';
    if (progEl)   progEl.textContent   = `${(message.index || 0) + 1} / ${message.total || 1}`;

    // Mirror the real cycling state (background.js is the source of truth)
    // onto the per-group Live/Idle badges. In memory only — writing it back
    // to monitorGroups made two open dashboard tabs overwrite each other's
    // group edits.
    let changed = false;
    config.groups.forEach(g => {
      const isCurrent = !message.paused && (g.name || extractGroupName(g.url)) === message.groupName;
      if (g.active !== isCurrent) { g.active = isCurrent; changed = true; }
    });
    if (changed) renderGroups();
  } else {
    cycleActive = false;
    if (bar) bar.style.display = 'none';
    if (btn) btn.textContent   = '▶ Start cycling';
    if (config.groups.some(g => g.active)) {
      config.groups.forEach(g => g.active = false);
      renderGroups();
    }
  }
  updateSidebarStatus();
});

// Sync cycle state when dashboard opens
function syncCycleState() {
  chrome.runtime.sendMessage({ type: 'GET_CYCLE_STATUS' }, (res) => {
    if (chrome.runtime.lastError || !res) return;
    const btn = document.getElementById('cycle-btn');
    const bar = document.getElementById('scanning-bar');
    cycleActive = !!res.active;
    if (res.active) {
      if (btn) btn.textContent = '⏹ Stop cycling';
      if (bar) bar.style.display = 'flex';
      const nameEl = document.getElementById('sb-group-name');
      const progEl = document.getElementById('sb-progress');
      if (nameEl) nameEl.textContent = res.groupName || 'Scanning…';
      if (progEl) progEl.textContent = `${(res.index || 0) + 1} / ${res.total || 1}`;
    } else {
      if (btn) btn.textContent = '▶ Start cycling';
      if (bar) bar.style.display = 'none';
    }
    updateSidebarStatus();
  });
}



// Group link boxes start with "https://www.facebook.com/groups/": pasting a
// full link over just that start replaces it, and a bare start isn't a group.
const GROUP_PREFIX = 'https://www.facebook.com/groups/';
const isGroupUrl = (u) => /facebook\.com\/groups\/[^/?#\s]+/i.test(String(u || ''));
function prefillGroupInput(el) {
  if (!el || el.dataset.prefill) return;
  el.dataset.prefill = '1';
  if (!el.value) el.value = GROUP_PREFIX;
  el.addEventListener('paste', (e) => {
    const t = (e.clipboardData || window.clipboardData)?.getData('text') || '';
    if (el.value.trim() === GROUP_PREFIX && /^https?:\/\//i.test(t.trim())) { e.preventDefault(); el.value = t.trim(); el.dispatchEvent(new Event('input')); }
  });
  el.addEventListener('input', () => { const v = el.value, i = v.lastIndexOf('http'); if (i > 0) el.value = v.slice(i); });
}

// ── GROUP MANAGEMENT ───────────────────────────────────────────────────────────
async function addGroup() {
  const urlInput  = document.getElementById('group-url-input');
  const nameInput = document.getElementById('group-name-input');
  const url  = urlInput.value.trim();
  const name = nameInput.value.trim() || extractGroupName(url);

  if (!isGroupUrl(url)) {
    toast('Please enter a valid Facebook group URL', 'error');
    return;
  }

  if (config.groups.find(g => g.url === url)) {
    toast('This group is already in your list', 'error');
    return;
  }

  // The server rejects leads from any group past the plan's cap, so extra
  // groups would silently produce nothing.
  if (config.groups.length >= config.maxGroups) {
    toast(`Your plan covers ${config.maxGroups} groups — remove one to add another`, 'error');
    return;
  }

  config.groups.push({ url, name, active: false });
  await saveConfig({ groups: config.groups });
  urlInput.value  = GROUP_PREFIX;
  nameInput.value = '';
  renderGroups();
  updateStats();
  toast(`Added: ${name}`, 'success');
}

async function removeGroup(index) {
  config.groups.splice(index, 1);
  await saveConfig({ groups: config.groups });
  renderGroups();
  updateStats();
  toast('Group removed', 'info');
}

async function renameGroup(index) {
  const group = config.groups[index];
  if (!group) return;

  const nameEl = document.getElementById(`gi-name-${index}`);
  if (!nameEl) return;

  const currentName = group.name || extractGroupName(group.url);

  // Replace name text with inline input
  const input = document.createElement('input');
  input.type  = 'text';
  input.value = currentName;
  input.dataset.renameIndex = index;
  input.style.cssText = `
    background:var(--bg);border:1px solid var(--blue);border-radius:4px;
    padding:3px 8px;color:var(--off);font-size:13px;font-weight:600;
    width:180px;outline:none;font-family:var(--font);
  `;

  nameEl.innerHTML = '';
  nameEl.appendChild(input);
  input.focus();
  input.select();

  const save = async () => {
    const newName = input.value.trim();
    if (newName && config.groups[index]) {
      config.groups[index].name = newName;
      await saveConfig({ groups: config.groups });
      toast('Nickname updated', 'success');
    }
    renderGroups();
  };

  input.addEventListener('blur',    save);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter')  { input.blur(); }
    if (e.key === 'Escape') { renderGroups(); }
  });
}

function extractGroupName(url) {
  try {
    const match = url.match(/facebook\.com\/groups\/([^/?]+)/);
    if (match) return decodeURIComponent(match[1]).replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  } catch {}
  return 'Facebook Group';
}

const GROUP_ICON = '<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></svg>';
function getGroupEmoji(name) {
  const n = (name || '').toLowerCase();
  if (n.includes('hvac') || n.includes('ac') || n.includes('heat')) return '❄️';
  if (n.includes('plumb') || n.includes('pipe') || n.includes('water')) return '🔧';
  if (n.includes('roof')) return '🏠';
  if (n.includes('electric')) return '⚡';
  if (n.includes('landscape') || n.includes('garden') || n.includes('lawn')) return '🌿';
  if (n.includes('paint')) return '🎨';
  return '🏘️';
}

// ── KEYWORD MANAGEMENT ─────────────────────────────────────────────────────────
async function addKeyword(type) {
  const inputId = type === 'and' ? 'and-kw-input' : 'single-kw-input';
  const input = document.getElementById(inputId);
  const val = input.value.trim().toLowerCase();

  if (!val) return;

  if (type === 'and' && !val.includes('+')) {
    toast('AND group requires a + between terms (e.g. plumber+looking for)', 'error');
    return;
  }

  if (config.keywords.includes(val)) {
    toast('Keyword already exists', 'error');
    return;
  }

  config.keywords.push(val);
  await saveConfig({ keywords: config.keywords });
  input.value = '';
  renderKeywords();

  // Notify content script
  chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });
  toast('Keyword added', 'success');
}

async function removeKeyword(kw) {
  config.keywords = config.keywords.filter(k => k !== kw);
  await saveConfig({ keywords: config.keywords });
  renderKeywords();
  chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });
}

// ── GHL INTEGRATION ────────────────────────────────────────────────────────────
// GHL panel is mostly read-only — webhook auto-configured via provision-customer.
// The one thing worth populating: point "Open GHL →" straight at this
// customer's own sub-account Settings/Integrations page instead of the
// generic app.gohighlevel.com root, which previously made the customer
// re-navigate there by hand every time. Needs ghlLocationId, which only
// exists in local storage after an /activate response that included it
// (added server-side alongside this fix) — falls back to the generic link
// until the next activation populates it.
//
// "settings/lc-integrations" is GHL's Integrations page (confirmed
// 2026-09-23; the earlier "settings/integrations" guess was wrong).
function populateGhl() {
  const link = document.getElementById('open-ghl-integrations-link');
  if (link && config.ghlLocationId) {
    link.href = `https://app.gohighlevel.com/v2/location/${encodeURIComponent(config.ghlLocationId)}/settings/lc-integrations`;
  }
  renderSetupChecklist();
  populateOwnerApp();
}

// Guide step 3 — the AnyoneNear phone app (replaced the LeadConnector
// app, docs/owner-app-scope.md phase 5). The address comes from /activate
// (OWNER_APP_URL on the server); until it's set the step still shows and
// points at the welcome email instead of a link.
function populateOwnerApp() {
  const url    = config.ownerAppUrl;
  const link   = document.getElementById('owner-app-link');
  const noLink = document.getElementById('owner-app-nolink');
  if (link) {
    link.style.display = url ? '' : 'none';
    if (url) { link.href = url + '/install.html'; link.textContent = url.replace(/^https?:\/\//, ''); }
  }
  if (noLink) noLink.style.display = url ? 'none' : '';
}

// Setup checklist built from what provisioning actually verified on the
// customer's GHL sub-account (ghlSetup, returned by /activate). Replaces a
// hardcoded all-green banner that also claimed things that never existed
// (GHL approve/reject buttons, a webhook URL).
function renderSetupChecklist() {
  const el = document.getElementById('ghl-setup-checklist');
  if (!el) return;
  const s = config.ghlSetup;
  const hasLocation = !!config.ghlLocationId;

  const rows = [
    ['GHL sub-account created',                 hasLocation],
    ['Lead pipeline ready',            s ? s.pipeline : null],
    ['Custom contact fields in place',          s ? s.customFields : null],
    ['Messenger AI nurture workflow published', s ? s.workflows : null],
    ['Messenger contacts merge onto leads',     s ? s.facebookNameMerge : null],
    ['Leads sent straight to your GHL pipeline', hasLocation],
  ];
  // Paid add-ons get their own rows (and the texting-number card below).
  const addons = config.addons || {};
  if (addons.sms)      rows.push(['Business texting number added (SMS add-on)', s ? (s.phoneNumber ?? null) : null]);
  if (addons.voice_ai) rows.push(['Voice AI follow-up agent (add-on)', true]);

  const smsCard = document.getElementById('sms-number-card');
  if (smsCard) smsCard.style.display = addons.sms ? '' : 'none';
  const smsUpsell = document.getElementById('sms-upsell-note');
  if (smsUpsell) smsUpsell.style.display = addons.sms ? 'none' : '';
  const icon = (ok) => ok === true
    ? '<span style="color:var(--green2);">✓</span>'
    : ok === false ? '<span style="color:var(--red);">✗</span>'
    : '<span style="color:var(--dim);">?</span>';

  const allOk = rows.every(([, ok]) => ok === true);
  const anyBad = rows.some(([, ok]) => ok === false);
  el.style.background  = allOk ? 'rgba(63,185,80,0.06)' : anyBad ? 'rgba(248,81,73,0.06)' : 'var(--bg2)';
  el.style.borderColor = allOk ? 'rgba(63,185,80,0.2)'  : anyBad ? 'rgba(248,81,73,0.25)' : 'var(--border)';

  const heading = allOk ? '✓ Your GHL account is set up'
    : anyBad ? 'Some setup steps didn’t complete — contact support and we’ll fix them'
    : 'Setup status';
  const note = !s && hasLocation
    ? '<div style="font-size:12px;color:var(--dim);margin-top:10px;">“?” means this account was set up before automatic checks existed — support can confirm it for you.</div>'
    : '';

  el.innerHTML = `
    <div style="font-size:13px;font-weight:600;color:${allOk ? 'var(--green2)' : 'var(--off)'};margin-bottom:10px;">${heading}</div>
    <div style="display:flex;flex-direction:column;gap:7px;font-size:13px;color:var(--muted);">
      ${rows.map(([label, ok]) => `<div style="display:flex;gap:10px;">${icon(ok)} ${escHtml(label)}</div>`).join('')}
    </div>${note}`;
}

// ── SETTINGS ──────────────────────────────────────────────────────────────────
// Hourly cloud scan card (Settings).
async function populateCloudCard() {
  const { cloud } = await chrome.storage.local.get('cloud');
  const c = cloud || { enabled: false, hasApifyToken: false, needsOwnKey: true, serviceMode: 'local', radiusMi: 30, area: '' };
  const $ = (id) => document.getElementById(id);
  if (!$('cloud-card')) return;
  $('cloud-enabled').checked = !!c.enabled;
  $('cloud-service-mode').value = c.serviceMode || 'local';
  $('cloud-radius').value = c.radiusMi || 30;
  $('cloud-radius-field').style.display = c.serviceMode === 'anywhere' ? 'none' : '';
  $('cloud-area-fields').style.display = c.serviceMode === 'anywhere' ? 'none' : '';
  $('cloud-city').value = c.city || '';
  $('cloud-state').value = c.state || '';
  $('cloud-area-hint').textContent = c.serviceMode === 'anywhere'
    ? 'Replies go to buyers anywhere; the AI only checks that they need what you sell.'
    : (c.area ? `Posts clearly asking for help far outside ${c.area} are skipped.` : 'Add your city and state below so we know your area.');
  const token = $('cloud-apify-token');
  token.value = '';
  token.placeholder = c.hasApifyToken ? 'Saved ✓ (paste a new one to replace it)' : 'apify_api_…';
  if (!c.needsOwnKey) {
    $('cloud-key-hint').textContent = c.hasApifyToken
      ? 'Your plan includes cloud scanning; your own Apify token is being used. Clear the box and save to use ours instead.'
      : "Included with your plan. You don't need an Apify account.";
  }
  // Monthly allowance on our key: posts read so far vs. the plan's cap.
  if (c.postsCap && !c.hasApifyToken) {
    const used = Math.min(c.postsUsed || 0, c.postsCap);
    const full = used >= c.postsCap;
    $('cloud-key-hint').textContent = `Included with your plan: ${c.postsCap.toLocaleString()} posts a month. ${used.toLocaleString()} read so far this month.`
      + (full ? ' This month\'s allowance is used up, so cloud scanning pauses until your billing date. Add your own Apify token to keep it going.' : '');
  }
  $('cloud-status').textContent = c.enabled
    ? (c.needsOwnKey && !c.hasApifyToken ? 'Cloud scan is on, but it needs your Apify token before it can run.' : 'Cloud scan is on. It runs at 5 minutes past every hour.')
    : 'Cloud scan is off. Turn it on above and save.';
}

async function saveCloudCard() {
  const $ = (id) => document.getElementById(id);
  const settings = {
    enabled: $('cloud-enabled').checked,
    serviceMode: $('cloud-service-mode').value,
    radiusMi: Number($('cloud-radius').value) || 30,
    city: $('cloud-city').value.trim(),
    state: $('cloud-state').value.trim(),
  };
  const t = $('cloud-apify-token').value.trim();
  if (t) settings.apifyToken = t;
  $('cloud-status').textContent = 'Saving…';
  const res = await chrome.runtime.sendMessage({ type: 'SAVE_CLOUD_SETTINGS', settings }).catch(() => null);
  if (!res?.ok) { $('cloud-status').textContent = res?.error || "Couldn't save. Try again."; return; }
  toast('Cloud scan settings saved', 'success');
  await populateCloudCard();
}

async function populateSettings() {
  populateCloudCard();
  const { theme = 'system' } = await chrome.storage.sync.get('theme');
  const themeRadio = document.querySelector(`input[name="theme"][value="${theme}"]`);
  if (themeRadio) themeRadio.checked = true;
  const f = (id, val) => { const el = document.getElementById(id); if (el) el.value = val ?? ''; };
  f('page-name-input',     config.businessPageName);
  f('messenger-url-input', config.messengerUrl);
  const { tagPageInReplies } = await chrome.storage.sync.get('tagPageInReplies');
  const tagBox = document.getElementById('tag-page-input');
  if (tagBox) tagBox.checked = tagPageInReplies !== false;   // on by default
  const { replyMode, autoPostDefault } = await chrome.storage.sync.get(['replyMode', 'autoPostDefault']);
  const { reviewUntil } = await chrome.storage.local.get('reviewUntil');
  const modeSel = document.getElementById('reply-mode-input');
  if (modeSel) {
    modeSel.value = replyMode === 'auto' || replyMode === 'review' ? replyMode : 'default';
    const def = modeSel.querySelector('option[value="default"]');
    if (def) def.textContent = autoPostDefault === true
      ? 'Recommended: automatic after a 48-hour review period'
      : 'Recommended for now: review every reply';
  }
  const modeNote = document.getElementById('reply-mode-note');
  if (modeNote && modeSel?.value === 'default') {
    if (autoPostDefault !== true) {
      modeNote.textContent = 'While we fine-tune the AI, each reply waits for your OK. Choose Automatic whenever you\u2019re happy with how it sounds \u2014 replies to buyers the AI is confident about (7/10 or higher) will then post on their own, within your safety limits.';
    } else if (reviewUntil && Date.now() < reviewUntil) {
      modeNote.textContent = `Review period: replies wait for your OK until ${new Date(reviewUntil).toLocaleString()}, then post automatically for buyers the AI is confident about (7/10 or higher), within your safety limits.`;
    }
  }

  const { safety } = await chrome.storage.sync.get('safety');
  const s = { ...SAFETY_DEFAULTS, ...(safety || {}) };
  for (const k of Object.keys(SAFETY_DEFAULTS)) f(`safety-${k}`, s[k]);

  // Which preset is this? (Older saves have no preset name — match by values.)
  const preset = s.preset || Object.keys(SAFETY_PRESETS).find((p) =>
    Object.keys(SAFETY_DEFAULTS).every((k) => SAFETY_PRESETS[p][k] === s[k]))
    || (s.dailyCap >= 25 ? 'busy' : s.dailyCap >= 15 ? 'balanced' : 'careful');
  const radio = document.querySelector(`input[name="safety-preset"][value="${preset}"]`);
  if (radio) radio.checked = true;
  showSafetyCustom(preset === 'custom');
  updateSafetyWarning(s);
}

function showSafetyCustom(show) {
  const el = document.getElementById('safety-custom');
  if (el) el.style.display = show ? '' : 'none';
}

function selectedSafetyPreset() {
  return document.querySelector('input[name="safety-preset"]:checked')?.value || 'careful';
}

// Live feedback while choosing: show the numbers for Custom, the warning for
// anything more active than Careful.
document.addEventListener('change', (e) => {
  if (e.target.name === 'safety-preset') {
    const p = e.target.value;
    showSafetyCustom(p === 'custom');
    updateSafetyWarning(p === 'custom' ? readSafetyForm() : SAFETY_PRESETS[p]);
  } else if (String(e.target.id || '').startsWith('safety-')) {
    updateSafetyWarning(readSafetyForm());
  }
});

function readSafetyForm() {
  const n = (k) => parseInt(document.getElementById(`safety-${k}`)?.value, 10);
  const clamp = (v, lo, hi, dflt) => Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : dflt;
  const d = SAFETY_DEFAULTS;
  const s = {
    dailyCap:        clamp(n('dailyCap'), 1, 50, d.dailyCap),
    minGapMin:       clamp(n('minGapMin'), 1, 240, d.minGapMin),
    maxGapMin:       clamp(n('maxGapMin'), 1, 240, d.maxGapMin),
    dwellMinSec:     clamp(n('dwellMinSec'), 60, 3600, d.dwellMinSec),
    dwellMaxSec:     clamp(n('dwellMaxSec'), 60, 3600, d.dwellMaxSec),
    activeStartHour: clamp(n('activeStartHour'), 0, 23, d.activeStartHour),
    activeEndHour:   clamp(n('activeEndHour'), 0, 24, d.activeEndHour),
  };
  if (s.maxGapMin < s.minGapMin)     s.maxGapMin   = s.minGapMin;
  if (s.dwellMaxSec < s.dwellMinSec) s.dwellMaxSec = s.dwellMinSec;
  return s;
}

function isMoreActiveThanDefault(s) {
  const d = SAFETY_DEFAULTS;
  const hours = (x) => ((x.activeEndHour - x.activeStartHour) + 24) % 24 || 24;
  return s.dailyCap > d.dailyCap || s.minGapMin < d.minGapMin || s.maxGapMin < d.maxGapMin
    || s.dwellMinSec < d.dwellMinSec || hours(s) > hours(d);
}

function updateSafetyWarning(s) {
  const el = document.getElementById('safety-warning');
  if (el) el.style.display = isMoreActiveThanDefault(s) ? 'block' : 'none';
  // Stored settings that were already acknowledged stay ticked.
  const ack = document.getElementById('safety-ack');
  if (ack && s.riskAcknowledgedAt) ack.checked = true;
}

async function saveSafetySettings(reset = false) {
  const preset = reset ? 'careful' : selectedSafetyPreset();
  const s = preset === 'custom' ? readSafetyForm() : { ...SAFETY_PRESETS[preset] };

  // Anything more active than Careful needs the customer's explicit
  // acknowledgement, recorded with a timestamp.
  const risky = isMoreActiveThanDefault(s);
  const ack = document.getElementById('safety-ack');
  if (risky && !ack?.checked) {
    toast('Please tick the box to confirm you understand the risk to your Facebook account', 'error');
    ack?.focus();
    return;
  }
  await chrome.storage.sync.set({ safety: { ...s, preset, ...(risky ? { riskAcknowledgedAt: new Date().toISOString() } : {}) } });
  await populateSettings();
  chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });
  const label = { careful: 'Careful', balanced: 'Balanced', busy: 'Busy', custom: 'Custom' }[preset];
  toast(`Saved — ${label} mode`, 'success');
}

async function updateLicenseStatusCard() {
  const el = document.getElementById('license-status-body');
  if (!el) return;

  const sync = await chrome.storage.sync.get(['licenseStatus', 'plan', 'licenseExpiresAt', 'licenseError']);

  if (sync.licenseStatus === 'active') {
    el.innerHTML = `
      <span class="badge badge-green">● Active</span>
      <span style="margin-left:8px;font-weight:500;color:var(--off);text-transform:capitalize;">${escHtml(sync.plan || 'starter')} plan</span>
      <div style="font-size:12px;color:var(--dim);margin-top:4px;">Revalidates automatically every 24 hours</div>
      <button class="btn btn-outline btn-sm" style="margin-top:10px;" data-action="sign-out-license">Sign out of this license</button>
      <div style="font-size:12px;color:var(--dim);margin-top:4px;">Stops monitoring in this browser and frees it up so you can use your license on another computer. Your keywords and groups stay here.</div>
    `;
  } else if (sync.licenseStatus === 'invalid') {
    el.innerHTML = `
      <span class="badge badge-red">✗ Invalid</span>
      <div style="font-size:12px;color:var(--red);margin-top:4px;">${escHtml(sync.licenseError || 'License key not recognized')}</div>
      <button class="btn btn-outline btn-sm" style="margin-top:8px;" data-action="show-license-screen">Re-enter license key</button>
    `;
  } else {
    el.innerHTML = `<span class="badge badge-dim">Not activated</span>
      <button class="btn btn-outline btn-sm" style="margin-left:8px;" data-action="show-license-screen">Enter license key</button>`;
  }
}

async function saveBusinessSettings() {
  const name = document.getElementById('page-name-input').value.trim();
  const url  = document.getElementById('messenger-url-input').value.trim();
  const tag  = document.getElementById('tag-page-input')?.checked !== false;
  const mode = document.getElementById('reply-mode-input')?.value || 'default';
  await saveConfig({ businessPageName: name, messengerUrl: url, tagPageInReplies: tag });
  if (mode === 'auto' || mode === 'review') await chrome.storage.sync.set({ replyMode: mode });
  else await chrome.storage.sync.remove('replyMode');
  chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });
  toast('Business settings saved', 'success');
}

async function signOutLicense() {
  if (!confirm('Sign out of this license? Monitoring stops in this browser until you enter your license key again.')) return;
  const res = await chrome.runtime.sendMessage({ type: 'SIGN_OUT_LICENSE' }).catch(() => null);
  if (!res?.ok) { toast("Couldn't sign out. Try again.", 'error'); return; }
  isLicensed = false;
  hideSidebar();
  showPanel('license');
  toast('Signed out of this license', 'success');
}

// ── License Activation ────────────────────────────────────────────────────────
async function activateLicense() {
  const input = document.getElementById('license-key-input');
  const btn   = document.getElementById('activate-btn');
  const errEl = document.getElementById('license-error');
  const key   = input?.value.trim();

  if (!key) { showLicenseError('Please enter your license key'); return; }
  if (!/^[a-zA-Z0-9_-]{8,64}$/.test(key)) {
    showLicenseError('That doesn’t look like a license key — copy it exactly from your welcome email');
    return;
  }

  if (btn) { btn.textContent = 'Activating…'; btn.disabled = true; }
  if (errEl) errEl.style.display = 'none';

  // Get device ID
  const { deviceId } = await chrome.storage.local.get('deviceId');
  let dId = deviceId;
  if (!dId) {
    const arr = new Uint8Array(16);
    crypto.getRandomValues(arr);
    dId = Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
    await chrome.storage.local.set({ deviceId: dId });
  }

  const result = await chrome.runtime.sendMessage({
    type: 'ACTIVATE_LICENSE',
    licenseKey: key,
    deviceId:   dId,
  });

  if (btn) { btn.textContent = 'Activate →'; btn.disabled = false; }

  if (result?.valid) {
    isLicensed = true;
    showSidebar();
    toast(`✓ Activated — ${result.plan} plan`, 'success');
    await loadConfig();
    renderAll();
    updateSidebarStatus();
    startLeadPolling();
    updateLicenseStatusCard();
    if (config.groups.length === 0) {
      setTimeout(() => {
        if (typeof window.openWizard === 'function') window.openWizard();
        else showPanel('wizard');
      }, 400);
    } else {
      showPanel('monitor');
    }
  } else {
    showLicenseError(result?.error || 'Activation failed — please try again');
  }
}

function showLicenseError(msg) {
  const errEl = document.getElementById('license-error');
  if (errEl) { errEl.textContent = msg; errEl.style.display = 'block'; }
}

// ── WIZARD ────────────────────────────────────────────────────────────────────
function showWizStep(n) {
  wizStep = n;
  document.querySelectorAll('.wizard-step-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.ws').forEach(s => s.classList.remove('active'));
  document.getElementById(`wiz-step-${n}`)?.classList.add('active');
  document.getElementById(`wiz-tab-${n}`)?.classList.add('active');

  if (n === 2) renderQuickKeywords();
  if (n === 3) renderWizSummary();
}

function renderQuickKeywords() {
  const container = document.getElementById('quick-keywords');
  if (!container) return;

  const suggestions = [
    'need AC repair', 'HVAC help', 'air conditioner broken',
    'need a plumber', 'pipe burst', 'water heater',
    'roof repair', 'need a roofer', 'roof leak',
    'need an electrician', 'electrician recommendation',
    'looking for a contractor', 'anyone recommend',
  ];

  container.innerHTML = suggestions.map(s => `
    <button class="btn btn-ghost btn-sm" style="border:1px solid var(--border);" data-action="wiz-quick-add" data-kw="${s}">
      + ${s}
    </button>
  `).join('');
}

function wizQuickAdd(kw) {
  if (!wizKeywords.includes(kw)) {
    wizKeywords.push(kw);
    renderWizKeywords();
  }
}

function wizAddKeyword() {
  const input = document.getElementById('wiz-kw-input');
  const val = input.value.trim().toLowerCase();
  if (!val) return;
  if (!wizKeywords.includes(val)) {
    wizKeywords.push(val);
    renderWizKeywords();
  }
  input.value = '';
}

function renderWizKeywords() {
  const wrap = document.getElementById('wiz-kw-wrap');
  if (!wrap) return;
  wrap.innerHTML = wizKeywords.map(k => `
    <span class="kw-tag">
      ${escHtml(k)}
      <button class="kw-remove" data-action="wiz-remove-kw" data-kw="${escHtml(k)}">×</button>
    </span>
  `).join('');
}

function wizRemoveKw(kw) {
  wizKeywords = wizKeywords.filter(k => k !== kw);
  renderWizKeywords();
}

function wizAddGroup() {
  const urlInput  = document.getElementById('wiz-group-url');
  const nameInput = document.getElementById('wiz-group-name');
  const url  = urlInput.value.trim();
  const name = nameInput?.value.trim() || extractGroupName(url);

  if (!isGroupUrl(url)) {
    toast('Please enter a valid Facebook group URL', 'error');
    return;
  }
  if (!wizGroups.find(g => g.url === url)) {
    wizGroups.push({ url, name, active: false });
    renderWizGroups();
  }
  urlInput.value  = GROUP_PREFIX;
  if (nameInput) nameInput.value = '';
}

function renderWizGroups() {
  const list = document.getElementById('wiz-group-list');
  if (!list) return;
  if (wizGroups.length === 0) {
    list.innerHTML = '<div style="color:var(--dim);font-size:13px;">No groups added yet.</div>';
    return;
  }
  list.innerHTML = wizGroups.map((g, i) => `
    <div class="group-item" style="margin-bottom:8px;">
      <div class="gi-icon">${getGroupEmoji(g.name)}</div>
      <div class="gi-info">
        <div class="gi-name">${escHtml(g.name)}</div>
        <div class="gi-url">${escHtml(g.url)}</div>
      </div>
      <button class="btn btn-danger btn-sm" data-action="wiz-remove-group" data-index="${i}">Remove</button>
    </div>
  `).join('');
}

// wizSaveStep1 no longer needed — page/messenger come from license activation
// Kept as no-op for any residual calls
async function wizSaveStep1() { showWizStep(2); }

// Leads reach GHL through the backend (no webhook URL to enter) — no-op step.
async function wizSaveGhl() { showWizStep(3); }

function renderWizSummary() {
  const el = document.getElementById('wiz-summary');
  if (!el) return;

  const allGroups   = [...config.groups, ...wizGroups.filter(g => !config.groups.find(c => c.url === g.url))];
  const allKeywords = [...new Set([...config.keywords, ...wizKeywords])];
  const check = (v) => v ? '✅' : '⚠️';

  el.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:8px;font-size:13px;">
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:var(--r);">
        <span>${check(allGroups.length > 0)}</span>
        <span style="color:var(--muted);">Groups:</span>
        <span style="color:var(--off);font-weight:500;">${allGroups.length} group${allGroups.length !== 1 ? 's' : ''} to monitor</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:var(--r);">
        <span>${check(allKeywords.length > 0)}</span>
        <span style="color:var(--muted);">Keywords:</span>
        <span style="color:var(--off);font-weight:500;">${allKeywords.length} keyword${allKeywords.length !== 1 ? 's' : ''} active</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:var(--r);">
        <span>${check(config.ghlLocationId)}</span>
        <span style="color:var(--muted);">GHL:</span>
        <span style="color:var(--off);font-weight:500;">${config.ghlLocationId ? 'Linked to your sub-account ✓' : 'Not linked yet — contact support'}</span>
      </div>
    </div>
  `;
}

async function goLive() {
  const newGroups = wizGroups.filter(g => !config.groups.find(c => c.url === g.url));
  config.groups   = [...config.groups, ...newGroups];
  const newKws    = wizKeywords.filter(k => !config.keywords.includes(k));
  config.keywords = [...config.keywords, ...newKws];

  await saveConfig({ groups: config.groups, keywords: config.keywords });
  chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });
  showPanel('monitor');
  await startCycling();
  toast('🚀 AnyoneNear is live!', 'success');
}

// ── UTILS ─────────────────────────────────────────────────────────────────────
function openFbTab() {
  chrome.tabs.create({ url: 'https://www.facebook.com/groups/feed/', active: true });
}

function clearLeads() {
  if (!confirm('Clear all stored leads?')) return;
  leads = [];
  chrome.storage.local.set({ leads: [] });
  renderLeadFeed();
  renderAllLeads();
  updateStats();
  toast('Leads cleared', 'info');
}

function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatTime(ts) {
  if (!ts) return '';
  try {
    const d = new Date(ts);
    const now = new Date();
    const diff = (now - d) / 1000;
    if (diff < 60)    return `${Math.floor(diff)}s ago`;
    if (diff < 3600)  return `${Math.floor(diff/60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
    return d.toLocaleDateString();
  } catch { return ''; }
}

function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  // textContent, not innerHTML — messages include group names the user typed
  // and values that come back from the server.
  const span = document.createElement('span');
  span.textContent = msg;
  t.appendChild(span);
  c.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

// ── EVENT DELEGATION ──────────────────────────────────────────────────────────
// Handles ALL button clicks via data-action attributes.
// This replaces every inline onclick= handler (blocked by CSP).
// Also handles dynamically generated buttons (group remove, keyword remove)
// via data-action on the generated elements.

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]');
  if (!el) return;

  const action = el.dataset.action;

  switch (action) {

    // ── Navigation ──
    case 'nav':
      showPanel(el.dataset.panel);
      break;

    // ── License ──
    case 'activate-license':   activateLicense();                              break;
    case 'show-license-screen':showPanel('license');                           break;
    case 'sign-out-license':   signOutLicense();                                break;
    case 'save-cloud':         saveCloudCard();                                 break;
    case 'open-wizard':
      if (typeof window.openWizard === 'function') window.openWizard();
      break;

    // ── Monitor ──
    case 'open-fb-tab':   openFbTab();    break;
    case 'toggle-cycling': toggleCycling(); break;
    case 'clear-leads':   clearLeads();   break;
    case 'clear-keywords': clearKeywords(el.dataset.type); break;

    // ── Groups ──
    case 'add-group':     addGroup();     break;
    case 'remove-group':
      removeGroup(parseInt(el.dataset.index));
      break;
    case 'rename-group':
      renameGroup(parseInt(el.dataset.index));
      break;
    case 'open-group':
      window.open(el.dataset.url, '_blank');
      break;

    // ── Keywords ──
    case 'add-keyword':
      addKeyword(el.dataset.type);
      break;
    case 'remove-keyword':
      removeKeyword(el.dataset.kw);
      break;

    // ── Settings ──
    case 'save-business': saveBusinessSettings(); break;
    case 'save-safety':   saveSafetySettings();     break;
    case 'reset-safety':  saveSafetySettings(true); break;

    // ── Wizard ──
    case 'wiz-step':      showWizStep(parseInt(el.dataset.step)); break;
    case 'wiz-save-1':    wizSaveStep1();   break;
    case 'wiz-add-group': wizAddGroup();    break;
    case 'wiz-add-keyword': wizAddKeyword(); break;
    case 'wiz-save-ghl':  wizSaveGhl();     break;
    case 'go-live':       goLive();         break;
    case 'wiz-remove-group':
      wizGroups.splice(parseInt(el.dataset.index), 1);
      renderWizGroups();
      break;
    case 'wiz-quick-add':
      wizQuickAdd(el.dataset.kw);
      break;
    case 'wiz-remove-kw':
      wizRemoveKw(el.dataset.kw);
      break;
  }
});

// ── ENTER KEY SHORTCUTS ────────────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const id = e.target.id;
  if (id === 'group-url-input')  addGroup();
  if (id === 'single-kw-input')  addKeyword('single');
  if (id === 'and-kw-input')     addKeyword('and');
  if (id === 'wiz-group-url')    wizAddGroup();
  if (id === 'wiz-group-name')   wizAddGroup();
  if (id === 'wiz-kw-input')     wizAddKeyword();
  if (id === 'license-key-input') activateLicense();
});

// ── BOOT ──────────────────────────────────────────────────────────────────────
["group-url-input", "wiz-group-url"].forEach((id) => prefillGroupInput(document.getElementById(id)));
document.getElementById("an-open-app")?.addEventListener("click", () => chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" }).catch(() => {}));
init();

// Listen for storage changes — allows bypass via Service Worker console
// without needing to close and reopen the dashboard tab
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;
  if (!changes.licenseStatus) return;

  const newStatus = changes.licenseStatus.newValue;
  if (newStatus === 'active' && !isLicensed) {
    // Reload config and unlock
    loadConfig().then(() => {
      isLicensed = true;
      showSidebar();
      renderAll();
      updateSidebarStatus();
      startLeadPolling();
      updateLicenseStatusCard();
      if (config.groups.length === 0) {
        setTimeout(() => {
          if (typeof window.openWizard === 'function') window.openWizard();
          else showPanel('wizard');
        }, 300);
      } else {
        showPanel('monitor');
      }
    });
  } else if ((newStatus === 'none' || newStatus === 'invalid') && isLicensed) {
    // Lock down
    isLicensed = false;
    hideSidebar();
    showPanel('license');
  }
});

// ── UPGRADES ──────────────────────────────────────────────────────────────────
// Plan usage from /activate plus offers matched to what's happening in the
// customer's account (docs/pricing.md). Buying happens on the master's
// upgrade form; the add-on then switches on automatically.
const UPGRADE_URL = 'https://link.hookditup.com/widget/form/VgXHX9fQHTnDvQx6X1R4';   // AnyoneNear Upgrades order form (master)
const SUPPORT_PHONE = '(435) 236-2946';

const ADDON_CATALOG = [
  { key: 'pro',            name: 'Pro plan',               price: '$249/mo', blurb: '5 groups and 3,000 AI lead checks a month.' },
  { key: 'sms',            name: 'SMS Follow-up',          price: '$49/mo',  blurb: 'Texts qualified leads a confirmation from your business number. 500 texts included.' },
  { key: 'voice_ai',       name: 'Voice AI Lead Callback', price: '$149/mo', blurb: 'An AI voice agent calls qualified leads back for you, day or night, and can book an estimate on your calendar during the call. Call summaries and transcripts show on each lead. 150 minutes included.' },
  { key: 'review_booster', name: 'Review Booster',         price: '$29/mo',  blurb: 'Automatic review requests after every job you win.' },
  { key: 'chat_widget',    name: 'AI Chat Widget',         price: '$49/mo',  blurb: 'Catches people who saw your reply and went to your website instead of messaging.' },
  { key: 'booking',        name: 'Booking & Reminders',    price: '$29/mo',  blurb: 'Book leads onto your calendar from the phone app, plus a booking link, confirmations, reminders and a new link after a no-show. Texts need SMS Follow-up.' },
  { key: 'reactivation',   name: 'Lead Reactivation',      price: '$297 per campaign', blurb: 'Re-engages leads that went cold. 500–2,000 contacts per campaign; email/SMS sending billed separately.' },
  { key: 'keep_running',   name: 'Keep It Running (done for you)', price: '$99 one-time', blurb: 'A 20-minute screen-share where we set up your computer to stay awake and keep monitoring all day, test a restart, and watch your uptime for 30 days.' },
  { key: 'bundle',         name: 'Full Follow-up bundle',  price: '$199/mo', blurb: 'All five: SMS Follow-up, Voice AI Callback, Review Booster, AI Chat Widget and Booking & Reminders (save $106, 35%).' },
];

function upgradeLinkHtml(label) {
  return UPGRADE_URL
    ? `<a class="btn btn-primary" href="${UPGRADE_URL}" target="_blank" rel="noopener">${escHtml(label)}</a>`
    : `<span style="font-size:12px;color:var(--muted);">Reply to your welcome email or call ${SUPPORT_PHONE} to add it.</span>`;
}

function renderUpgrades() {
  const box = document.getElementById('upgrades-content');
  if (!box) return;
  // Usage can arrive with fields missing (older server, first refresh); read
  // everything as numbers so a gap shows 0 instead of throwing on every
  // panel switch.
  const raw = config.usage;
  const n = (v) => Number(v) || 0;
  const u = raw ? { ...raw, aiCallsMtd: n(raw.aiCallsMtd), aiLimit: n(raw.aiLimit), groupsUsed: n(raw.groupsUsed),
    maxGroups: n(raw.maxGroups), leadsMtd: n(raw.leadsMtd), qualifiedMtd: n(raw.qualifiedMtd), planLabel: raw.planLabel || '' } : null;
  const addons = config.addons || {};
  const isPro = !!u && /pro|agency/i.test(u.planLabel || '');

  let html = '';
  if (u) {
    const pct = u.aiLimit ? Math.min(100, Math.round((u.aiCallsMtd / u.aiLimit) * 100)) : 0;
    const barColor = pct >= 100 ? 'var(--red)' : pct >= 80 ? 'var(--orange)' : 'var(--blue)';
    const warn = pct >= 100
      ? `You’ve reached your limit — lead checks are paused until ${u.resetsAt ? new Date(u.resetsAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : u.planLabel === 'Trial' ? 'you start your plan' : 'your billing date'}.`
      : pct >= 80 ? 'You’re close to your monthly limit.' : '';
    html += `
      <div class="card" style="margin-bottom:20px;">
        <div class="card-title">Your plan: ${escHtml(u.planLabel)}</div>
        <div class="card-sub" style="margin-bottom:12px;">${u.resetsAt ? `Usage this billing month (resets ${new Date(u.resetsAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}, your billing date)` : u.planLabel === 'Trial' ? 'Usage for your trial (no reset)' : 'Usage this billing month'}</div>
        <div style="font-size:13px;color:var(--light);margin-bottom:6px;">AI lead checks: <strong>${u.aiCallsMtd.toLocaleString()}</strong> of ${u.aiLimit.toLocaleString()} (${pct}%)</div>
        <div style="height:8px;background:var(--bg3);border-radius:4px;overflow:hidden;margin-bottom:14px;">
          <div style="height:100%;width:${pct}%;background:${barColor};"></div>
        </div>
        <div style="font-size:13px;color:var(--light);">Groups: <strong>${u.groupsUsed}</strong> of ${u.maxGroups} · Leads found: <strong>${u.leadsMtd}</strong> · Qualified: <strong>${u.qualifiedMtd}</strong></div>
        ${warn ? `<div style="margin-top:10px;font-size:12px;color:${barColor};">${warn}</div>` : ''}
      </div>`;
  } else {
    html += '<div class="card-sub" style="margin-bottom:20px;">Usage appears here once your license has refreshed.</div>';
  }

  // Offers matched to this account
  const offers = [];
  if (u && !isPro && u.aiLimit && u.aiCallsMtd >= 0.8 * u.aiLimit)
    offers.push(['pro', `You've used ${Math.round(u.aiCallsMtd / u.aiLimit * 100)}% of this month's AI lead checks. Pro triples the limit and adds 2 more groups.`]);
  if (u && !isPro && u.groupsUsed >= u.maxGroups)
    offers.push(['pro', `All ${u.maxGroups} of your groups are in use. Pro lets you watch 5.`]);
  if (u && u.noReplyMtd >= 3 && !addons.chat_widget)
    offers.push(['chat_widget', `${u.noReplyMtd} people saw your reply this month but never messaged. Many look you up online instead — the AI Chat Widget catches them on your website.`]);
  if (u && u.qualifiedMtd >= 1 && !addons.voice_ai)
    offers.push(['voice_ai', `${u.qualifiedMtd} qualified lead${u.qualifiedMtd === 1 ? '' : 's'} this month. Leads go cold fast. Voice AI calls them back for you, even after hours, and can book the estimate on the call.`]);
  if (u && u.qualifiedMtd >= 1 && !addons.sms)
    offers.push(['sms', 'Send every qualified lead an instant text from your business number, so they know you’re on it.']);
  const seen = new Set();
  const matched = offers.filter(([k]) => !seen.has(k) && seen.add(k));

  if (matched.length) {
    html += '<div style="font-size:15px;font-weight:600;color:var(--white);margin-bottom:12px;">Recommended for you</div>';
    html += matched.map(([k, why]) => {
      const a = ADDON_CATALOG.find((x) => x.key === k);
      return `<div class="card" style="margin-bottom:12px;border-color:rgba(56,139,253,0.35);">
        <div class="card-title">${escHtml(a.name)} <span style="color:var(--muted);font-weight:400;">· ${escHtml(a.price)}</span></div>
        <div class="card-sub" style="margin:6px 0 12px;">${escHtml(why)}</div>
        ${upgradeLinkHtml('Add ' + a.name)}
      </div>`;
    }).join('');
  }

  html += '<div style="font-size:15px;font-weight:600;color:var(--white);margin:24px 0 12px;">All upgrades</div>';
  html += '<div class="up-grid">' + ADDON_CATALOG.map((a) => {
    const active = a.key === 'pro' ? isPro : a.key === 'bundle' ? ['sms', 'voice_ai', 'review_booster', 'chat_widget', 'booking'].every((k) => addons[k]) : !!addons[a.key];
    return `<div class="up-card">
      <div class="up-name">${escHtml(a.name)}</div>
      <div class="up-price">${escHtml(a.price)}</div>
      <div class="up-blurb">${escHtml(a.blurb)}</div>
      ${active ? '<div class="up-active">✓ Active on your account</div>' : ''}
    </div>`;
  }).join('') + '</div>';
  html += `<div style="margin-top:14px;">${upgradeLinkHtml('See upgrade options')}</div>`;

  box.innerHTML = html;
}
