// AnyoneNear — Setup Wizard Modal
// Runs as an IIFE inside the dashboard page.
// Exposes window.openWizard() and window.closeWizard() globally.

(function () {
  'use strict';

  // Same backend this whole extension talks to (background.js has its own
  // copy of these two constants — there's no shared module between the
  // service worker and dashboard-page scripts to import from). Previously
  // the URL+key were hardcoded a second time inline at the one fetch() call
  // site below; centralizing here so a third call site (persistVertical)
  // doesn't paste them a third time.
  const BACKEND_URL       = 'https://citzcbytydvrrqxbzkli.supabase.co/functions/v1';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpdHpjYnl0eWR2cnJxeGJ6a2xpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAwMzU5OTMsImV4cCI6MjEwNTYxMTk5M30.6KoRIkdQIfVRO8BccKag9XSNS0EGSC51y8g9_6Y574o';

  // ── Industry keyword packs ────────────────────────────────────────────────
  // Same design as supabase/functions/activate's KEYWORD_PACKS (kept in sync
  // by hand, not shared code, since these are two separate deployment
  // targets): a topic-terms x intent-terms cross product instead of a short
  // hand-picked phrase list, so the wizard's pre-filled keywords aren't a
  // hard recall ceiling before the customer even starts. A few of the old
  // specific high-signal phrases are kept as standalone extras.
  const WIZ_INTENT_TERMS = [
    'need', 'recommend', 'recommendation', 'looking for',
    'anyone know', 'who do you use', 'help', 'broken',
    'not working', 'asap', 'emergency', 'today',
  ];

  function buildIndustryKeywords(topics, extraStandalone = [], intents = WIZ_INTENT_TERMS) {
    const andPairs = topics.flatMap((topic) =>
      intents.map((intent) => `${topic}+${intent}`)
    );
    return [...extraStandalone, ...andPairs];
  }

  // Line icons from Lucide (lucide.dev, ISC license), inlined so they look
  // the same on every computer (some emojis are missing on Windows).
  const ICON_PATHS = {
    hvac: '<path d="M18 17.5a2.5 2.5 0 1 1-4 2.03V12"/> <path d="M6 12H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/> <path d="M6 8h12"/> <path d="M6.6 15.572A2 2 0 1 0 10 17v-5"/>',
    plumbing: '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z"/>',
    roofing: '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/> <path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    electrical: '<path d="M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z"/>',
    landscaping: '<path d="M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z"/> <path d="M7 16v6"/> <path d="M13 19v3"/> <path d="M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5"/>',
    painting: '<rect width="16" height="6" x="2" y="2" rx="2"/> <path d="M10 16v-2a2 2 0 0 1 2-2h8a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/> <rect width="4" height="6" x="8" y="16" rx="1"/>',
    contractor: '<path d="m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9"/> <path d="m18 15 4-4"/> <path d="m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5"/>',
    windows: '<path d="M10 21H2"/> <path d="M10 3H7a2 2 0 00-2 2v16"/> <path d="M14 12h.01"/> <path d="M19 21V5a2 2 0 00-1.675-1.974l-6.163-1.013A1 1 0 0010 3v18a1 1 0 001.124.992z"/> <path d="M22 21h-3"/>',
    cleaning: '<path d="M3 3h.01"/> <path d="M7 5h.01"/> <path d="M11 7h.01"/> <path d="M3 7h.01"/> <path d="M7 9h.01"/> <path d="M3 11h.01"/> <rect width="4" height="4" x="15" y="5"/> <path d="m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2"/> <path d="m13 14 8-2"/> <path d="m13 19 8-2"/>',
    pest: '<path d="M12 20v-9"/> <path d="M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z"/> <path d="M14.12 3.88 16 2"/> <path d="M21 21a4 4 0 0 0-3.81-4"/> <path d="M21 5a4 4 0 0 1-3.55 3.97"/> <path d="M22 13h-4"/> <path d="M3 21a4 4 0 0 1 3.81-4"/> <path d="M3 5a4 4 0 0 0 3.55 3.97"/> <path d="M6 13H2"/> <path d="m8 2 1.88 1.88"/> <path d="M9 7.13V6a3 3 0 1 1 6 0v1.13"/>',
    flooring: '<path d="M12 3v18"/> <path d="M3 12h18"/> <rect x="3" y="3" width="18" height="18" rx="2"/>',
    other: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/> <path d="m15 5 4 4"/>',
    building: '<path d="M10 12h4"/> <path d="M10 8h4"/> <path d="M14 21v-3a2 2 0 0 0-4 0v3"/> <path d="M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2"/> <path d="M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/> <path d="M16 3.128a4 4 0 0 1 0 7.744"/> <path d="M22 21v-2a4 4 0 0 0-3-3.87"/> <circle cx="9" cy="7" r="4"/>',
    key: '<path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/> <circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/> <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    marketing: '<path d="M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/> <path d="M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14"/> <path d="M8 6v8"/>',
    sparkles: '<path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/> <path d="M20 2v4"/> <path d="M22 4h-4"/> <circle cx="4" cy="20" r="2"/>',
    search: '<path d="m21 21-4.34-4.34"/> <circle cx="11" cy="11" r="8"/>',
    truck: '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/> <path d="M15 18H9"/> <path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/> <circle cx="17" cy="18" r="2"/> <circle cx="7" cy="18" r="2"/>',
    car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/> <circle cx="7" cy="17" r="2"/> <path d="M9 17h6"/> <circle cx="17" cy="17" r="2"/>',
    smile: '<circle cx="12" cy="12" r="10"/> <path d="M8 14s1.5 2 4 2 4-2 4-2"/> <line x1="9" x2="9.01" y1="9" y2="9"/> <line x1="15" x2="15.01" y1="9" y2="9"/>',
    scissors: '<circle cx="6" cy="6" r="3"/> <path d="M8.12 8.12 12 12"/> <path d="M20 4 8.12 15.88"/> <circle cx="6" cy="18" r="3"/> <path d="M14.8 14.8 20 20"/>',
    heartpulse: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/> <path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',
    camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/> <circle cx="12" cy="13" r="3"/>',
    shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />',
    hammer: '<path d="m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9" /> <path d="m18 15 4-4" /> <path d="m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5" />',
    plane: '<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z" />',
    paw: '<circle cx="11" cy="4" r="2" /> <circle cx="18" cy="8" r="2" /> <circle cx="20" cy="16" r="2" /> <path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z" />',
    calculator: '<rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" />',
    utensils: '<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/> <path d="M7 2v20"/> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/>',
  };

  // Intent words for trades where nothing is "broken": people ask for a
  // recommendation or the best one around, not for help today.
  const WIZ_ASK_TERMS = [
    'need', 'recommend', 'recommendation', 'looking for', 'anyone know',
    'who do you use', 'suggestions', 'best', 'good', 'hire',
  ];
  const MARKETING_TERMS = ['need', 'recommend', 'recommendation', 'looking for', 'anyone know', 'who do you use', 'help', 'hire', 'suggestions', 'freelancer'];
  function icon(name, size = 20) {
    return `<svg class="an-icon" xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[name] || ICON_PATHS.users}</svg>`;
  }

  const INDUSTRY_PACKS = {
    hvac: {
      label: 'HVAC technician',
      icon:  'hvac',
      keywords: buildIndustryKeywords(
        ['ac', 'hvac', 'air conditioner', 'air conditioning', 'furnace',
         'heat pump', 'heater', 'thermostat', 'cooling', 'heating'],
        ['AC stopped blowing cold', "furnace won't turn on"]
      ),
    },
    plumbing: {
      label: 'Plumber',
      icon:  'plumbing',
      keywords: buildIndustryKeywords(
        ['plumber', 'plumbing', 'pipe', 'water heater', 'drain', 'leak',
         'faucet', 'toilet', 'sewer', 'garbage disposal', 'water pressure'],
        ['pipe burst', 'water leak']
      ),
    },
    roofing: {
      label: 'Roofer',
      icon:  'roofing',
      keywords: buildIndustryKeywords(
        ['roof', 'roofer', 'roofing', 'shingles', 'gutters', 'soffit', 'fascia'],
        ['roof leak', 'missing shingles', 'hail damage']
      ),
    },
    electrical: {
      label: 'Electrician',
      icon:  'electrical',
      keywords: buildIndustryKeywords(
        ['electrician', 'electrical', 'outlet', 'breaker', 'wiring', 'panel',
         'generator', 'ev charger'],
        ['power outage', 'lights flickering']
      ),
    },
    landscaping: {
      label: 'Landscaper / Lawn care',
      icon:  'landscaping',
      keywords: buildIndustryKeywords(
        ['landscaper', 'landscaping', 'lawn', 'tree removal', 'sprinkler',
         'mulch', 'yard', 'sod', 'tree trimming', 'lawn fertilization'],
        ['yard cleanup', 'lawn mowing']
      ),
    },
    painting: {
      label: 'Painter',
      icon:  'painting',
      keywords: buildIndustryKeywords(
        ['painter', 'painting', 'paint job', 'cabinet painting',
         'deck staining', 'fence painting'],
        ['interior painting', 'exterior painting']
      ),
    },
    contractor: {
      label: 'General contractor',
      icon:  'contractor',
      keywords: buildIndustryKeywords(
        ['contractor', 'renovation', 'remodel', 'remodeling',
         'home repair', 'addition', 'home improvement', 'bathroom remodel',
         'kitchen remodel', 'deck build'],
        ['anyone recommend a contractor']
      ),
    },
    windows: {
      label: 'Window & door installer',
      icon:  'windows',
      keywords: buildIndustryKeywords(
        ['window', 'window replacement', 'door installation', 'sliding door',
         'front door', 'patio door'],
        ['window broken', 'window drafty']
      ),
    },
    cleaning: {
      label: 'House cleaner',
      icon:  'cleaning',
      keywords: buildIndustryKeywords(
        ['house cleaning', 'cleaning service', 'maid service', 'deep clean',
         'move out cleaning', 'carpet cleaning', 'window cleaning',
         'housekeeper', 'house cleaner', 'cleaning lady', 'cleaners'],
        ['housekeeper needed', 'cleaning lady needed']
      ),
    },
    pest: {
      label: 'Pest control',
      icon:  'pest',
      keywords: buildIndustryKeywords(
        ['pest control', 'exterminator', 'ants', 'roaches', 'termite',
         'bed bugs', 'rodent', 'mosquito'],
        ['ants infestation', 'termite inspection']
      ),
    },
    flooring: {
      label: 'Flooring installer',
      icon:  'flooring',
      keywords: buildIndustryKeywords(
        ['flooring', 'hardwood', 'tile installation', 'carpet replacement',
         'laminate', 'floor repair'],
        ['hardwood refinish']
      ),
    },
    real_estate: {
      label: 'Realtor / Mortgage broker',
      icon:  'key',
      keywords: buildIndustryKeywords(
        ['realtor', 'real estate agent', 'buyer agent', 'listing agent', 'selling our house',
         'sell my house', 'buying a house', 'first time home buyer', 'mortgage', 'mortgage broker',
         'loan officer', 'refinance', 'pre-approved', 'home loan'],
        ['recommend a realtor', 'looking for a realtor', 'need a mortgage broker'],
        WIZ_ASK_TERMS
      ),
    },
    moving: {
      label: 'Mover',
      icon:  'truck',
      keywords: buildIndustryKeywords(
        ['movers', 'moving company', 'moving help', 'help moving', 'moving truck', 'packers',
         'piano movers', 'long distance move'],
        ['need movers', 'recommend movers'],
        [...WIZ_ASK_TERMS, 'asap', 'this weekend']
      ),
    },
    auto_repair: {
      label: 'Auto mechanic',
      icon:  'car',
      keywords: buildIndustryKeywords(
        ['mechanic', 'auto repair', 'car repair', 'auto shop', 'brakes', 'check engine light',
         'transmission', 'oil change', 'car trouble', 'tires', 'alignment', "car won't start"],
        ['honest mechanic', 'good mechanic']
      ),
    },
    dental: {
      label: 'Dentist / Orthodontist',
      icon:  'smile',
      keywords: buildIndustryKeywords(
        ['dentist', 'dental', 'orthodontist', 'braces', 'invisalign', 'teeth cleaning', 'toothache',
         'root canal', 'dental implants', 'pediatric dentist', 'teeth whitening', 'crown'],
        ['tooth pain', 'chipped tooth'],
        [...WIZ_ASK_TERMS, 'emergency', 'asap', 'today']
      ),
    },
    salon: {
      label: 'Hair stylist / Barber / Lash & nail tech',
      icon:  'scissors',
      keywords: buildIndustryKeywords(
        ['hair salon', 'hairstylist', 'hair stylist', 'barber', 'haircut', 'balayage', 'highlights',
         'hair color', 'lash tech', 'lash extensions', 'nail tech', 'nail salon', 'gel nails', 'brows',
         'bridal hair'],
        ['recommend a hair stylist', 'looking for a barber'],
        WIZ_ASK_TERMS
      ),
    },
    chiro_massage: {
      label: 'Chiropractor / Massage therapist',
      icon:  'heartpulse',
      keywords: buildIndustryKeywords(
        ['chiropractor', 'chiropractic', 'adjustment', 'massage', 'massage therapist', 'deep tissue',
         'back pain', 'neck pain', 'sciatica'],
        ['recommend a chiropractor', 'good massage'],
        WIZ_ASK_TERMS
      ),
    },
    photography: {
      label: 'Photographer',
      icon:  'camera',
      keywords: buildIndustryKeywords(
        ['photographer', 'photography', 'family photos', 'senior pictures', 'wedding photographer',
         'newborn photos', 'headshots', 'engagement photos', 'photo shoot'],
        ['recommend a photographer', 'looking for a photographer'],
        WIZ_ASK_TERMS
      ),
    },
    restaurant: {
      label: 'Restaurant / Caterer',
      icon:  'utensils',
      keywords: buildIndustryKeywords(
        ['restaurant', 'catering', 'caterer', 'food truck', 'date night', 'brunch', 'lunch spot',
         'dinner spot', 'birthday dinner', 'private dining', 'party food'],
        ['where should we eat', 'best place to eat'],
        [...WIZ_ASK_TERMS, 'tonight']
      ),
    },
    insurance_agent: {
      label: 'Insurance agent',
      icon:  'shield',
      keywords: buildIndustryKeywords(
        ['insurance agent', 'insurance', 'home insurance', 'homeowners insurance', 'auto insurance',
         'car insurance', 'life insurance', 'renters insurance', 'insurance quote', 'umbrella policy',
         'medicare plan', 'business insurance'],
        ['recommend an insurance agent', 'insurance went up'],
        WIZ_ASK_TERMS
      ),
    },
    handyman: {
      label: 'Handyman',
      icon:  'hammer',
      keywords: buildIndustryKeywords(
        ['handyman', 'handy man', 'odd jobs', 'honey do list', 'small repairs', 'drywall repair',
         'mount a tv', 'hang shelves', 'furniture assembly', 'fix a door', 'caulking'],
        ['need a handyman', 'recommend a handyman'],
        WIZ_ASK_TERMS
      ),
    },
    travel_agent: {
      label: 'Travel agent',
      icon:  'plane',
      // Not a local trade: people anywhere ask for a travel agent.
      nonLocal: true,
      keywords: buildIndustryKeywords(
        ['travel agent', 'travel advisor', 'vacation planning', 'trip planning', 'cruise',
         'disney trip', 'all inclusive', 'honeymoon', 'destination wedding', 'europe trip'],
        ['recommend a travel agent', 'anyone use a travel agent'],
        WIZ_ASK_TERMS
      ),
    },
    pet_care: {
      label: 'Pet groomer / Sitter',
      icon:  'paw',
      keywords: buildIndustryKeywords(
        ['dog groomer', 'pet groomer', 'grooming', 'dog walker', 'pet sitter', 'dog sitter',
         'cat sitter', 'dog trainer', 'dog boarding', 'doggy daycare'],
        ['recommend a groomer', 'need a dog sitter'],
        [...WIZ_ASK_TERMS, 'this weekend']
      ),
    },
    accounting: {
      label: 'Accountant / Tax preparer',
      icon:  'calculator',
      keywords: buildIndustryKeywords(
        ['accountant', 'cpa', 'tax preparer', 'tax prep', 'taxes done', 'bookkeeper', 'bookkeeping',
         'tax return', 'payroll', 'small business taxes', 'irs letter'],
        ['recommend an accountant', 'need a cpa'],
        WIZ_ASK_TERMS
      ),
    },
    marketing: {
      label: 'Digital marketer / Web designer',
      icon:  'marketing',
      // Only shown to accounts the server lists (activate's extraTrades) or
      // that already use it; it's the owner's own niche, not a customer trade.
      restricted: true,
      // Not a local trade: people ask for help, a recommendation or someone to
      // hire, not an emergency, so it uses its own intent words.
      nonLocal: true,
      keywords: buildIndustryKeywords(
        ['website', 'web design', 'web designer', 'web developer', 'seo', 'marketing',
         'marketing agency', 'social media', 'social media manager', 'google ads', 'facebook ads',
         'logo', 'branding', 'google business profile', 'google reviews', 'email marketing'],
        ['need a website', 'website help', 'need more customers', 'how do i get more customers', 'need more leads'],
        MARKETING_TERMS
      ),
    },
    other: {
      label: 'Other',
      icon:  'other',
      keywords: [],
    },
  };

  // Keywords that came from an industry pack (here or the server's copy in
  // activate/index.ts) rather than being typed by the customer. Re-running
  // the wizard swaps these out for the newly picked industry's pack while
  // keeping everything the customer added by hand.
  const PACK_TOPICS = new Set(Object.values(INDUSTRY_PACKS).flatMap((p) =>
    p.keywords.filter((k) => k.includes('+')).map((k) => k.split('+')[0].toLowerCase())));
  const PACK_STANDALONE = new Set([
    ...Object.values(INDUSTRY_PACKS).flatMap((p) => p.keywords.filter((k) => !k.includes('+'))),
    // server-only extras (activate's KEYWORD_PACKS)
    'AC stopped working', "furnace won't turn on", 'anyone recommend', 'can anyone suggest', 'who do you use for',
  ].map((k) => k.toLowerCase()));
  const PACK_ALL = new Set(Object.values(INDUSTRY_PACKS).flatMap((p) => p.keywords.map((k) => k.toLowerCase())));
  const PACK_INTENTS = new Set([...WIZ_INTENT_TERMS, ...WIZ_ASK_TERMS, ...MARKETING_TERMS, 'asap', 'this weekend', 'emergency', 'today', 'tonight']);
  function isPackKeyword(k) {
    const kw = String(k).toLowerCase().trim();
    if (PACK_STANDALONE.has(kw) || PACK_ALL.has(kw)) return true;
    const parts = kw.split('+');
    return parts.length === 2 && PACK_TOPICS.has(parts[0]) && PACK_INTENTS.has(parts[1]);
  }

  // The server keeps a smaller set of verticals (playbooks + keyword packs);
  // the wizard's extra home-service industries fall back to "general" there.
  const SERVER_VERTICAL = { contractor: 'general', windows: 'general', cleaning: 'general',
    pest: 'general', flooring: 'general', other: 'general' };

  // Restricted trades this account may pick: the server's list (activate's
  // extraTrades) plus whatever it already uses, so nobody loses their trade.
  let allowedRestricted = new Set();
  async function loadAllowedTrades() {
    const [s, l] = await Promise.all([chrome.storage.sync.get('vertical'), chrome.storage.local.get(['extraTrades', 'serverVertical'])]);
    allowedRestricted = new Set([...(Array.isArray(l.extraTrades) ? l.extraTrades : []), s.vertical, l.serverVertical].filter(Boolean));
  }
  const tradeVisible = (key) => !INDUSTRY_PACKS[key]?.restricted || allowedRestricted.has(key);

  // ── State ─────────────────────────────────────────────────────────────────
  const TOTAL_STEPS   = 5;
  let currentStep     = 1;
  let selectedIndustry = null;
  let wizGroups       = [];
  let wizKeywords     = [];
  let existingGroups  = [];   // groups already being monitored before this run

  const STEP_CONFIG = [
    { label: 'Industry',  progress: 10  },
    { label: 'Groups',    progress: 30  },
    { label: 'Keywords',  progress: 55  },
    { label: 'GHL',       progress: 78  },
    { label: 'Done',      progress: 100 },
  ];

  const NEXT_LABELS = [
    'Continue →',
    'Continue →',
    'Continue →',
    'Continue →',
    '▶ Start Monitoring',
  ];

  // ── Open / Close ──────────────────────────────────────────────────────────
  function openWizard() {
    currentStep      = 1;
    selectedIndustry = null;
    wizGroups        = [];
    wizKeywords      = [];
    existingGroups   = [];
    chrome.storage.local.get(['monitorGroups', 'cloud']).then(({ monitorGroups, cloud }) => {
      existingGroups = monitorGroups || [];
      renderWizGroups();
      // The town the group finder searches: the service area, if it's set.
      const town = document.getElementById('wmod-finder-town');
      if (town && !town.value && cloud?.city) town.value = [cloud.city, cloud.state].filter(Boolean).join(', ');
    });

    const overlay = document.getElementById('wizard-overlay');
    if (!overlay) return;
    overlay.style.display = 'flex';

    buildPips();
    showStep(1);
    renderPips();
    updateNav();
    renderIndustryPicker();
  }

  function closeWizard() {
    const overlay = document.getElementById('wizard-overlay');
    if (overlay) overlay.style.display = 'none';
  }

  // ── Pip indicators ────────────────────────────────────────────────────────
  function buildPips() {
    const row = document.getElementById('wiz-pip-row');
    if (!row) return;
    row.innerHTML = '';
    STEP_CONFIG.forEach((s, i) => {
      const pip = document.createElement('div');
      pip.className   = 'wiz-pip pending';
      pip.id          = `wiz-pip-${i + 1}`;
      pip.textContent = i + 1;
      pip.title       = s.label;
      row.appendChild(pip);
      if (i < STEP_CONFIG.length - 1) {
        const conn = document.createElement('div');
        conn.className = 'wiz-connector';
        conn.id        = `wiz-conn-${i + 1}`;
        row.appendChild(conn);
      }
    });
  }

  function renderPips() {
    STEP_CONFIG.forEach((_, i) => {
      const pip  = document.getElementById(`wiz-pip-${i + 1}`);
      const conn = document.getElementById(`wiz-conn-${i + 1}`);
      if (!pip) return;
      if (i + 1 < currentStep) {
        pip.className   = 'wiz-pip done';
        pip.textContent = '✓';
        if (conn) conn.classList.add('done');
      } else if (i + 1 === currentStep) {
        pip.className   = 'wiz-pip active';
        pip.textContent = i + 1;
        if (conn) conn.classList.remove('done');
      } else {
        pip.className   = 'wiz-pip pending';
        pip.textContent = i + 1;
        if (conn) conn.classList.remove('done');
      }
    });
    const prog = document.getElementById('wiz-progress');
    if (prog) prog.style.width = STEP_CONFIG[currentStep - 1].progress + '%';
  }

  function showStep(n) {
    document.querySelectorAll('.wiz-step-content').forEach(el => el.classList.remove('active'));
    const el = document.getElementById(`wmod-step-${n}`);
    if (el) el.classList.add('active');
  }

  function updateNav() {
    const nextBtn = document.getElementById('wiz-next-btn');
    const backBtn = document.getElementById('wiz-back-btn');
    if (!nextBtn || !backBtn) return;

    nextBtn.textContent = NEXT_LABELS[currentStep - 1];
    nextBtn.className   = currentStep === TOTAL_STEPS
      ? 'wiz-btn-next success'
      : 'wiz-btn-next';
    backBtn.style.display = currentStep > 1 ? 'block' : 'none';

    // Disable next on step 1 until industry selected
    nextBtn.disabled = (currentStep === 1 && !selectedIndustry);
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  async function goNext() {
    if (currentStep === 1 && !selectedIndustry) {
      return;
    }

    // If "Other" selected, generate keywords from description before advancing
    if (currentStep === 1 && selectedIndustry === 'other') {
      const description = document.getElementById('wmod-custom-industry')?.value.trim();
      if (!description) {
        showError('wmod-industry-error', 'Please describe your service so we can generate keywords for you');
        return;
      }
      clearError('wmod-industry-error');
      generateCustomKeywords(description);
    }

    // Groups already being monitored count — re-running the wizard to switch
    // industry shouldn't force adding another group.
    if (currentStep === 2 && wizGroups.length === 0 && existingGroups.length === 0) {
      showError('wmod-group-error', 'Add at least one Facebook group to continue');
      return;
    }

    if (currentStep === TOTAL_STEPS) {
      await finishWizard();
      return;
    }

    currentStep++;
    showStep(currentStep);
    renderPips();
    updateNav();

    if (currentStep === 3) renderKwStep();
    if (currentStep === 5) renderSummary();
  }

  function goBack() {
    if (currentStep <= 1) return;
    currentStep--;
    showStep(currentStep);
    renderPips();
    updateNav();
  }

  // ── Custom keywords for "Other" ───────────────────────────────────────────
  // Templated from the customer's own description of their service. (This
  // used to call a `generate-keywords` edge function that was never built —
  // it 404'd every time and fell through to this same template.) The keyword
  // match is only a wide net; Claude does the real qualification downstream.
  function generateCustomKeywords(description) {
    description = description.toLowerCase();
    wizKeywords = [
      `need ${description}+help`,
      `${description} recommendation`,
      `looking for ${description}`,
      `anyone recommend ${description}`,
      `need ${description}+today`,
      `${description}+hire`,
      'anyone know a good',
      'can anyone recommend',
      'looking for someone',
      'need help+today',
    ];
  }

  // ── STEP 1: Industry Picker ───────────────────────────────────────────────
  async function renderIndustryPicker() {
    const container = document.getElementById('wmod-industry-grid');
    if (!container) return;
    await loadAllowedTrades().catch(() => {});

    container.innerHTML = Object.entries(INDUSTRY_PACKS).filter(([key]) => tradeVisible(key)).map(([key, pack]) => `
      <div class="industry-card ${selectedIndustry === key ? 'selected' : ''}"
           data-industry="${key}">
        <span class="industry-icon">${icon(pack.icon, 24)}</span>
        <span class="industry-label">${pack.label}</span>
      </div>
    `).join('');

    container.querySelectorAll('.industry-card').forEach(card => {
      card.addEventListener('click', () => {
        pickIndustry(card.dataset.industry);
      });
    });

    // Start with the trade the owner already gave us (onboarding form, order,
    // or a previous run of this wizard), when it's one we have a pack for.
    if (!selectedIndustry) {
      Promise.all([chrome.storage.sync.get('vertical'), chrome.storage.local.get('serverVertical')]).then(([s, l]) => {
        const known = [s.vertical, l.serverVertical].find((v) => v && v !== 'general' && INDUSTRY_PACKS[v] && tradeVisible(v));
        if (known && !selectedIndustry) pickIndustry(known);
      });
    }
  }

  function pickIndustry(key) {
    const container = document.getElementById('wmod-industry-grid');
    if (!container || !INDUSTRY_PACKS[key] || !tradeVisible(key)) return;
    selectedIndustry = key;
    container.querySelectorAll('.industry-card').forEach(c => c.classList.remove('selected'));
    container.querySelector(`[data-industry="${key}"]`)?.classList.add('selected');

    // Pre-load keywords from this pack
    wizKeywords = [...INDUSTRY_PACKS[key].keywords];
    // A business that isn't tied to one town finds groups by topic.
    const mode = document.getElementById('wmod-finder-mode');
    if (mode) { mode.value = INDUSTRY_PACKS[key].nonLocal ? 'topic' : 'town'; mode.dispatchEvent(new Event('change')); }

    // Show custom input for "other"
    const customRow = document.getElementById('wmod-industry-custom');
    if (customRow) customRow.style.display = key === 'other' ? 'block' : 'none';

    updateNav();
  }

  // ── STEP 2: Groups ────────────────────────────────────────────────────────
  function addGroup() {
    const urlInput  = document.getElementById('wmod-group-url');
    const nameInput = document.getElementById('wmod-group-name');
    const url  = urlInput?.value.trim();
    const name = nameInput?.value.trim() || extractName(url);

    clearError('wmod-group-error');

    if (!/facebook\.com\/groups\/[^/?#\s]+/i.test(url || '')) {
      showError('wmod-group-error', 'Please enter a valid Facebook group URL');
      return;
    }

    if (existingGroups.find(g => g.url === url)) {
      showError('wmod-group-error', 'You are already monitoring this group');
      return;
    }
    if (!wizGroups.find(g => g.url === url)) {
      wizGroups.push({ url, name, active: false });
      renderWizGroups();
    }

    if (urlInput)  urlInput.value  = 'https://www.facebook.com/groups/';
    if (nameInput) nameInput.value = '';
    urlInput?.focus();
  }

  function renderWizGroups() {
    const list = document.getElementById('wmod-group-list');
    if (!list) return;

    const existingHtml = existingGroups.map((g) => `
      <div class="wiz-group-tag" style="opacity:0.7;">
        <div class="wgt-icon">${groupEmoji(g.name)}</div>
        <div class="wgt-info">
          <div class="wgt-name">${esc(g.name)} <span style="font-size:11px;color:var(--dim);">· already monitoring</span></div>
          <div class="wgt-url">${esc(g.url)}</div>
        </div>
      </div>
    `).join('');

    if (wizGroups.length === 0) {
      list.innerHTML = existingHtml ||
        '<div style="font-size:13px;color:var(--dim);padding:8px 0;">No groups added yet</div>';
      return;
    }

    list.innerHTML = existingHtml + wizGroups.map((g, i) => `
      <div class="wiz-group-tag">
        <div class="wgt-icon">${groupEmoji(g.name)}</div>
        <div class="wgt-info">
          <div class="wgt-name">${esc(g.name)}</div>
          <div class="wgt-url">${esc(g.url)}</div>
        </div>
        <button class="wgt-remove" data-wiz-rm-group="${i}" title="Remove">×</button>
      </div>
    `).join('');

    list.querySelectorAll('[data-wiz-rm-group]').forEach(btn => {
      btn.addEventListener('click', () => {
        wizGroups.splice(parseInt(btn.dataset.wizRmGroup), 1);
        renderWizGroups();
      });
    });
  }

  // Group finder: background.js searches Facebook (a few background tabs) and
  // ranks the groups; the owner adds the ones they want. Groups they aren't in
  // yet get a "Join first" link — replies only work in groups they belong to.
  let finderResults = [];
  // "keyword+keyword" in the box (or a business that isn't local) searches by
  // topic instead of by town.
  function finderIsTopic(q) {
    return q.includes('+') || document.getElementById('wmod-finder-mode')?.value === 'topic';
  }
  async function findGroupsNearMe() {
    const town = document.getElementById('wmod-finder-town')?.value.trim();
    const status = document.getElementById('wmod-finder-status');
    const btn = document.getElementById('wmod-finder-btn');
    const topic = town && finderIsTopic(town);
    if (!town) { status.textContent = topic ? 'Enter a topic first, e.g. small business+marketing.' : 'Enter your town first.'; return; }
    btn.disabled = true;
    const overlay = showFinderOverlay(topic ? `"${town.replace(/\+/g, ' + ')}"` : town);
    status.textContent = topic ? `Searching Facebook for ${town.replace(/\+/g, ' + ')} groups…` : `Searching Facebook for groups around ${town}…`;
    const res = await chrome.runtime.sendMessage(topic ? { type: 'FIND_GROUPS', topic: town } : { type: 'FIND_GROUPS', town }).catch((e) => ({ ok: false, error: e.message }));
    overlay.remove();
    btn.disabled = false;
    if (!res?.ok) { status.textContent = res?.error || "Couldn't search right now. Make sure you're logged in to Facebook in this browser."; return; }
    finderResults = res.groups || [];
    status.textContent = finderResults.length
      ? `Found ${finderResults.length} groups, best matches first. Add the 3–5 busiest ${topic ? 'ones where your customers ask for help' : 'local ones'}.`
      : topic ? "Facebook didn't show any groups for that search. Try other words, e.g. small business+owners." : "Facebook didn't show any groups for that search. Try your county or a nearby bigger town.";
    renderFinderResults();
  }

  // While the finder runs: a clear "please wait" over the setup page, with
  // which search it's on. background.js sends FINDER_PROGRESS per search.
  function showFinderOverlay(town) {
    document.getElementById('an-finder-overlay')?.remove();
    const o = document.createElement('div');
    o.id = 'an-finder-overlay';
    o.className = 'finder-overlay';
    o.innerHTML = `<div class="finder-card">
        <div class="finder-spinner" aria-hidden="true"></div>
        <div class="finder-title">Scanning Facebook for ${town.startsWith('"') ? `${esc(town)} groups` : `groups around ${esc(town)}`}. Please wait…</div>
        <div class="finder-step" id="an-finder-step">Starting…</div>
        <p class="finder-note">Facebook search tabs will open and close by themselves. That's normal, so please don't close them. It takes about a minute.</p>
      </div>`;
    document.body.appendChild(o);
    const onMsg = (m) => {
      if (m?.type !== 'FINDER_PROGRESS') return;
      const el = document.getElementById('an-finder-step');
      if (el) el.textContent = `Search ${m.step} of ${m.total}`;
    };
    chrome.runtime.onMessage.addListener(onMsg);
    return { remove() { chrome.runtime.onMessage.removeListener(onMsg); o.remove(); } };
  }

  function renderFinderResults() {
    const list = document.getElementById('wmod-finder-results');
    if (!list) return;
    const added = (url) => wizGroups.some((g) => g.url === url) || existingGroups.some((g) => g.url === url);
    const fmt = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1).replace(/\.0$/, '')}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1).replace(/\.0$/, '')}K` : String(n);
    const rate = (d) => d >= 1 ? `${Math.round(d)} posts a day` : d * 7 >= 1 ? `${Math.round(d * 7)} posts a week` : `${Math.max(1, Math.round(d * 30))} posts a month`;
    list.innerHTML = finderResults.map((g, i) => `
      <div class="wiz-group-tag">
        <div class="wgt-icon">${groupEmoji(g.name)}</div>
        <div class="wgt-info">
          <div class="wgt-name">${esc(g.name)}</div>
          <div class="wgt-meta">${[g.members ? `${fmt(g.members)} members` : '', g.postsPerDay ? rate(g.postsPerDay) : '', g.privacy || '', g.member ? "you're a member" : ''].filter(Boolean).join(' · ')}</div>
        </div>
        ${g.member ? '' : `<a class="wgt-join" href="${esc(g.url)}" target="_blank" rel="noopener">Join first ↗</a>`}
        <button class="wgt-add" data-finder-add="${i}" ${added(g.url) ? 'disabled' : ''}>${added(g.url) ? 'Added' : 'Add'}</button>
      </div>`).join('');
    list.querySelectorAll('[data-finder-add]').forEach((b) => b.addEventListener('click', () => {
      const g = finderResults[Number(b.dataset.finderAdd)];
      if (!g || added(g.url)) return;
      wizGroups.push({ url: g.url, name: g.name, active: false });
      renderWizGroups();
      renderFinderResults();
    }));
  }

  // ── STEP 3: Keywords ──────────────────────────────────────────────────────
  let aiAskedFor = '';
  function renderKwStep() {
    renderKwTags();
    renderKwCloud();
    renderAiServices();
    // A custom trade has no built-in pack: ask AI straight away.
    if (selectedIndustry === 'other' && industryDescription() && aiAskedFor !== industryDescription()) {
      aiAskedFor = industryDescription();
      suggestServices();
    }

    // Show industry name in the header
    const industryNote = document.getElementById('wmod-kw-industry-note');
    if (industryNote && selectedIndustry) {
      const pack = INDUSTRY_PACKS[selectedIndustry];
      industryNote.textContent = `Pre-loaded for: ${pack.label}`;
      industryNote.style.display = 'block';
    }
  }

  function renderKwTags() {
    const wrap = document.getElementById('wmod-kw-tags');
    if (!wrap) return;

    if (wizKeywords.length === 0) {
      wrap.innerHTML = '<span style="font-size:12px;color:var(--dim);">No keywords yet</span>';
      return;
    }

    wrap.innerHTML = wizKeywords.map((kw, i) => `
      <div class="wiz-kw-tag">
        <span>${esc(kw)}</span>
        <button data-wiz-rm-kw="${i}" title="Remove">×</button>
      </div>
    `).join('');

    wrap.querySelectorAll('[data-wiz-rm-kw]').forEach(btn => {
      btn.addEventListener('click', () => {
        wizKeywords.splice(parseInt(btn.dataset.wizRmKw), 1);
        renderKwTags();
      });
    });
  }

  // AI suggestions: the services this kind of business usually sells, from
  // suggest-services. Each picked service becomes a keyword topic, paired with
  // the usual "looking for / recommend" intent words like the built-in packs.
  let aiServices = [];
  function industryDescription() {
    if (selectedIndustry === 'other') return document.getElementById('wmod-custom-industry')?.value.trim() || '';
    return selectedIndustry ? INDUSTRY_PACKS[selectedIndustry]?.label || '' : '';
  }
  async function suggestServices() {
    const btn = document.getElementById('wmod-ai-btn');
    const status = document.getElementById('wmod-ai-status');
    const industry = industryDescription();
    if (!industry) { status.textContent = 'Pick your trade on step 1 first.'; return; }
    btn.disabled = true;
    status.textContent = 'Asking AI which services a business like yours usually offers…';
    try {
      const { licenseKey } = await chrome.storage.sync.get(['licenseKey']);
      const res = await fetch(`${BACKEND_URL}/suggest-services`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${licenseKey || ''}` },
        body: JSON.stringify({ industry }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || `error ${res.status}`);
      const have = new Set(wizKeywords.map((k) => k.split('+')[0].toLowerCase()));
      aiServices = (data.services || []).filter((s) => !have.has(s));
      status.textContent = aiServices.length
        ? 'Tap the services you offer to add them. Each adds a few "looking for / recommend" keywords.'
        : 'No new suggestions. Your list already covers the usual services.';
    } catch (e) {
      status.textContent = `Couldn't get suggestions (${e.message}). You can still add keywords by hand.`;
    }
    btn.disabled = false;
    renderAiServices();
  }
  function renderAiServices() {
    const box = document.getElementById('wmod-ai-services');
    if (!box) return;
    box.innerHTML = aiServices.map((s) => `<div class="wiz-kw-chip" data-ai-service="${esc(s)}">+ ${esc(s)}</div>`).join('');
    box.querySelectorAll('[data-ai-service]').forEach((chip) => chip.addEventListener('click', () => {
      const svc = chip.dataset.aiService;
      for (const k of buildIndustryKeywords([svc])) if (!wizKeywords.includes(k)) wizKeywords.push(k);
      aiServices = aiServices.filter((x) => x !== svc);
      renderKwTags();
      renderAiServices();
    }));
  }

  function renderKwCloud() {
    const cloud = document.getElementById('wmod-kw-cloud');
    if (!cloud) return;

    // Show extra suggestions not already in the pack
    const extras = [
      'anyone recommend', 'looking for help+today', 'need someone ASAP',
      'can anyone suggest', 'who do you use for', 'need help with+repair',
    ].filter(k => !wizKeywords.includes(k));

    if (extras.length === 0) { cloud.style.display = 'none'; return; }
    cloud.style.display = 'flex';

    cloud.innerHTML = extras.map(kw => `
      <div class="wiz-kw-chip" data-wiz-quick="${esc(kw)}">${esc(kw)}</div>
    `).join('');

    cloud.querySelectorAll('[data-wiz-quick]').forEach(chip => {
      chip.addEventListener('click', () => {
        const kw = chip.dataset.wizQuick;
        if (!wizKeywords.includes(kw)) {
          wizKeywords.push(kw);
          renderKwTags();
          chip.classList.add('selected');
        }
      });
    });
  }

  function addKeyword() {
    const input = document.getElementById('wmod-kw-input');
    const val   = input?.value.trim().toLowerCase();
    if (!val) return;
    if (!wizKeywords.includes(val)) {
      wizKeywords.push(val);
      renderKwTags();
    }
    if (input) input.value = '';
    input?.focus();
  }

  // ── STEP 5: Summary ───────────────────────────────────────────────────────
  // Leads reach GHL through the backend — "connected" just means this license
  // is linked to a GHL sub-account (ghlLocationId from /activate).
  async function renderSummary() {
    const el = document.getElementById('wmod-summary');
    if (!el) return;

    const pack   = selectedIndustry ? INDUSTRY_PACKS[selectedIndustry] : null;
    const { ghlLocationId } = await chrome.storage.sync.get('ghlLocationId');
    const ghlOk  = !!ghlLocationId;

    const rows = [
      {
        icon: icon(pack?.icon || 'building', 16),
        label: 'Industry',
        value: pack?.label || 'Not selected',
        ok: !!selectedIndustry,
      },
      {
        icon: icon('users', 16),
        label: 'Groups',
        // Existing groups count too — re-running the wizard doesn't re-add them.
        value: (() => {
          const total = existingGroups.length + wizGroups.length;
          return `${total} group${total !== 1 ? 's' : ''} to monitor` +
            (wizGroups.length && existingGroups.length ? ` (${wizGroups.length} new)` : '');
        })(),
        ok: existingGroups.length + wizGroups.length > 0,
      },
      {
        icon: icon('key', 16),
        label: 'Keywords',
        value: `${wizKeywords.length} keyword${wizKeywords.length !== 1 ? 's' : ''} active`,
        ok: wizKeywords.length > 0,
      },
      {
        icon: icon('link', 16),
        label: 'GHL',
        value: ghlOk ? 'Linked to your sub-account ✓' : 'Not linked yet — contact support',
        ok: ghlOk,
      },
    ];

    el.innerHTML = rows.map(r => `
      <div class="wiz-summary-row">
        <span class="wsr-icon">${r.icon}</span>
        <span class="wsr-label">${r.label}</span>
        <span class="wsr-value">${r.value}</span>
        <span class="${r.ok ? 'wsr-ok' : 'wsr-warn'}">${r.ok ? '✓' : '→'}</span>
      </div>
    `).join('');
  }

  // ── Finish — save everything and refresh dashboard ─────────────────────────
  async function finishWizard() {
    try {
      // 1. Save groups to local storage
      const { monitorGroups: existing = [] } = await chrome.storage.local.get('monitorGroups');
      const merged = [
        ...existing,
        ...wizGroups.filter(g => !existing.find(e => e.url === g.url)),
      ];
      // The server rejects leads from groups past the plan's cap, so extra
      // groups would silently produce nothing — stop here instead.
      const { maxGroups = 3 } = await chrome.storage.sync.get('maxGroups');
      if (merged.length > maxGroups) {
        showError('wmod-group-error', `Your plan covers ${maxGroups} groups and this would make ${merged.length}. Remove some first (you can manage them later in the Groups tab).`);
        currentStep = 2; showStep(2); renderPips(); updateNav();
        return;
      }
      await chrome.storage.local.set({ monitorGroups: merged });

      // 2. Keywords: swap the previous industry pack for this one, but keep
      // anything the customer typed themselves. (Replacing everything wiped
      // hand-added keywords; merging everything kept the old industry's pack.)
      const { keywords: existingKw = [] } = await chrome.storage.sync.get('keywords');
      const custom = existingKw.filter((k) => !isPackKeyword(k));
      await chrome.storage.sync.set({ keywords: [...new Set([...custom, ...wizKeywords])] });

      // 3. Save industry vertical to sync storage, AND tell the server —
      // this used to be local-only, so the next time /activate re-runs (24h
      // re-validation) it would silently push the OLD vertical's keyword
      // pack back down, discarding this choice. Fire-and-forget: this call's
      // response is intentionally ignored so it can't clobber wizKeywords
      // (which may include "Other"-industry customizations the generic
      // per-vertical pack wouldn't have) — it only exists to update the
      // server's customers.vertical column for future activations.
      if (selectedIndustry) {
        await chrome.storage.sync.set({ vertical: selectedIndustry });
        persistVertical(selectedIndustry);
      }

      // 4. Notify background to reload config and push to content scripts
      chrome.runtime.sendMessage({ type: 'CONFIG_UPDATED' });

      // 5. Close modal
      closeWizard();

      // 6. Reload dashboard config THEN re-render so new data is visible
      if (typeof loadConfig === 'function') {
        await loadConfig();
      }

      if (typeof renderAll === 'function')            renderAll();
      if (typeof updateSidebarStatus === 'function')  updateSidebarStatus();
      if (typeof updateLicenseStatusCard === 'function') updateLicenseStatusCard();

      // 7. First time through: show the "Start here" guide; afterwards, the monitor.
      //    Start cycling either way if there are groups.
      const { guideSeen } = await chrome.storage.local.get('guideSeen');
      if (typeof showPanel === 'function') showPanel(guideSeen ? 'monitor' : 'guide');
      if (!guideSeen) await chrome.storage.local.set({ guideSeen: true });
      if (merged.length > 0 && typeof startCycling === 'function') {
        setTimeout(() => startCycling(), 600);
      }

    } catch (err) {
      console.error('[Wizard] finishWizard error:', err);
      showError('wmod-group-error', `Save failed: ${err.message}`);
    }
  }

  // Tells the server which vertical the customer actually picked, so
  // customers.vertical stops drifting from what the wizard shows locally.
  // Deliberately fire-and-forget — the response (including its keywords
  // field) is never applied to local storage; see the call site in
  // finishWizard() for why.
  async function persistVertical(vertical) {
    try {
      const { licenseKey } = await chrome.storage.sync.get(['licenseKey']);
      const { deviceId }   = await chrome.storage.local.get(['deviceId']);
      if (!licenseKey) return;

      await fetch(`${BACKEND_URL}/activate`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'apikey': SUPABASE_ANON_KEY },
        body: JSON.stringify({ licenseKey, deviceId, vertical: SERVER_VERTICAL[vertical] || vertical }),
      });
    } catch (err) {
      console.warn('[Wizard] persistVertical failed (non-fatal):', err.message);
    }
  }

  // ── Utilities ─────────────────────────────────────────────────────────────
  function showError(id, msg) {
    const el = document.getElementById(id);
    if (el) { el.textContent = msg; el.style.display = 'block'; }
  }

  function clearError(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  }

  function extractName(url) {
    try {
      const m = url?.match(/facebook\.com\/groups\/([^/?]+)/);
      if (m) return decodeURIComponent(m[1]).replace(/-/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
    } catch {}
    return 'Facebook Group';
  }

  function groupEmoji() {
    return icon('users', 15);
  }

  function esc(str) {
    return String(str || '')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // ── Wire up buttons ────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('wiz-next-btn')?.addEventListener('click', goNext);
    document.getElementById('wiz-back-btn')?.addEventListener('click', goBack);
    document.getElementById('wiz-skip-btn')?.addEventListener('click', closeWizard);
    document.getElementById('wmod-add-group-btn')?.addEventListener('click', addGroup);
    document.getElementById('wmod-finder-btn')?.addEventListener('click', findGroupsNearMe);
    document.getElementById('wmod-finder-mode')?.addEventListener('change', (e) => {
      const topic = e.target.value === 'topic';
      const input = document.getElementById('wmod-finder-town');
      if (input) input.placeholder = topic ? 'Topic, e.g. small business+marketing' : 'Your town, e.g. Springfield, MO';
      const hint = document.getElementById('wmod-finder-status');
      if (hint && !finderResults.length) hint.textContent = topic
        ? 'Searches Facebook for groups about your topic. Use + to combine words: "small business+marketing" finds groups about both. Takes about a minute; Facebook tabs open and close by themselves.'
        : 'Searches Facebook for your town\'s own groups ("Ask <town>", community, recommendation and neighbor groups), then ranks them by how local and active they are. Takes about a minute; Facebook tabs open and close by themselves while it runs. Tip: add your state (e.g. Springfield, MO) so other towns with the same name drop out.';
    });
    document.getElementById('wmod-finder-town')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') findGroupsNearMe();
    });
    document.getElementById('wmod-add-kw-btn')?.addEventListener('click', addKeyword);
    document.getElementById('wmod-ai-btn')?.addEventListener('click', suggestServices);

    if (typeof prefillGroupInput === 'function') prefillGroupInput(document.getElementById('wmod-group-url'));   // dashboard.js
    document.getElementById('wmod-group-url')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') addGroup();
    });
    document.getElementById('wmod-kw-input')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') addKeyword();
    });
  });

  // ── Expose globally ────────────────────────────────────────────────────────
  window.openWizard  = openWizard;
  window.closeWizard = closeWizard;

})();
