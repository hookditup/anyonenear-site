// Appearance set in the dashboard: "system" follows the computer.
chrome.storage.sync.get("theme").then(({ theme }) => {
  if (theme === "light" || theme === "dark") document.documentElement.dataset.theme = theme;
}).catch(() => {});
// AnyoneNear Popup Script
"use strict";

let keywords = [];
let leads    = [];

document.addEventListener("DOMContentLoaded", async () => {
  await loadAll();
  renderKeywords();
  renderLeads();
  updateStatus();
  setupListeners();
  clearBadge();
});

async function loadAll() {
  const sync  = await chrome.storage.sync.get(["keywords", "enabled", "licenseStatus", "plan"]);
  const local = await chrome.storage.local.get(["leads"]);

  keywords = sync.keywords || [];
  leads    = local.leads   || [];

  const enabled = sync.enabled !== false;
  document.getElementById("main-toggle").checked      = enabled;
  document.getElementById("toggle-text").textContent  = enabled ? "ON" : "OFF";

  // Show plan badge if licensed
  const planEl = document.getElementById("plan-badge");
  if (planEl && sync.licenseStatus === "active" && sync.plan) {
    planEl.textContent = sync.plan.toUpperCase();
    planEl.style.display = "inline";
  }
}

// ─── Status ───────────────────────────────────────────────────────────────────
async function updateStatus() {
  const dot  = document.getElementById("status-dot");
  const text = document.getElementById("status-text");
  const sync = await chrome.storage.sync.get(["licenseStatus", "licenseError", "enabled"]);

  // Not licensed
  if (!sync.licenseStatus || sync.licenseStatus === "none") {
    dot.className     = "status-dot inactive";
    text.textContent  = "Enter license key in Dashboard to activate";
    return;
  }

  if (sync.licenseStatus === "invalid") {
    dot.className     = "status-dot error";
    text.textContent  = sync.licenseError || "Invalid license key";
    return;
  }

  if (!sync.enabled) {
    dot.className     = "status-dot inactive";
    text.textContent  = "Scanning paused";
    return;
  }

  if (keywords.length === 0) {
    dot.className     = "status-dot inactive";
    text.textContent  = "No keywords — open Dashboard to add some";
    return;
  }

  // Ping content script
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.url?.includes("facebook.com/groups")) {
      chrome.tabs.sendMessage(tab.id, { type: "PING" }, (res) => {
        if (chrome.runtime.lastError || !res) {
          dot.className    = "status-dot inactive";
          text.textContent = "Waiting for group page…";
          return;
        }
        dot.className    = "status-dot active";
        text.textContent = `Monitoring · ${keywords.length} keyword${keywords.length !== 1 ? "s" : ""}`;
      });
    } else {
      dot.className    = "status-dot inactive";
      text.textContent = "Open a Facebook group to start scanning";
    }
  } catch {
    dot.className    = "status-dot inactive";
    text.textContent = `Ready · ${keywords.length} keywords`;
  }

  updateStats();
}

function updateStats() {
  const today      = new Date().toDateString();
  const todayLeads = leads.filter(l => new Date(l.timestamp).toDateString() === today);
  document.getElementById("stat-today").textContent = todayLeads.length;
  document.getElementById("stat-total").textContent = leads.length;
}

// ─── Keywords ─────────────────────────────────────────────────────────────────
function renderKeywords() {
  const wrap = document.getElementById("keywords-wrap");
  wrap.innerHTML = "";

  if (keywords.length === 0) {
    wrap.innerHTML = '<span style="color:var(--text3);font-size:12px;font-family:var(--mono);">no keywords yet</span>';
    return;
  }

  keywords.forEach((kw, i) => {
    const tag = document.createElement("div");
    tag.className = "kw-tag";
    tag.innerHTML = `
      <span>${escapeHtml(kw)}</span>
      <button class="kw-remove" data-index="${i}" title="Remove">×</button>
    `;
    wrap.appendChild(tag);
  });

  wrap.querySelectorAll(".kw-remove").forEach(btn => {
    btn.addEventListener("click", () => {
      keywords.splice(parseInt(btn.dataset.index), 1);
      saveKeywords();
      renderKeywords();
    });
  });
}

function addKeyword() {
  const input = document.getElementById("kw-input");
  const val   = input.value.trim().toLowerCase();
  if (!val) return;
  if (keywords.includes(val)) { showToast("Already added"); return; }
  keywords.push(val);
  input.value = "";
  saveKeywords();
  renderKeywords();
  showToast("Keyword added ✓");
}

async function saveKeywords() {
  await chrome.storage.sync.set({ keywords });
  notifyContentScript();
  updateStatus();
}

// ─── Leads ────────────────────────────────────────────────────────────────────
function renderLeads() {
  const list = document.getElementById("leads-list");

  if (leads.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📡</div>
        <p class="empty-title">Scanning groups…</p>
        <p class="empty-sub">Visit a Facebook group to start monitoring.<br>Qualified leads appear here instantly.</p>
      </div>`;
    return;
  }

  list.innerHTML = leads.slice(0, 50).map(lead => {
    const score       = Math.min(10, Math.max(0, Math.round(Number(lead.intentScore)))) || null;
    const scoreBadge  = score
      ? `<span class="intent-score score-${score >= 8 ? "high" : score >= 5 ? "mid" : "low"}">⚡ ${score}/10</span>`
      : "";
    const summary     = lead.intentSummary
      ? `<div class="intent-summary">${escapeHtml(lead.intentSummary)}</div>`
      : "";
    const kwBadges    = (lead.matchedKeywords || [])
      .map(k => `<span class="kw-badge">${escapeHtml(k)}</span>`).join("");
    const actions     = leadActionsHtml(lead);

    return `
      <div class="lead-item">
        <div class="lead-meta">
          <span class="lead-group">${escapeHtml(lead.groupName || "Unknown group")}</span>
          <div style="display:flex;align-items:center;gap:6px;">
            ${scoreBadge}
            <span class="lead-time">${formatTime(lead.timestamp)}</span>
          </div>
        </div>
        <div class="lead-keywords">${kwBadges}</div>
        ${summary}
        <div class="lead-snippet">${escapeHtml(lead.snippet || lead.postText || "")}</div>
        ${actions}
      </div>`;
  }).join("");

  list.querySelectorAll(".btn-send-comment").forEach(btn => {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      const leadId = btn.dataset.id;
      // Approval only QUEUES the comment — background.js posts it when the
      // safety limits allow and records the real outcome on the lead
      // (commentStatus), which re-renders this list via storage.onChanged.
      chrome.runtime.sendMessage({ type: "APPROVE_COMMENT", leadId }, (res) => {
        if (res?.ok) showToast(`Queued ✓ — posts ${formatEta(res.eta)}`);
        else if (res?.reason === "no_permalink") showToast("No post link found — reply to this one by hand");
        else if (res?.reason === "already_decided") showToast(res.status === "skipped" ? "Already skipped from your phone" : "Already sent from your phone");
        else showToast("Too late — this lead expired, nothing was posted");
      });
    });
  });

  list.querySelectorAll(".btn-skip-lead").forEach(btn => {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: "SKIP_LEAD", leadId: btn.dataset.id });
    });
  });

  list.querySelectorAll(".btn-open-post").forEach(btn => {
    btn.addEventListener("click", e => {
      e.stopPropagation();
      if (btn.dataset.url) chrome.tabs.create({ url: btn.dataset.url });
    });
  });
}

// ─── Event Listeners ──────────────────────────────────────────────────────────
function setupListeners() {
  // Tab switching
  document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(`panel-${tab.dataset.tab}`)?.classList.add("active");
    });
  });

  // Main toggle
  document.getElementById("main-toggle").addEventListener("change", async e => {
    const enabled = e.target.checked;
    document.getElementById("toggle-text").textContent = enabled ? "ON" : "OFF";
    await chrome.storage.sync.set({ enabled });
    notifyContentScript();
    updateStatus();
  });

  // Keywords
  document.getElementById("kw-add").addEventListener("click", addKeyword);
  document.getElementById("kw-input").addEventListener("keydown", e => {
    if (e.key === "Enter") addKeyword();
  });

  // Clear leads
  document.getElementById("clear-btn").addEventListener("click", async () => {
    if (!confirm("Clear all leads?")) return;
    leads = [];
    await chrome.storage.local.set({ leads: [] });
    renderLeads();
    updateStats();
    showToast("Cleared");
  });

  // Dashboard button
  document.getElementById("open-dashboard").addEventListener("click", openDashboard);
  wireReport();

  // Live lead updates.
  // LEAD_FOUND is a raw keyword match broadcast by content.js BEFORE Claude
  // qualification — it has no intentScore/intentSummary/commentDraft yet, and
  // may turn out to not even be a buyer. This used to write message.lead
  // straight into storage.local.leads unconditionally: with the popup open,
  // every keyword match (including ones Claude would later reject) appeared
  // in the list with no score, and because background.js's persistLead()
  // dedupes by id and returns early on an existing entry, the later write of
  // the real, qualified/scored lead was silently dropped. Treat this message
  // as nothing more than "something happened, refresh" and re-read the
  // qualified data background.js actually persisted, instead of trusting the
  // raw payload. The delay gives the Claude round-trip time to land.
  // Re-render whenever background.js persists a qualified lead or updates a
  // lead's comment status (queued → posted / failed).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.leads) {
      leads = changes.leads.newValue || [];
      renderLeads();
      updateStats();
    }
  });
}

// What a lead card shows, driven by the status background.js records.
function leadActionsHtml(lead) {
  const id   = escapeHtml(lead.id);
  const url  = escapeHtml(lead.postUrl || lead.sourceUrl || "");
  const view = url ? `<button class="btn-open-post" data-url="${url}">View post</button>` : "";
  const status = lead.commentStatus || (lead.commented ? "posted" : lead.postUrl ? "pending" : "manual");

  switch (status) {
    case "posted":  return `<div class="lead-commented">✅ Posted ${formatTime(lead.commentedAt)}</div>`;
    case "queued":  return `<div class="lead-commented">⏳ Queued — posts at a safe pace</div>`;
    case "failed":  return `<div class="lead-actions"><span class="lead-commented">⚠️ Not posted — reply by hand</span>${view}</div>`;
    case "skipped": return `<div class="lead-commented">Skipped</div>`;
    case "expired": return `<div class="lead-actions"><span class="lead-commented">Expired</span>${view}</div>`;
    case "manual":  return `<div class="lead-actions"><span class="lead-commented">Sent to GHL — reply by hand</span>${view}</div>`;
    default:
      return `<div class="lead-actions">
           <button class="btn-send-comment" data-id="${id}">Send ✓</button>
           <button class="btn-skip-lead" data-id="${id}">Skip</button>
           ${view}
         </div>`;
  }
}

function formatEta(ts) {
  if (!ts || ts - Date.now() < 90 * 1000) return "shortly";
  return "around " + new Date(ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
async function notifyContentScript() {
  try {
    // background.js relays this to EVERY open Facebook tab — the group
    // being scanned is usually an inactive background tab, which the old
    // active-tab-only message never reached.
    await chrome.runtime.sendMessage({ type: "CONFIG_UPDATED" });
  } catch {}
}

// The toolbar badge counts replies waiting for approval (background.js keeps
// it in sync), so opening the popup doesn't reset it any more.
async function clearBadge() {}

function formatTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const diff = Math.floor((Date.now() - d) / 60000);
  if (diff < 1)    return "just now";
  if (diff < 60)   return `${diff}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return d.toLocaleDateString();
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2000);
}

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// Settings live in the AnyoneNear app (Watch screen) since 1.11; Shift+click
// still opens the extension's own dashboard.
function openDashboard(e) {
  if (e?.shiftKey) {
    const url = chrome.runtime.getURL("dashboard/dashboard.html");
    return chrome.tabs?.create ? chrome.tabs.create({ url, active: true }) : window.open(url, "_blank");
  }
  chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" }).catch(() => {});
  window.close();
}

// Report a problem: a picture of the tab this popup was opened over (activeTab)
// and the message go to AnyoneNear through the background worker.
function wireReport() {
  const $ = (id) => document.getElementById(id);
  let shot = null, tabUrl = "";
  $("report-btn").addEventListener("click", async () => {
    $("report").style.display = "block";
    $("report-msg").focus();
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      tabUrl = tab?.url || "";
      shot = await chrome.tabs.captureVisibleTab(tab?.windowId, { format: "jpeg", quality: 60 });
      $("report-img").src = shot; $("report-img").style.display = "block";
    } catch { shot = null; $("report-shot").checked = false; $("report-shot").disabled = true; }
  });
  $("report-shot").addEventListener("change", () => { $("report-img").style.display = $("report-shot").checked && shot ? "block" : "none"; });
  $("report-close").addEventListener("click", () => { $("report").style.display = "none"; });
  $("report-send").addEventListener("click", async () => {
    const message = $("report-msg").value.trim();
    if (message.length < 3) return showToast("Tell us a little about it first");
    $("report-send").disabled = true; $("report-send").textContent = "Sending…";
    const res = await chrome.runtime.sendMessage({ type: "SEND_FEEDBACK", kind: $("report-kind").value, message,
      screenshot: $("report-shot").checked ? shot : null, tabUrl }).catch((e) => ({ ok: false, error: e.message }));
    $("report-send").disabled = false; $("report-send").textContent = "Send";
    if (res?.ok) { $("report").style.display = "none"; $("report-msg").value = ""; showToast("Thanks! We got it."); }
    else showToast(res?.error || "Couldn't send. Try again.");
  });
}
