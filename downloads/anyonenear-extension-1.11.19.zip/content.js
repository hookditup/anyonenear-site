// AnyoneNear Content Script
// Runs inside the user's own authenticated Facebook session.
// Detects buyer-intent posts via MutationObserver, matches keywords,
// sends leads to background for Claude qualification, posts approved comments.

(function () {
  "use strict";

  // ─── State ────────────────────────────────────────────────────────────────
  let config = {
    keywords:        [],
    enabled:         true,
    businessPageName:"",       // e.g. "Austin AC Pros" — embedded in comment
    messengerUrl:    "",       // m.me/PageName — Messenger direct link for comment CTA
    scanAllGroups:   false,    // the account may scan every group (set by AnyoneNear, not the owner)
    monitorGroups:   [],       // the Watch list: only these groups are scanned
    areaWords:       [],       // city, county, nearby towns: required in "area only" groups
    skipWords:       [],       // "now hiring", "for sale"…: a matching post with one is skipped (no AI check)
    maxPostAgeDays:  3,        // posts older than this are skipped (0 = no limit)
  };

  // In-memory fast path for "already processed" lead IDs. Backed by
  // chrome.storage.local "seenLeadIds" ({ id: epochMs }) — the tab-cycling
  // flow reloads the page every few minutes, which used to wipe this Set and
  // re-send every visible post to background as brand new.
  const seenPostIds = new Set();
  let seenLeadTimes = {};             // id -> epochMs, mirror of what gets persisted
  let seenSaveTimer = null;
  const SEEN_TTL_MS = 30 * 24 * 60 * 60 * 1000; // forget IDs after 30 days
  const SEEN_MAX = 5000;                        // keep only the newest N

  let scanTimer = null;
  let isGroupPage = false;

  // sleep helper — used throughout
  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // After the extension is reloaded or updated, this copy of the script keeps
  // running in tabs that were already open, but every chrome.* call throws
  // "Extension context invalidated". Detect that and shut this copy down
  // quietly — a page refresh loads the new one.
  function extensionAlive() {
    try { return !!chrome.runtime?.id; } catch { return false; }
  }

  let orphaned = false;
  function shutDownIfOrphaned() {
    if (orphaned || extensionAlive()) return orphaned;
    orphaned = true;
    try { stopScanning(); } catch { /* ignore */ }
    try { dmObserver?.disconnect(); navObserver?.disconnect(); } catch { /* ignore */ }
    clearTimeout(seenSaveTimer);
    try { setBadge("off", "extension was updated — refresh this tab"); } catch { /* ignore */ }
    console.log("[AnyoneNear] Extension was reloaded — refresh this tab to resume scanning.");
    return true;
  }

  // ─── On-page status ───────────────────────────────────────────────────────
  // The pill and panel live in bubble.js (loaded first, same isolated world);
  // this only reports the scanner's state for the current page.
  const badge = { checked: 0, matches: 0, old: 0, skipOld: 0, skipWord: 0 };

  function setBadge(state, detail) {
    try { window.FB1Bubble?.status(state, detail); } catch { /* bubble unavailable */ }
  }

  function badgeWatching(extra) {
    const t = new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    setBadge("on", `watching · ${badge.checked} new post${badge.checked === 1 ? "" : "s"} checked here · ` +
      `${badge.matches} keyword match${badge.matches === 1 ? "" : "es"}${extra ? " · " + extra : ""} · ${t}`);
  }

  // chrome.runtime.sendMessage that never throws (orphaned script, or the
  // background worker momentarily unavailable).
  function sendToBackground(msg) {
    if (shutDownIfOrphaned()) return;
    try { chrome.runtime.sendMessage(msg).catch(() => {}); } catch { shutDownIfOrphaned(); }
  }

  // ─── Init ─────────────────────────────────────────────────────────────────
  async function init() {
    await loadConfig();
    await loadSeenIds();
    checkIfGroupPage();

    // Previously this returned early on anything that wasn't a group page —
    // including a direct load of /messages — so neither the navigation
    // observer nor the DM monitor was ever installed in that case.
    if (isMessagesPage()) {
      startDmMonitoring();
      observeNavigation();
    }

    if (!isGroupPage) return;

    log("AnyoneNear active on group page");
    startScanning();

    // Re-scan when Facebook's SPA navigates
    observeNavigation();
  }

  function isMessagesPage() {
    return window.location.href.includes("facebook.com/messages");
  }

  // ─── Seen-ID persistence ──────────────────────────────────────────────────
  // Drop entries older than SEEN_TTL_MS and cap at the SEEN_MAX newest.
  function pruneSeen(obj) {
    const now = Date.now();
    const entries = Object.entries(obj || {})
      .filter(([, t]) => typeof t === "number" && now - t < SEEN_TTL_MS)
      .sort((a, b) => b[1] - a[1])
      .slice(0, SEEN_MAX);
    return Object.fromEntries(entries);
  }

  function loadSeenIds() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["seenLeadIds"], (data) => {
        const stored = data.seenLeadIds && typeof data.seenLeadIds === "object"
          ? data.seenLeadIds
          : {};
        // Anything marked in memory before storage answered wins (newer).
        seenLeadTimes = pruneSeen({ ...stored, ...seenLeadTimes });
        for (const id of Object.keys(seenLeadTimes)) seenPostIds.add(id);
        if (Object.keys(stored).length !== Object.keys(seenLeadTimes).length) {
          scheduleSeenSave(); // write back the pruned set
        }
        resolve();
      });
    });
  }

  function markSeen(id) {
    if (!id) return;
    seenPostIds.add(id);
    seenLeadTimes[id] = Date.now();
    scheduleSeenSave();
  }

  // Debounced (~2s) write. Re-reads storage and merges first so two FB tabs
  // scanning at once don't clobber each other's seen IDs (last-writer-wins
  // on the whole object otherwise).
  function scheduleSeenSave() {
    clearTimeout(seenSaveTimer);
    seenSaveTimer = setTimeout(flushSeenIds, 2000);
  }

  function flushSeenIds() {
    clearTimeout(seenSaveTimer);
    seenSaveTimer = null;
    if (shutDownIfOrphaned()) return;
    chrome.storage.local.get(["seenLeadIds"], (data) => {
      const stored = data.seenLeadIds && typeof data.seenLeadIds === "object"
        ? data.seenLeadIds
        : {};
      seenLeadTimes = pruneSeen({ ...stored, ...seenLeadTimes });
      chrome.storage.local.set({ seenLeadIds: seenLeadTimes });
    });
  }

  // Best-effort flush of a pending debounced write before the tab navigates
  // away (cycling reloads the page) — not guaranteed to complete.
  window.addEventListener("pagehide", () => {
    if (seenSaveTimer) flushSeenIds();
  });

  async function loadConfig() {
    return new Promise((resolve) => {
      if (shutDownIfOrphaned()) return resolve();
      chrome.storage.sync.get(
        ["keywords", "enabled", "licenseStatus",
         "businessPageName", "messengerUrl", "scanAllGroups", "areaWords", "skipWords", "maxPostAgeDays"],
        (data) => {
          config = { ...config, ...data };
          config.scanAllGroups = data.scanAllGroups === true;
          config.areaWords = Array.isArray(data.areaWords) ? data.areaWords.map((w) => String(w).trim()).filter((w) => w.length >= 2) : [];
          config.skipWords = cleanSkipWords(data.skipWords);
          config.maxPostAgeDays = maxAgeDays(data.maxPostAgeDays);
          config.keywords = (data.keywords || [])
            .map((k) => k.toLowerCase().trim())
            .filter(Boolean);
          chrome.storage.local.get(["monitorGroups"], ({ monitorGroups }) => {
            config.monitorGroups = Array.isArray(monitorGroups) ? monitorGroups : [];
            resolve();
          });
        }
      );
    });
  }

  function checkIfGroupPage() {
    isGroupPage =
      /facebook\.com\/groups\//.test(window.location.href) ||
      /facebook\.com\/[^/]+\/groups\//.test(window.location.href);
  }

  // ─── Scanning ─────────────────────────────────────────────────────────────

  let domObserver = null;
  let scanDebounceTimer = null;

  // Debounced scan — fires after DOM settles, prevents rapid-fire scanning
  // when Facebook injects multiple posts at once
  function debouncedScan() {
    clearTimeout(scanDebounceTimer);
    scanDebounceTimer = setTimeout(() => {
      scanPosts();
    }, 500);
  }

  // MutationObserver replaces scroll-based priming entirely.
  // Watches the DOM for new [role="article"] elements being injected by Facebook
  // as the user naturally scrolls — or as Facebook pre-renders them.
  // Zero forced scrolling. Zero performance hit. Works across all tabs.
  function startDomObserver() {
    if (domObserver) return; // already running

    domObserver = new MutationObserver((mutations) => {
      let newArticleFound = false;

      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType !== 1) continue; // element nodes only

          // Check if the added node is an article or contains articles
          if (
            node.getAttribute?.('role') === 'article' ||
            node.querySelector?.('[role="article"]') ||
            node.hasAttribute?.('aria-posinset') ||
            node.querySelector?.('[aria-posinset]') ||
            node.getAttribute?.('data-pagelet')?.startsWith('FeedUnit') ||
            node.querySelector?.('[data-pagelet^="FeedUnit"]')
          ) {
            newArticleFound = true;
            break;
          }
        }
        if (newArticleFound) break;
      }

      if (newArticleFound) {
        debouncedScan();
      }
    });

    // Observe the entire document body for subtree changes
    domObserver.observe(document.body, {
      childList: true,
      subtree: true,
    });

    log("MutationObserver active — watching for new posts");
  }

  function stopDomObserver() {
    if (domObserver) {
      domObserver.disconnect();
      domObserver = null;
    }
    clearTimeout(scanDebounceTimer);
  }

  function startScanning() {
    if (!config.enabled) {
      log("Scanning turned off");
      setBadge("off", "turned off — switch it on in the extension popup");
      return;
    }
    if (config.keywords.length === 0) {
      log("No keywords set");
      setBadge("idle", "no keywords set — run the setup wizard");
      return;
    }

    // Don't scan if license is not active
    if (config.licenseStatus && config.licenseStatus !== "active") {
      log("License not active — scanning paused");
      setBadge("idle", "license not active — open the dashboard");
      return;
    }

    setBadge("on", "starting…");

    // Scan whatever is already in the DOM immediately
    sleep(1000).then(() => {
      scanPosts();

      // Watch for new posts as Facebook injects them naturally
      startDomObserver();

      // Fallback interval — catches any posts the observer might miss
      // due to Facebook rendering edge cases. Much less frequent than before.
      scanTimer = setInterval(scanPosts, 30000); // every 30s as safety net only
    });
  }

  function stopScanning() {
    if (scanTimer) {
      clearInterval(scanTimer);
      scanTimer = null;
    }
    stopDomObserver();
  }

  // Only groups on the Watch list are scanned: not the Groups feed
  // (/groups/feed, every joined group mixed together) and not groups the
  // owner is just browsing. That keeps lead checks, replies and the plan's
  // group count to the groups they picked. Accounts with scanAllGroups
  // (AnyoneNear's own) scan every group page, the feed included.
  function groupSlug(url) {
    const m = String(url || "").match(/\/groups\/([^/?#]+)/);
    return m ? decodeURIComponent(m[1]).toLowerCase() : "";
  }

  // Keep the Watch list and the all-groups flag current without a reload.
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.monitorGroups) config.monitorGroups = Array.isArray(changes.monitorGroups.newValue) ? changes.monitorGroups.newValue : [];
      if (area === "sync" && changes.scanAllGroups) config.scanAllGroups = changes.scanAllGroups.newValue === true;
      if (area === "sync" && changes.areaWords) config.areaWords = Array.isArray(changes.areaWords.newValue) ? changes.areaWords.newValue.map((w) => String(w).trim()).filter((w) => w.length >= 2) : [];
      if (area === "sync" && changes.skipWords) config.skipWords = cleanSkipWords(changes.skipWords.newValue);
      if (area === "sync" && changes.maxPostAgeDays) config.maxPostAgeDays = maxAgeDays(changes.maxPostAgeDays.newValue);
    });
  } catch { /* extension context gone */ }

  function isWatchedGroupPage() {
    if (config.scanAllGroups) return true;
    const here = groupSlug(location.pathname);
    if (!here || ["feed", "discover", "joins", "notifications", "search"].includes(here)) return false;
    const name = extractGroupName().trim().toLowerCase();
    return config.monitorGroups.some((g) => g && g.active !== false &&
      (groupSlug(g.url) === here || (name && String(g.name || "").trim().toLowerCase() === name)));
  }

  // "Area only" groups (big statewide or national ones): a post must also name
  // one of the business's area words before it counts, so posts from far away
  // don't use up AI lead checks. Needs at least one area word to apply.
  function currentGroupAreaOnly() {
    if (!config.areaWords.length) return false;
    const here = groupSlug(location.pathname);
    return config.monitorGroups.some((g) => g && g.areaOnly === true && groupSlug(g.url) === here);
  }

  function mentionsArea(text) {
    const t = String(text || "").toLowerCase();
    return config.areaWords.some((w) => new RegExp(`(^|[^a-z0-9])${w.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`, "i").test(t));
  }

  // Skip words (2026-09-29): phrases that mark a post as an ad or a job
  // listing ("now hiring", "for sale"). A post with one never gets the AI check.
  // Posts older than maxPostAgeDays are skipped too: a reply a week late is
  // no use, and old posts showing up means the feed isn't newest-first.
  const normText = (t) => String(t || "").toLowerCase().replace(/[\u2018\u2019]/g, "'");
  // Same list as the server's DEFAULT_SKIP_WORDS (_shared/watch-config.ts),
  // used until the app sends this business's own list.
  const DEFAULT_SKIP_WORDS = ["now hiring", "we're hiring", "we are hiring", "for sale", "now booking", "booking now",
    "taking new clients", "accepting new clients", "limited spots", "we specialize in", "dm for pricing", "message us for"];
  function cleanSkipWords(v) {
    return (Array.isArray(v) ? v : DEFAULT_SKIP_WORDS).map((w) => normText(w).trim()).filter((w) => w.length >= 2);
  }
  function maxAgeDays(v) {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 ? Math.min(60, n) : 3;
  }
  function skipWordIn(text) {
    const t = normText(text);
    return config.skipWords.find((w) => new RegExp(`(^|[^a-z0-9])${w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`).test(t)) || "";
  }
  function postTooOld(post) {
    const t = Number(post.timestamp);
    return config.maxPostAgeDays > 0 && t > 0 && Date.now() - t > config.maxPostAgeDays * 864e5;
  }

  async function scanPosts() {
    if (shutDownIfOrphaned()) return;
    if (!config.enabled || config.keywords.length === 0) return;
    if (!isWatchedGroupPage()) {
      if (!scanPosts.skipLogged) { scanPosts.skipLogged = true; log("Not a watched group — not scanning this page"); }
      setBadge("idle", "not one of your watched groups");
      return;
    }
    scanPosts.skipLogged = false;

    // FB leaves each post's timestamp link without a real href until it's
    // hovered/focused. Nudge them first so posts get their numeric post ID
    // (stable dedupe + a permalink for replying) instead of a text hash.
    // The wait means scans can now overlap (observer + 30s timer); one at a
    // time, so a post can't pass the seen-check in two scans at once.
    if (scanPosts.running) return;
    scanPosts.running = true;
    try {
      if (revealPermalinks(postContainers()) > 0) await sleep(400);
    } finally {
      scanPosts.running = false;
    }

    const posts = extractPosts();
    let matchCount = 0;
    const areaOnly = currentGroupAreaOnly();

    for (const post of posts) {
      // extractPosts() pre-filters by seenPostIds (and dedupes within the
      // pass), so every post reaching here is already known-new — markSeen()
      // just records it in memory and schedules the persisted write.
      markSeen(post.id);

      const matches = findKeywordMatches(post.text, config.keywords);
      const mention = isOwnMention(post.text);
      const old = postTooOld(post);
      if (old) badge.old++;
      if (matches.length > 0 && !mention && areaOnly && !mentionsArea(post.text)) continue;   // not in the business's area
      if ((matches.length > 0 || mention) && old) { badge.skipOld++; continue; }
      if (matches.length > 0 && !mention) {
        const w = skipWordIn(post.text);
        if (w) { badge.skipWord++; log(`Skipped a matching post with the skip word "${w}":`, post.id); continue; }
      }
      if ((matches.length > 0 || mention) && post.ownReplied) {
        log("Skipped a matching post you've already commented on:", post.id);
        continue;
      }
      if (matches.length > 0 || mention) {
        matchCount++;
        const lead = buildLeadObject(post, matches, mention);
        handleLead(lead);
      }
    }

    badge.checked += posts.length;
    badge.matches += matchCount;
    if (posts.length) recordScanToday(posts.length, matchCount);
    if (postContainers().length === 0 && badge.checked === 0) {
      setBadge("idle", "no posts found on this page yet");
    } else {
      badgeWatching();
    }

    // One line per scan that saw anything new — tells "found no posts" (FB
    // markup changed) apart from "found posts, none matched a keyword".
    if (posts.length > 0 || !scanPosts.reported) {
      scanPosts.reported = true;
      const articles = postContainers().length;
      log(`Scan: ${articles} post container(s) on page, ${posts.length} new post(s)/comment(s), ` +
          `${matchCount} keyword match(es) — ${config.keywords.length} keywords active`);
    }
  }

  // Today's running totals across all tabs, for the bubble's "Today" row.
  function recordScanToday(checked, matched) {
    if (shutDownIfOrphaned()) return;
    const day = new Date().toDateString();
    chrome.storage.local.get(["scanToday"], ({ scanToday }) => {
      const cur = scanToday && scanToday.day === day ? scanToday : { day, checked: 0, matched: 0 };
      chrome.storage.local.set({ scanToday: { day, checked: cur.checked + checked, matched: cur.matched + matched } });
    });
  }

  // ─── Post Extraction ──────────────────────────────────────────────────────
  // Facebook changes its DOM structure frequently.
  // We use multiple selector strategies so the extension degrades gracefully.
  function extractPosts() {
    const posts = [];
    // Dedupe within this single pass — the same lead can be reached twice
    // (e.g. a comment and a strategy-2 container, or duplicate FB renders).
    const seenThisPass = new Set();
    const isNew = (id) => id && !seenPostIds.has(id) && !seenThisPass.has(id);

    // Strategy 1: top-level post containers (see postContainers()). Comments
    // inside them are mined by extractCommentLeads() below.
    for (const el of postContainers()) {
      // Cheap ID first when the post has a permalink (fb_<postId>); only posts
      // without one pay for the clone+strip text extraction to build a hash ID.
      const { id, postUrl, text } = computePostIdentity(el);
      if (isNew(id)) {
        seenThisPass.add(id);
        const post = parseArticleElement(el, id, postUrl, text);
        if (post) { post.ownReplied = hasOwnComment(el); posts.push(post); }
      }

      // Buyer intent shows up constantly in REPLIES to other people's posts —
      // "anyone recommend a good plumber?" threads are exactly what this
      // extension exists to catch — but comments were previously stripped out
      // and never looked at as their own lead candidates. Mine them here.
      // Done even when the parent post is already seen, so comments that
      // arrive later on an old post still get picked up.
      for (const c of extractCommentLeads(el, isNew)) {
        seenThisPass.add(c.id);
        posts.push(c);
      }
    }

    // Strategies 2/3 only look inside the main column — never the Messenger
    // chat popups, notifications or other page chrome.
    const main = document.querySelector('[role="main"]');

    // Strategy 2: Feed story containers
    if (posts.length === 0 && main) {
      const storyEls = main.querySelectorAll(
        '[data-pagelet^="FeedUnit"], [data-pagelet^="GroupsFeed"]'
      );
      for (const el of storyEls) {
        const { id, text } = computePostIdentity(el);
        if (!isNew(id)) continue;
        seenThisPass.add(id);
        const post = parseGenericElement(el, id, text);
        if (post) { post.ownReplied = hasOwnComment(el); posts.push(post); }
      }
    }

    // Strategy 3: Any div with substantial text that looks like a post
    // Facebook sometimes renders without semantic roles at all
    if (posts.length === 0 && main) {
      const divEls = main.querySelectorAll(
        'div[data-testid="post_message"], div[class*="userContent"], div[data-ad-preview="message"]'
      );
      for (const el of divEls) {
        const target = el.closest('div[id]') || el;
        const { id, text } = computePostIdentity(target);
        if (!isNew(id)) continue;
        seenThisPass.add(id);
        const post = parseGenericElement(target, id, text);
        if (post) posts.push(post);
      }
    }

    return posts;
  }

  // Top-level posts on the page. Current FB group feeds mark each post as a
  // [role="feed"] child with aria-posinset (the post itself is NOT a
  // role="article" any more — only its comments are). Older markup and single
  // post pages still use a top-level role="article". Both lookups are limited
  // to the feed / main column: the Messenger chat popup renders every message
  // as a role="article" too, and those must never be read as group posts.
  function postContainers() {
    const feedPosts = [...document.querySelectorAll('[role="feed"] [aria-posinset]')]
      .filter((el) => !(el.parentElement && el.parentElement.closest("[aria-posinset]")));
    if (feedPosts.length) return feedPosts;

    const main = document.querySelector('[role="main"]');
    if (!main) return [];
    return [...main.querySelectorAll('[role="article"]')]
      .filter((el) => !(el.parentElement && el.parentElement.closest('[role="article"]')));
  }

  // Dispatches hover/focus events on post-header links that have no real URL
  // yet (href empty, "#" or query-only), which makes FB fill in the permalink
  // shortly after. Synthetic events only — nothing is focused or scrolled.
  // Returns how many links were nudged.
  function revealPermalinks(containers) {
    let nudged = 0;
    for (const el of containers) {
      for (const a of el.querySelectorAll("a")) {
        const art = a.closest('[role="article"]');
        if (art && art !== el) continue; // a comment's link
        const href = (a.getAttribute("href") || "").trim();
        if (href && !href.startsWith("?") && href !== "#") continue;
        if (a.dataset.fb1Nudged) continue;
        a.dataset.fb1Nudged = "1";
        a.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
        a.dispatchEvent(new FocusEvent("focusin", { bubbles: true }));
        nudged++;
      }
    }
    return nudged;
  }

  // Comments nested inside a post — FB renders each as its own [role="article"].
  // postUrl is ALWAYS null for comments (safety rule): background.js's
  // fireComment() skips auto-posting for any lead without a postUrl, so a
  // comment lead can never trigger an automated reply. They still get
  // AI-qualified, notified, and relayed to GHL; the comment's own link (if
  // found) travels separately as sourceUrl for manual follow-up.
  function extractCommentLeads(articleEl, isNew) {
    const leads = [];
    const commentEls = articleEl.querySelectorAll('[role="article"]');

    for (const cEl of commentEls) {
      // Prefer FB's own comment ID — cheap, and stable as the comment ages.
      const { commentId, link } = extractCommentLink(cEl);
      let id = commentId ? `fbc_${commentId}` : null;
      if (id && !isNew(id)) continue;

      const text = extractCommentBody(cEl);
      if (!text || text.length < 15) continue;
      if (isOwnComment(cEl)) continue;   // our own comment is never a lead

      if (!id) id = hashLeadId(text);
      if (!isNew(id)) continue;

      const authorEl = cEl.querySelector('a[role="link"] strong, a[role="link"] span');
      const authorName = authorEl ? authorEl.textContent.trim() : "Unknown";

      leads.push({
        id,
        text,
        timestamp: extractTimestamp(cEl),
        postUrl: null,
        sourceUrl: link,
        authorName,
        groupName: extractGroupName(),
        groupId: extractGroupId(),
        isComment: true,
      });
    }

    return leads;
  }

  // Finds the comment's own link (the one carrying comment_id=<n>), ignoring
  // links that belong to nested replies. For a reply FB's link carries both
  // comment_id (the PARENT comment) and reply_comment_id (this reply) — use the
  // reply's own id so a reply never collides with its parent.
  function extractCommentLink(cEl) {
    const anchors = cEl.querySelectorAll('a[href*="comment_id="]');
    for (const a of anchors) {
      if (a.closest('[role="article"]') !== cEl) continue; // belongs to a nested reply
      try {
        const u = new URL(a.href, window.location.origin);
        const cid = u.searchParams.get("reply_comment_id") || u.searchParams.get("comment_id");
        if (cid && /^\d+$/.test(cid)) return { commentId: cid, link: a.href };
      } catch { /* malformed href — keep looking */ }
    }
    return { commentId: null, link: null };
  }

  // Comment BODY only — no author, no "Like · Reply · 3h" row, no nested
  // replies — so the hash-fallback ID doesn't drift as the relative time ages.
  function extractCommentBody(cEl) {
    const clone = cEl.cloneNode(true);
    clone
      .querySelectorAll('[role="article"], [role="button"], button, svg, ul[role="list"]')
      .forEach((node) => node.remove());

    // FB puts the comment text in div[dir="auto"] blocks; take the outermost ones.
    const blocks = [...clone.querySelectorAll('div[dir="auto"]')].filter(
      (d) => !(d.parentElement && d.parentElement.closest('div[dir="auto"]'))
    );
    let text = blocks
      .map((b) => (b.innerText || b.textContent || "").trim())
      .filter(Boolean)
      .join("\n");

    if (!text) {
      // No dir=auto blocks — fall back to the whole (stripped) clone.
      text = (clone.innerText || clone.textContent || "").trim();
    }

    return text
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .substring(0, 800);
  }

  function parseArticleElement(el, precomputedId, precomputedUrl, precomputedText) {
    let id = precomputedId;
    let postUrl = precomputedUrl || null;
    let text = precomputedText || null;
    if (!id) ({ id, postUrl, text } = computePostIdentity(el));
    if (!id) return null;

    // Extract text — grab all visible text nodes, skip nav/button text
    if (!text) text = extractVisibleText(el);
    if (!text || text.length < 20) return null;

    const timestamp = extractTimestamp(el);

    // postUrl is deliberately null (not window.location.href) when no permalink
    // with an extractable post ID is found — background.js's fireComment()
    // refuses to auto-post for a lead with no real postUrl, and postComment()
    // itself refuses (no_permalink) if it can't pull a post ID out of it.

    // Try to get author name
    const authorEl = el.querySelector(
      '[data-ad-rendering-role="profile_name"] a, [data-ad-rendering-role="profile_name"], ' +
      'a[role="link"] strong, h2 a[role="link"]'
    );
    const authorName = authorEl ? authorEl.textContent.trim() : "Unknown";

    // Group name from page title or URL
    const groupName = extractGroupName();
    const groupId = extractGroupId();

    return { id, text, timestamp, postUrl, authorName, groupName, groupId };
  }

  // Top-level post permalink. Ignores:
  //   - links inside nested [role="article"] (comments)
  //   - links inside the message body (someone pasting/sharing another post)
  //   - links without an extractable numeric post ID
  // and prefers anchors that sit BEFORE the message body in DOM order (the
  // header timestamp/permalink) over later ones — a shared-post attachment
  // renders its own header + timestamp link to the ORIGINAL post further down.
  function extractPostUrl(el) {
    const bodyEl =
      el.querySelector('[data-ad-rendering-role="story_message"]') ||
      el.querySelector('[data-ad-comet-preview="message"]') ||
      el.querySelector('[data-ad-preview="message"]');

    const anchors = el.querySelectorAll(
      'a[href*="/permalink/"], a[href*="story_fbid="], a[href*="/posts/"], a[href*="multi_permalinks="]'
    );

    let fallback = null;
    for (const a of anchors) {
      const art = a.closest('[role="article"]');
      if (art && art.parentElement && art.parentElement.closest('[role="article"]')) continue; // in a comment
      if (bodyEl && bodyEl.contains(a)) continue;
      if (!extractPostId(a.href)) continue;

      if (!bodyEl) return a.href; // no body marker — first in DOM order is the header
      const beforeBody = bodyEl.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING;
      if (beforeBody) return a.href;
      if (!fallback) fallback = a.href;
    }
    return fallback;
  }

  // Numeric post ID from any of FB's post URL shapes:
  //   /groups/<g>/posts/<id>, /groups/<g>/permalink/<id>,
  //   ?story_fbid=<id>, /permalink.php?story_fbid=<id>, ?multi_permalinks=<id>
  // Returns null for anything else (incl. non-numeric "pfbid..." IDs).
  function extractPostId(url) {
    if (!url || typeof url !== "string") return null;
    let u;
    try {
      u = new URL(url, window.location.origin);
    } catch {
      return null;
    }

    const pathMatch =
      u.pathname.match(/\/posts\/(pfbid[A-Za-z0-9]{10,}|\d+)(?:[/?#]|$)/) ||
      u.pathname.match(/\/permalink\/(pfbid[A-Za-z0-9]{10,}|\d+)(?:[/?#]|$)/);
    if (pathMatch) return pathMatch[1];

    // FB now hands out opaque "pfbid…" post ids as often as numeric ones; both
    // work in /groups/<g>/posts/<id>/ permalinks.
    const storyFbid = u.searchParams.get("story_fbid");
    if (storyFbid && /^(pfbid[A-Za-z0-9]{10,}|\d+)$/.test(storyFbid)) return storyFbid;

    // multi_permalinks can be a comma-separated list — the first is the target
    const multi = (u.searchParams.get("multi_permalinks") || "").split(",")[0];
    if (multi && /^\d+$/.test(multi)) return multi;

    return null;
  }

  // FB's own machine-readable timestamp (data-utime / datetime) is frequently
  // absent from current markup, and this used to fall straight through to
  // Date.now() — meaning "detected_at" was silently always the SCAN time, not
  // the actual POST time, for most posts. That's not just cosmetic: any
  // recency-based prioritization (surfacing the freshest "right now" leads
  // first) is worthless if every post looks equally fresh. FB commonly puts
  // the real human-readable date in the timestamp link's title/aria-label
  // even when the machine-readable attributes are missing — try that before
  // giving up. Returns "" when the post time can't be read: the lead then
  // shows its scan time (buildLead falls back to now) but carries no postedAt,
  // so the owner's response-speed stat only counts posts whose real time is known.
  // Otherwise returns a numeric epoch-MILLISECONDS string, regardless of source —
  // data-utime is Facebook's legacy unix-SECONDS format, the HTML5 datetime
  // attribute and aria-label/title text are ISO/human date strings. Mixing
  // those formats without normalizing (e.g. feeding unix-seconds straight into
  // `new Date(n)`, which expects milliseconds) would silently produce dates
  // from 1970.
  function extractTimestamp(el) {
    // A time in the future or over 60 days old is a misread, not a post time.
    const plausible = (ms) => ms > Date.now() - 60 * 86400_000 && ms < Date.now() + 5 * 60_000;
    const timeEl = el.querySelector("abbr[data-utime], time");
    if (timeEl) {
      const utime = timeEl.getAttribute("data-utime");
      if (utime && /^\d+$/.test(utime) && plausible(Number(utime) * 1000)) return (Number(utime) * 1000).toString();

      const iso = timeEl.getAttribute("datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed) && plausible(parsed)) return parsed.toString();
      }
    }

    const timeLink = el.querySelector(
      'a[href*="/permalink/"], a[href*="?story_fbid="], a[href*="/posts/"], a[aria-label][href*="/"]'
    );
    const label = timeLink?.getAttribute("aria-label") || timeLink?.getAttribute("title");
    if (label) {
      // "Friday, September 26, 2026 at 3:14 PM" — Date.parse chokes on " at ".
      const parsed = Date.parse(label.replace(/\s+at\s+/i, " "));
      if (!Number.isNaN(parsed) && plausible(parsed)) return parsed.toString();
    }

    return "";
  }

  function parseGenericElement(el, precomputedId, precomputedText) {
    let id = precomputedId;
    let text = precomputedText || null;
    if (!id) ({ id, text } = computePostIdentity(el));
    if (!id) return null;
    if (!text) text = extractVisibleText(el);
    if (!text || text.length < 20) return null;
    return {
      id,
      text,
      timestamp: extractTimestamp(el),
      // Same reasoning as parseArticleElement — these fallback strategies (2/3)
      // never even look for a permalink, so window.location.href was always the
      // whole feed/group URL, not a specific post. null, not a fake per-post URL.
      postUrl: null,
      authorName: "Unknown",
      groupName: extractGroupName(),
      groupId: extractGroupId(),
    };
  }

  function extractVisibleText(el) {
    const clone = el.cloneNode(true);

    // Remove the comment section entirely — we only want the original post text.
    // Comments sit in a nested article or in elements after the post body.
    // These selectors target the comment thread container.
    const commentSelectors = [
      '[aria-label*="Comment" i]',
      '[role="article"] [role="article"]', // nested articles = comments
      'ul[role="list"]',                   // comment list
      '[data-visualcompletion="ignore"]',
    ];
    commentSelectors.forEach(sel => {
      clone.querySelectorAll(sel).forEach(node => node.remove());
    });

    // Remove UI chrome — buttons, icons, reaction bars, share bars
    const uiSelectors = [
      '[role="button"]',
      '[role="navigation"]',
      '[role="complementary"]',
      "svg",
      "button",
      'div[aria-label*="Like"]',
      'div[aria-label*="Comment"]',
      'div[aria-label*="Share"]',
      'div[aria-label*="Send"]',
      // NOTE: [data-ad-comet-preview="message"] used to be in this list, but
      // it's FB's post-MESSAGE container — stripping it deleted the post body.
    ];
    uiSelectors.forEach(sel => {
      clone.querySelectorAll(sel).forEach(node => node.remove());
    });

    // Try to isolate just the post body text element
    // Facebook wraps the actual post text in a specific container — check the
    // message containers first, before the much looser div[dir="auto"] guess.
    const postBody =
      clone.querySelector('[data-ad-rendering-role="story_message"]') ||
      clone.querySelector('[data-ad-comet-preview="message"]') ||
      clone.querySelector('[data-ad-preview="message"]') ||
      clone.querySelector('[data-testid="post_message"]') ||
      clone.querySelector('div[dir="auto"]') ||
      clone;

    return (postBody.innerText || clone.innerText)
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .substring(0, 1500);
  }

  // Stable lead ID for a top-level post (or strategy-2/3 container):
  //   - fb_<postId>          when a header permalink with a numeric post ID exists
  //   - h_<groupId>_<hash>   otherwise, hashed over the extracted BODY text only
  // The old fallback hashed innerText, which includes the author + relative
  // time ("3h" → "4h"), so the same post got a new ID as it aged.
  // Returns { id, postUrl, text } — text is only filled when it had to be
  // extracted for the hash, so callers can reuse it instead of re-extracting.
  function computePostIdentity(el) {
    const postUrl = extractPostUrl(el);
    const postId = extractPostId(postUrl);
    if (postId) {
      // Clean permalink — FB's hrefs carry long __cft__/__tn__ tracking
      // queries that are useless downstream and change between renders.
      // Always the /permalink/ form: the /posts/ form of the same ID can send
      // you to the group instead of the post (CONNECT Utah, 2026-09-30).
      const gid = extractGroupId();
      const clean = gid !== "unknown"
        ? `https://www.facebook.com/groups/${gid}/permalink/${postId}/`
        : postUrl.split(/[?#]/)[0];
      return { id: `fb_${postId}`, postUrl: clean, text: null };
    }

    const text = extractVisibleText(el);
    return { id: hashLeadId(text), postUrl: null, text };
  }

  // Hash fallback, namespaced by group. Without the group prefix, two posts in
  // two different groups sharing a common opener ("Anyone recommend a good...")
  // would collide and the second would be silently treated as already-seen.
  // Only the first 200 chars are hashed so expanding a "See more" post (which
  // changes the extracted length) doesn't change its ID.
  function hashLeadId(bodyText) {
    const body = (bodyText || "").replace(/\s+/g, " ").trim().substring(0, 200);
    if (!body) return null;
    return `h_${extractGroupId()}_${simpleHash(body)}`;
  }

  // Numeric ID or vanity slug from /groups/<id>/ in the current URL.
  function extractGroupId() {
    const match = window.location.pathname.match(/\/groups\/([^/?#]+)/);
    return match ? decodeURIComponent(match[1]) : "unknown";
  }

  function extractGroupName() {
    // The group title is the H1 inside the main column. Facebook also renders
    // H1s for the notifications panel and other chrome, so those are skipped.
    const skip = /^(notifications|facebook|marketplace|menu|home|groups|search results)$/i;
    const h1s = [...document.querySelectorAll('[role="main"] h1'), ...document.querySelectorAll("h1")];
    for (const h1 of h1s) {
      const t = h1.textContent.trim();
      if (t && !skip.test(t)) return t;
    }

    // From URL
    const match = window.location.pathname.match(/\/groups\/([^/]+)/);
    if (match) return decodeURIComponent(match[1]).replace(/-/g, " ");

    return "Unknown Group";
  }

  // ─── Keyword Matching ──────────────────────────────────────────────────────
  // Supports two formats:
  //   Single keyword:  "plumber"             — fires if present anywhere in post
  //   AND group:       "plumber+looking"     — BOTH terms must appear in the post
  //
  // In the popup, enter AND groups with a + between terms:
  //   "plumber+looking for" = only fires when both appear in the same post
  //   "plumber+recommend"   = fires for "Can anyone recommend a plumber?" but not
  //                           "I'm a plumber taking new clients"

  function findKeywordMatches(text, keywords) {
    const lowerText = text.toLowerCase();
    const matches = [];

    for (const keyword of keywords) {
      const isAndGroup = keyword.includes("+");

      if (isAndGroup) {
        // AND logic — every term in the group must appear
        const terms = keyword.split("+").map(t => t.trim().toLowerCase()).filter(Boolean);
        const allMatch = terms.every(term => {
          const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          return new RegExp(`\\b${escaped}\\b`, "i").test(lowerText);
        });

        if (allMatch) {
          // Build snippet around the first term
          const firstTerm = terms[0];
          const idx = lowerText.indexOf(firstTerm);
          const start = Math.max(0, idx - 60);
          const end = Math.min(text.length, idx + firstTerm.length + 60);
          const snippet = "…" + text.substring(start, end).trim() + "…";
          matches.push({ keyword: terms.join(" + "), snippet });
        }

      } else {
        // OR logic — single keyword must appear
        const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const regex = new RegExp(`\\b${escaped}\\b`, "gi");

        if (regex.test(lowerText)) {
          const idx = lowerText.indexOf(keyword.toLowerCase());
          const start = Math.max(0, idx - 60);
          const end = Math.min(text.length, idx + keyword.length + 60);
          const snippet = "…" + text.substring(start, end).trim() + "…";
          matches.push({ keyword, snippet });
        }
      }
    }

    return matches;
  }

  // ─── Own-business mentions ────────────────────────────────────────────────
  // Someone naming or tagging the customer's own Business Page ("call Austin
  // AC Pros, they're great") is a warm lead even with no keyword match. Our
  // own posted replies also contain the page name, so anything carrying our
  // Messenger link is skipped.
  function pageSlug() {
    const m = String(config.messengerUrl || "").match(/m\.me\/([A-Za-z0-9.\-_]+)/i);
    return m ? m[1].toLowerCase() : "";
  }

  function isOwnMention(text) {
    const name = String(config.businessPageName || "").trim().toLowerCase();
    const t = String(text || "").toLowerCase();
    const slug = pageSlug();
    if (slug && t.includes(`m.me/${slug}`)) return false;        // our own reply
    if (name.length >= 4 && t.includes(name)) return true;
    return !!slug && slug.length >= 4 && new RegExp(`\\b${slug.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i").test(t);
  }

  // ─── Already replied ──────────────────────────────────────────────────────
  // A post the owner (or their Page) has already commented on isn't a lead to
  // reply to again. Signs a comment is ours, any one is enough:
  //   - its author link carries the signed-in account's ID (c_user cookie;
  //     group comments link to /groups/<id>/user/<uid>/)
  //   - FB's own-comment menu ("Edit or delete this"; others get "Hide or report")
  //   - the author is the business Page, or the text has our Messenger link
  // Only comments FB has rendered are seen, so posting re-checks on the post itself.
  function selfUserId() {
    const m = document.cookie.match(/(?:^|;\s*)c_user=(\d+)/);
    return m ? m[1] : "";
  }

  function isOwnComment(cEl) {
    const uid = selfUserId();
    const slug = pageSlug();
    const pageName = String(config.businessPageName || "").trim().toLowerCase();
    if (slug && (cEl.innerText || "").toLowerCase().includes(`m.me/${slug}`)) return true;
    if (cEl.querySelector('[aria-label="Edit or delete this" i]')) return true;
    // The author is the first profile link (avatar or name), not people tagged in the text.
    for (const a of Array.from(cEl.querySelectorAll("a[href]")).slice(0, 2)) {
      const href = a.getAttribute("href") || "";
      if (uid && (href.includes(`/user/${uid}/`) || new RegExp(`[?&]id=${uid}(?:&|$)`).test(href) || href.includes(`/${uid}/`))) return true;
    }
    const label = (cEl.getAttribute("aria-label") || "").toLowerCase();   // "Comment by Name 2 hours ago"
    const author = (cEl.querySelector('a[role="link"] strong, a[role="link"] span')?.textContent || "").trim().toLowerCase();
    return pageName.length >= 4 && (author === pageName || label.startsWith(`comment by ${pageName}`));
  }

  function hasOwnComment(scopeEl) {
    for (const cEl of scopeEl.querySelectorAll('[role="article"]')) {
      if (cEl !== scopeEl && isOwnComment(cEl)) return true;
    }
    return false;
  }

  // ─── Lead Object ──────────────────────────────────────────────────────────
  function buildLeadObject(post, matches, mention = false) {
    return {
      mention,
      id: post.id,
      source: post.isComment ? "facebook_comment" : "facebook_group",
      groupName: post.groupName,
      groupId: post.groupId || extractGroupId(),
      authorName: post.authorName,
      postUrl: post.postUrl,
      // Comment leads: the comment's own link, for manual follow-up only.
      // Never used for auto-posting (postUrl stays null for comments).
      sourceUrl: post.sourceUrl || null,
      postText: post.text.substring(0, 500),
      matchedKeywords: [...(mention ? ["@mention"] : []), ...matches.map((m) => m.keyword)],
      snippet: matches[0]?.snippet || post.text.substring(0, 120),
      // Real post/comment time when FB's markup exposed it (see extractTimestamp),
      // not just "now" — matters for any future freshness-based prioritization.
      timestamp: new Date(Number(post.timestamp) || Date.now()).toISOString(),
      // Only when the real post time was read — the response-speed stat.
      postedAt: Number(post.timestamp) ? new Date(Number(post.timestamp)).toISOString() : null,
      pageUrl: window.location.href,
    };
  }

  // ─── Lead Handling ────────────────────────────────────────────────────────
  // Keyword match is NOT the final gate — Claude qualifies buyer intent first.
  // The background script calls Claude, and only if Claude confirms the person
  // is SEEKING the service (not offering it) does the alert fire.
  function handleLead(lead) {
    log("Keyword match — sending to Claude for qualification:", lead.matchedKeywords);

    // Send to background — Claude will qualify, then decide whether to alert
    sendToBackground({
      type: "LEAD_FOUND",
      lead,
      businessPageName: config.businessPageName,
      messengerUrl: config.messengerUrl,
    });
  }

  // ─── Comment Posting Engine ───────────────────────────────────────────────
  // Posts a comment to a Facebook group post using the active session DOM.
  // Strategy: find the comment box for the target post, type the text,
  // then click the submit button. All actions mimic normal human interaction.

  // The same group post as /permalink/<id> ↔ /posts/<id>.
  function otherPostLink(url) {
    return /\/permalink\//.test(url) ? url.replace("/permalink/", "/posts/") : url.replace("/posts/", "/permalink/");
  }

  async function postComment(postUrl, commentText, tagName) {
    log("Attempting to post comment on:", postUrl);

    try {
      // Step 1: Strict post-ID match. The old check was
      //   postUrl.includes(currentUrl.split("?")[0])
      // which is TRUE on the group feed (the feed URL is a prefix of every post
      // URL in the group), so comments landed on whatever post was first in
      // the feed. Now: both IDs must be extractable and equal.
      const targetId = extractPostId(postUrl);
      if (!postUrl || !targetId) {
        log("No extractable post ID in postUrl — refusing to post");
        return { ok: false, reason: "no_permalink" };
      }

      // A deleted post (or one removed by an admin, or no longer visible to
      // this account) sends its link to the group instead: if we already went
      // to the post's link and aren't on it, the post is gone.
      const currentId = extractPostId(window.location.href);
      const navKey = `an_post_nav_${targetId}`;
      if (currentId !== targetId) {
        let tries = 0;
        try { tries = Number(sessionStorage.getItem(navKey)) || 0; sessionStorage.setItem(navKey, String(tries + 1)); } catch { /* storage blocked */ }
        // First the saved link, then the same post in the other link shape
        // (/posts/ ↔ /permalink/): Facebook opens some posts in only one.
        if (tries >= 2) { log("Neither link shape opened the post: deleted or not visible"); return { ok: false, reason: "post_unavailable" }; }
        window.location.href = tries === 0 ? postUrl : otherPostLink(postUrl);
        return { ok: false, reason: "navigating", retry: true };
      }
      if (contentUnavailable()) return { ok: false, reason: "post_unavailable" };

      if (!commentText || !commentText.trim()) {
        return { ok: false, reason: "insert_failed" };
      }

      // Never a second reply: if the owner or their Page has commented on
      // this post since it was found (or before, out of sight), stop here.
      await sleep(1500);
      if (hasOwnComment(getCommentScope())) {
        log("Already commented on this post — not posting again");
        return { ok: false, reason: "already_replied" };
      }

      // Replies generated with tagPage end in a literal "@Page Name". Type the
      // text without it, then make it a real tag via the typeahead below.
      let tagAtEnd = false;
      if (tagName) {
        const suffix = `@${tagName}`;
        const trimmed = commentText.trimEnd();
        if (trimmed.toLowerCase().endsWith(suffix.toLowerCase())) {
          commentText = trimmed.slice(0, -suffix.length).trimEnd();
          tagAtEnd = true;
        }
      }

      // Step 2: Find the Lexical comment editor, scoped to the post (dialog or
      // main column) — never document-wide, never the generic
      // [aria-label*="comment"] match that used to hit other posts' buttons.
      await sleep(1000);
      let box = findCommentBox(getCommentScope());

      if (!box) {
        // Box not rendered yet — click this post's "Leave/Write a comment"
        // opener, looked up inside the same scope only.
        const opener = getCommentScope().querySelector(
          '[aria-label*="Leave a comment" i], [aria-label*="Write a comment" i]'
        );
        if (opener) {
          opener.click();
          await sleep(800);
        }
        box = await waitForMatch(() => findCommentBox(getCommentScope()), 6000);
      }

      if (!box) {
        // Hidden page (background tab, minimized or covered window): Facebook
        // doesn't draw the comment box there. Say so, so it can be told apart.
        const hidden = document.visibilityState !== "visible";
        const pageText = (document.querySelector('[role="main"]')?.innerText || "").slice(0, 4000);
        const reason = hidden ? "comment_box_not_found_hidden"
          : /turned off commenting|commenting has been turned off|comments (are|have been) turned off/i.test(pageText) ? "comments_off"
          : postContainers().length === 0 ? "post_unavailable"
          : "comment_box_not_found";
        log("Comment box not found:", reason);
        return { ok: false, reason };
      }

      // Step 3: Focus the box (clear any leftover draft first)
      box.focus();
      await sleep(400);
      if (box.textContent.trim()) {
        document.execCommand("selectAll");
        document.execCommand("delete");
        await sleep(200);
      }

      // Step 4: Insert text. execCommand("insertText") fires a real
      // beforeinput/input pair that Lexical handles. The old clipboard path
      // (navigator.clipboard.writeText + execCommand("paste")) fails in
      // background tabs and overwrote the user's clipboard. There is NO
      // textContent/innerText fallback on purpose — writing the DOM directly
      // bypasses Lexical's state, so the box LOOKS filled but FB submits
      // nothing (a false "success").
      const probe = normalizeForCompare(commentText.trim().substring(0, 20));
      const boxHasOurText = () => normalizeForCompare(box.textContent).includes(probe);

      document.execCommand("insertText", false, commentText);
      await sleep(300);

      if (!boxHasOurText()) {
        // Fallback: synthetic paste event carrying text/plain — Lexical reads
        // event.clipboardData directly, no real clipboard involved.
        log("insertText didn't land — trying synthetic paste event");
        box.focus();
        if (box.textContent.trim()) {
          document.execCommand("selectAll");
          document.execCommand("delete");
        }
        try {
          const dt = new DataTransfer();
          dt.setData("text/plain", commentText);
          box.dispatchEvent(new ClipboardEvent("paste", {
            clipboardData: dt, bubbles: true, cancelable: true,
          }));
        } catch (e) {
          log("Synthetic paste failed:", e.message);
        }
        await sleep(400);
      }

      if (!boxHasOurText()) {
        log("Text did not appear in comment box");
        // Best-effort: don't leave a half-inserted draft sitting in the box
        if (box.textContent.trim()) {
          box.focus();
          document.execCommand("selectAll");
          document.execCommand("delete");
        }
        return { ok: false, reason: "insert_failed" };
      }

      log("Text in box:", box.textContent.trim().substring(0, 50));

      // @tag the customer's Business Page at the end of the reply. If the tag
      // can't be made and the reply has no other way to reach the business,
      // add the Messenger link so the lead can still get in touch.
      if (tagName && (tagAtEnd || !normalizeForCompare(box.textContent).includes(normalizeForCompare(tagName)))) {
        const tagged = await tagPageInBox(box, tagName);
        const mme = String(config.messengerUrl || "").split("?")[0].split("#")[0];
        if (!tagged && tagAtEnd && mme && !box.textContent.includes(mme)) {
          box.focus();
          document.execCommand("insertText", false, ` ${mme}`);
          await sleep(300);
          log("Tag not made — added Messenger link instead");
        }
      }

      // Step 5: Submit — try button first, Enter key as fallback
      await sleep(400);

      // Re-confirm our text is still there right before submitting — the
      // "box cleared" check below only means something if it was full.
      const hadOurTextBeforeSubmit = boxHasOurText();
      if (!hadOurTextBeforeSubmit) {
        log("Comment text vanished before submit");
        return { ok: false, reason: "insert_failed" };
      }

      // Submit button is looked up inside this box's own form (or nearest
      // ancestor that holds a submit button) — not document-wide.
      const submitBtn = findSubmitButton(box);

      if (submitBtn) {
        submitBtn.click();
        log("Clicked submit button");
      } else {
        // Enter key fallback
        box.dispatchEvent(new KeyboardEvent("keydown", {
          key: "Enter", code: "Enter", keyCode: 13,
          bubbles: true, cancelable: true
        }));
        log("Used Enter key to submit");
      }

      await sleep(1000);

      // Step 6: Verify comment was posted — box had our text before submit
      // and is empty now
      const boxAfter = box.textContent.trim();
      if (hadOurTextBeforeSubmit && boxAfter === "") {
        log("Comment posted successfully — box cleared after submit");
        return { ok: true };
      } else {
        // This used to `return { ok: true, ... }` here — a real failure signal
        // (the box still has the drafted text, meaning submit didn't go through)
        // was being reported as success. background.js then showed a "Comment
        // posted" notification and relayed a "commented" stage update to GHL for
        // a comment that was never actually posted. Report the failure honestly;
        // no retry here since a delayed-clear false negative would otherwise risk
        // a genuine double-post.
        log("Box still has text after submit — comment was NOT confirmed posted");
        return { ok: false, reason: "box_not_cleared" };
      }

    } catch (err) {
      log("Comment posting error:", err.message);
      return { ok: false, reason: err.message };
    }
  }

  // Where to look for the comment editor on a permalink page: a dialog that
  // actually contains a Lexical editor (post opened as an overlay), else the
  // main column, else the whole document.
  function getCommentScope() {
    const dialog = document.querySelector('[role="dialog"]');
    if (dialog && dialog.querySelector('[data-lexical-editor="true"]')) return dialog;
    return document.querySelector('[role="main"]') || document;
  }

  const COMMENT_BOX_SELECTORS = [
    '[contenteditable="true"][data-lexical-editor="true"]',
    '[contenteditable="true"][aria-label*="comment" i]',
    '[contenteditable="true"][aria-placeholder*="comment" i]',
    '[role="textbox"][contenteditable="true"]',
  ];

  // Selectors tried in priority order (Lexical first), first match wins.
  function findCommentBox(scope) {
    for (const sel of COMMENT_BOX_SELECTORS) {
      const el = scope.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  const SUBMIT_SELECTOR =
    '[aria-label="Comment"]:not([aria-disabled="true"]), ' +
    'div[aria-label="Comment"][role="button"], ' +
    'div[aria-label*="Post comment"][role="button"]';

  // Submit button belonging to THIS box: inside box.closest("form"), else the
  // nearest ancestor of the box that contains a submit button (bounded to
  // the comment scope so we never climb into the rest of the feed).
  function findSubmitButton(box) {
    const form = box.closest("form");
    if (form) {
      const btn = form.querySelector(SUBMIT_SELECTOR);
      if (btn) return btn;
    }

    const scope = getCommentScope();
    let node = box.parentElement;
    for (let depth = 0; node && depth < 12; depth++) {
      const btn = node.querySelector(SUBMIT_SELECTOR);
      if (btn) return btn;
      if (node === scope || node === document.body) break;
      node = node.parentElement;
    }
    return null;
  }

  // Type "@Page Name" and pick the Page from FB's mention typeahead, which
  // turns it into a real, clickable tag. If the typeahead doesn't offer it
  // (markup change, page name ambiguity), the text simply stays as plain
  // "@Page Name" — the reply is still posted. UNVERIFIED against live FB.
  async function tagPageInBox(box, tagName) {
    try {
      box.focus();
      document.execCommand("insertText", false, ` @${tagName}`);
      const want = normalizeForCompare(tagName);
      const option = await waitForMatch(() => {
        for (const opt of document.querySelectorAll('[role="listbox"] [role="option"]')) {
          if (normalizeForCompare(opt.textContent).includes(want)) return opt;
        }
        return null;
      }, 2500);
      if (option) {
        option.click();
        await sleep(400);
        log("Tagged page:", tagName);
        return true;
      }
      log("Page tag typeahead not shown — leaving plain text @" + tagName);
    } catch (e) {
      log("Page tagging failed:", e.message);
    }
    return false;
  }

  // Whitespace-insensitive compare — Lexical renders newlines as separate
  // paragraphs, so textContent loses them.
  function normalizeForCompare(s) {
    return (s || "").replace(/\s+/g, "").toLowerCase();
  }

  // ─── DM Monitor ───────────────────────────────────────────────────────────
  // Watches for incoming Facebook Messages from leads.
  // When a DM arrives containing a phone number, fires the GHL webhook.
  // Only activates when on facebook.com/messages/

  let dmObserver = null;

  // In-memory mirror of chrome.storage.local's "processedDms", checked
  // synchronously so two DM elements processed in the same MutationObserver
  // tick can't both pass the dedupe check before either's storage write lands
  // (see checkForNewDms — that was a genuine check-then-act race between two
  // concurrent async chrome.storage.local.get calls). Loaded once when DM
  // monitoring starts so it still respects dedup history across page reloads.
  let processedDmsMemory = null;

  // normalized lead authorName -> lead id, built from chrome.storage.local
  // "leads". DMs are only acted on when the thread's display name matches a
  // known lead — previously ANY row with a phone number (including our own
  // outgoing messages and unrelated contacts) was sent to GHL.
  let leadAuthorIndex = null;

  function normalizeName(s) {
    return (s || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  // If one author has several leads, the most recent (by timestamp) wins.
  function buildLeadAuthorIndex(leads) {
    const index = new Map();
    const times = new Map();
    for (const lead of Array.isArray(leads) ? leads : []) {
      if (!lead || !lead.id) continue;
      const key = normalizeName(lead.authorName);
      if (!key || key === "unknown") continue;
      const t = Date.parse(lead.timestamp) || 0;
      if (!index.has(key) || t >= times.get(key)) {
        index.set(key, lead.id);
        times.set(key, t);
      }
    }
    return index;
  }

  function startDmMonitoring() {
    if (!isMessagesPage()) return;
    if (dmObserver) return; // already running

    log("DM monitoring active");

    chrome.storage.local.get(["processedDms", "leads"], (data) => {
      processedDmsMemory = new Set(data.processedDms || []);
      leadAuthorIndex = buildLeadAuthorIndex(data.leads);
      checkForNewDms(); // initial check, now that dedupe + lead data are loaded
    });

    // Keep the author index current as new leads are stored by background.js
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.leads) {
        leadAuthorIndex = buildLeadAuthorIndex(changes.leads.newValue);
      }
    });

    dmObserver = new MutationObserver(() => {
      checkForNewDms();
    });

    dmObserver.observe(document.body, { childList: true, subtree: true });
  }

  function checkForNewDms() {
    if (shutDownIfOrphaned()) return;
    // storage.local.get above hasn't resolved yet
    if (!processedDmsMemory || !leadAuthorIndex) return;
    if (leadAuthorIndex.size === 0) return; // no leads = nobody to match

    // Look for unread message threads
    const messageEls = document.querySelectorAll(
      '[data-testid="mwthreadlist-item"], ' +
      '[aria-label*="unread"], ' +
      'div[role="row"]'
    );

    for (const el of messageEls) {
      const text = el.innerText || "";
      const name = extractSenderName(el);

      // Only threads whose display name matches a known lead's author
      const leadId = leadAuthorIndex.get(normalizeName(name));
      if (!leadId) continue;

      // Preview = the row's text minus the display-name line. Skip our own
      // outgoing messages ("You: ..." / "You sent ...") — a number WE sent
      // isn't the lead's phone.
      const bodyLines = text
        .split("\n")
        .map((l) => l.trim())
        .filter((l) => l && normalizeName(l) !== normalizeName(name));
      const preview = bodyLines[0] || "";
      if (/^you(:|\s+sent\b)/i.test(preview)) continue;

      const phone = extractPhoneNumber(bodyLines.join("\n"));

      if (phone) {
        const dmId = `dm_${simpleHash(phone + name)}`;

        // Synchronous check-and-mark against the in-memory Set closes the race:
        // no other iteration (in this tick or the next mutation callback) can
        // see this id as "not yet processed" once we've added it here.
        if (processedDmsMemory.has(dmId)) continue;
        processedDmsMemory.add(dmId);
        try { chrome.storage.local.set({ processedDms: [...processedDmsMemory].slice(-100) }); } catch { shutDownIfOrphaned(); }

        log("Phone found in DM from:", name, "—", phone);

        // background.js relays it to GHL via the ghl-webhook function
        sendToBackground({
          type: "DM_PHONE_CAPTURED",
          leadId, // id of the matched lead in chrome.storage.local "leads"
          contact: {
            name,
            phone,
            source: "facebook_dm",
            rawText: text.substring(0, 300),
            timestamp: new Date().toISOString(),
          },
        });
      }
    }
  }

  function extractPhoneNumber(text) {
    // Match common US phone formats
    const patterns = [
      /\b(\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/,
      /\b\d{10}\b/,
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) return match[0].replace(/\D/g, "").slice(-10);
    }
    return null;
  }

  function extractSenderName(el) {
    const nameEl = el.querySelector(
      '[data-testid="mwthreadlist-item-name"], ' +
      'span[dir="auto"]:first-child, ' +
      'a[role="link"] span'
    );
    return nameEl ? nameEl.textContent.trim() : "Unknown";
  }

  // ─── DOM Helpers ──────────────────────────────────────────────────────────

  // Resolves with finder()'s first truthy result, re-checked on every DOM
  // mutation, or null after timeoutMs. Takes a function (not a selector) so
  // callers can scope the lookup (e.g. to the post's dialog/main column).
  function waitForMatch(finder, timeoutMs = 5000) {
    return new Promise((resolve) => {
      const existing = finder();
      if (existing) return resolve(existing);

      let timer = null;
      const observer = new MutationObserver(() => {
        const el = finder();
        if (el) {
          observer.disconnect();
          clearTimeout(timer);
          resolve(el);
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      timer = setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }


  // ─── Navigation Observer ──────────────────────────────────────────────────
  // Facebook is a SPA — URL changes don't reload the page
  let navObserver = null;

  function observeNavigation() {
    if (navObserver) return; // init() may call this from both the /messages and group paths
    let lastUrl = window.location.href;

    const observer = navObserver = new MutationObserver(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        stopScanning();
        checkIfGroupPage();

        // New page: fresh per-page counts (bubble.js decides what to show).
        badge.checked = 0; badge.matches = 0;

        if (isGroupPage) {
          loadConfig().then(startScanning);
        }

        // Start DM monitoring if navigated to messages
        if (isMessagesPage()) {
          startDmMonitoring();
        }
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ─── Group search results (group finder) ──────────────────────────────────
  // Facebook's markup changes often, so this reads text, not class names: each
  // result is a link to /groups/<id>/ whose surrounding block mentions
  // "members". From that block: members, posts a day, public/private, and
  // whether the owner is already in it.
  function scrapeGroupSearch(doc) {
    const SKIP = /^(feed|discover|joins|create|search|notifications|your_groups|categories)$/i;
    const out = new Map();
    for (const a of doc.querySelectorAll('a[href*="/groups/"]')) {
      const m = (a.getAttribute("href") || "").match(/facebook\.com\/groups\/([^/?#]+)|^\/groups\/([^/?#]+)/);
      const slug = m && (m[1] || m[2]);
      if (!slug || SKIP.test(slug)) continue;
      const url = `https://www.facebook.com/groups/${slug}/`;
      const name = (a.textContent || "").trim();
      if (name.length < 3 || out.has(url) && out.get(url).name) continue;
      // Walk up to the result's own block; stop at one that also holds
      // another group's link (that's the list, not this result).
      let box = a, meta = "";
      for (let i = 0; i < 8 && box.parentElement; i++) {
        box = box.parentElement;
        const others = [...box.querySelectorAll('a[href*="/groups/"]')].some((o) => {
          const om = (o.getAttribute("href") || "").match(/\/groups\/([^/?#]+)/);
          return om && om[1] !== slug && !SKIP.test(om[1]);
        });
        if (others) break;
        const t = box.innerText || box.textContent || "";
        if (/\bmembers?\b/i.test(t)) { meta = t; break; }
      }
      if (!meta) continue;
      out.set(url, { url, name, ...parseGroupMeta(meta) });
    }
    return [...out.values()].slice(0, 25);
  }

  function parseGroupMeta(text) {
    const t = String(text).replace(/\s+/g, " ");
    const mem = t.match(/([\d.,]+)\s*([KkMm])?\s+members?\b/);
    let members = null;
    if (mem) {
      const n = parseFloat(mem[1].replace(/,/g, ""));
      members = Math.round(n * (/k/i.test(mem[2] || "") ? 1e3 : /m/i.test(mem[2] || "") ? 1e6 : 1));
    }
    const posts = t.match(/(\d+)\+?\s+posts?\s+(?:a|per)\s+(day|week|month|year)/i);
    const per = { day: 1, week: 7, month: 30, year: 365 };
    const postsPerDay = posts ? Math.round((Number(posts[1]) / per[posts[2].toLowerCase()]) * 10) / 10 : null;
    return {
      members, postsPerDay,
      privacy: /\bprivate\b/i.test(t) ? "private" : /\bpublic\b/i.test(t) ? "public" : null,
      member: /\b(joined|you're a member|you are a member|visit group|view group)\b/i.test(t),
    };
  }

  // ─── Message Listener (from popup/background) ─────────────────────────────
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "CONFIG_UPDATED") {
      stopScanning();
      loadConfig().then(() => {
        if (isGroupPage) startScanning();
        sendResponse({ ok: true });
      });
      return true;
    }

    // Group finder (setup): a notice on the search tab, which closes by itself.
    if (message.type === "FINDER_BANNER") {
      if (!document.getElementById("an-finder-banner")) {
        const d = document.createElement("div");
        d.id = "an-finder-banner";
        d.textContent = "AnyoneNear is searching for local groups in this tab. It closes by itself in a few seconds, and another may open. You can keep using Facebook in your other tabs.";
        d.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#1f6feb;color:#fff;font:600 14px/1.4 system-ui,-apple-system,Segoe UI,sans-serif;padding:12px 16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.3)";
        document.documentElement.appendChild(d);
      }
      sendResponse({ ok: true });
      return;
    }

    // Group finder (setup): read a Facebook group-search results page.
    if (message.type === "SCRAPE_GROUP_SEARCH") {
      (async () => {
        for (let i = 0; i < 2; i++) { window.scrollBy(0, window.innerHeight); await new Promise((r) => setTimeout(r, 1200)); }
        sendResponse({ ok: true, groups: scrapeGroupSearch(document) });
      })();
      return true;
    }

    if (message.type === "PING") {
      sendResponse({ ok: true, isGroupPage, keywordCount: config.keywords.length });
    }

    // The monitoring (cycling) tab only: scroll slowly down the feed so FB
    // loads more than the first handful of posts, then return to the top.
    // Never runs in a tab the user can see — it stops the moment the tab
    // becomes visible.
    if (message.type === "CYCLE_SCAN") {
      sendResponse({ ok: true });
      deepScroll(message.maxSteps || 6);
    }

    // One step of a monitoring visit, driven by background.js (runVisit):
    // scroll a screen (not on the first step), read what's there, and report
    // how many posts were new, how many were already known before this visit
    // started, and how tall the feed is now (so it can tell "caught up" from
    // "Facebook isn't loading more").
    if (message.type === "SCAN_STEP") {
      scanStep(message).then(sendResponse, () => sendResponse({ ok: false, reason: "error" }));
      return true;
    }
    if (message.type === "SCAN_DONE") {
      if (document.visibilityState !== "visible") window.scrollTo({ top: 0, behavior: "instant" });
      badgeWatching();
      sendResponse({ ok: true });
    }

    // Background asks content script to post a comment
    if (message.type === "POST_COMMENT") {
      // background.js records the outcome on the lead (it serializes all
      // writes to "leads" — a second writer here could drop its updates).
      postComment(message.postUrl, message.commentText, message.tagName).then(sendResponse);
      return true; // async
    }

    // Start DM monitoring on demand
    if (message.type === "START_DM_MONITOR") {
      startDmMonitoring();
      sendResponse({ ok: true });
    }
  });

  let visitKnown = null;   // post ids known when the current visit started

  // The monitoring window's tab reads "AnyoneNear monitoring · <group>" so it's
  // easy to find in the taskbar and Alt+Tab. Facebook rewrites the title as it
  // updates the page, so it's put back whenever that happens.
  let monitorLabel = "", titleObserver = null;
  function markMonitorTab(label) {
    monitorLabel = `AnyoneNear monitoring · ${label || extractGroupName()}`;
    if (document.title !== monitorLabel) document.title = monitorLabel;
    if (titleObserver) return;
    const head = document.querySelector("head");
    if (!head) return;
    titleObserver = new MutationObserver(() => { if (monitorLabel && document.title !== monitorLabel) document.title = monitorLabel; });
    titleObserver.observe(head, { subtree: true, childList: true, characterData: true });
  }

  // Facebook's "This content isn't available right now" page (the group is
  // gone, the account can't see it, or it rejected the link's sort setting).
  function contentUnavailable() {
    const t = (document.querySelector('[role="main"]')?.innerText || document.body?.innerText || "").slice(0, 2000);
    return /this content isn'?t available|content not found|this page isn'?t available/i.test(t) && postContainers().length === 0;
  }

  async function scanStep({ scroll, first, label, away }) {
    markMonitorTab(label);
    if (first && contentUnavailable()) return { ok: false, reason: "unavailable" };
    if (!isGroupPage) return { ok: false, reason: "not_group" };
    if (!isWatchedGroupPage()) return { ok: false, reason: "not_watched" };
    if (first || !visitKnown) visitKnown = new Set(seenPostIds);
    // Someone is looking at this window: leave it alone. (Not when nobody is
    // at the computer: then it's in front because the extension brought it.)
    if (scroll && !away && document.visibilityState === "visible" && document.hasFocus()) return { ok: false, reason: "in_use" };
    if (scroll) window.scrollBy({ top: Math.round(window.innerHeight * (0.8 + Math.random() * 0.3)), behavior: "instant" });
    for (let i = 0; i < 10 && scanPosts.running; i++) await sleep(300);
    const before = { ...badge };
    await scanPosts();
    let oldSeen = 0;
    for (const el of postContainers()) { const { id } = computePostIdentity(el); if (id && visitKnown.has(id)) oldSeen++; }
    badgeWatching(`reading the feed · ${badge.checked} post${badge.checked === 1 ? "" : "s"} checked`);
    // Age of the lowest post on the page that shows its time (the deep check
    // stops once it reaches ~2-day-old posts).
    let oldestAgeH = null;
    const els = postContainers();
    for (let k = els.length - 1; k >= 0 && k >= els.length - 8; k--) {
      const t = Number(extractTimestamp(els[k]));
      if (t > 0) { oldestAgeH = (Date.now() - t) / 3600e3; break; }
    }
    return { ok: true, newPosts: badge.checked - before.checked, matches: badge.matches - before.matches, oldSeen, oldestAgeH,
      oldPosts: badge.old - before.old, skippedOld: badge.skipOld - before.skipOld, skippedWords: badge.skipWord - before.skipWord,
      height: document.documentElement.scrollHeight, hidden: document.visibilityState !== "visible" };
  }

  let deepScrolling = false;
  // maxSteps: ~6 on a routine visit, up to 15 when catching up after a gap
  // (e.g. Chrome was closed overnight). Stops early once scrolling stops
  // turning up posts it hasn't already seen — the feed is newest-first, so
  // that means it has caught up to where the last visit left off.
  async function deepScroll(maxSteps = 6) {
    if (deepScrolling || !isGroupPage || document.visibilityState === "visible") return;
    deepScrolling = true;
    try {
      const steps = Math.max(3, maxSteps - Math.floor(Math.random() * 2));
      let dryRuns = 0;
      for (let i = 0; i < steps; i++) {
        if (document.visibilityState === "visible" || orphaned) break;
        badgeWatching(`${maxSteps > 6 ? "catching up" : "loading more posts"} (${i + 1}/${steps})`);
        const before = badge.checked;
        window.scrollBy({ top: Math.round(window.innerHeight * (0.6 + Math.random() * 0.3)), behavior: "smooth" });
        await sleep(2500 + Math.random() * 3000);                 // human-ish reading pause
        scanPosts();
        dryRuns = badge.checked === before ? dryRuns + 1 : 0;
        if (i >= 2 && dryRuns >= 2) break;                        // nothing new two screens running
      }
      if (document.visibilityState !== "visible") window.scrollTo({ top: 0 });
    } finally {
      deepScrolling = false;
      if (!orphaned) badgeWatching();
    }
  }

  // ─── Utilities ────────────────────────────────────────────────────────────
  function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash).toString(36);
  }

  function log(...args) {
    console.log("[AnyoneNear]", ...args);
  }

  // ─── Boot ─────────────────────────────────────────────────────────────────
  init();
})();
